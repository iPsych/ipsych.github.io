// V53: Dual-GPU SIFT filtering with inline diff + packed cost kernels
// Uses GPU0 + GPU1 to split gradient computation across NVLink

#include "sift_wrapper_v28.cuh"
#include "tck_reader.cuh"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <cstring>
#include <cstdint>
#include <cmath>
#include <limits>

struct MappingData {
    uint32_t num_tracks;
    uint32_t num_fixels;
    uint64_t total_entries;
    double FOD_sum;
    double TD_sum;
    std::vector<uint64_t> offsets;
    std::vector<uint32_t> fixel_indices;
    std::vector<float> segment_lengths;
    std::vector<float> total_contribution;
    std::vector<float> total_length;
    std::vector<double> fixel_FOD;
    std::vector<double> fixel_TD;
    std::vector<double> fixel_weight;
};

bool load_mapping(const char* path, MappingData& data) {
    std::ifstream f(path, std::ios::binary);
    if (!f) { std::cerr << "Cannot open " << path << std::endl; return false; }
    uint32_t magic;
    f.read(reinterpret_cast<char*>(&magic), 4);
    if (magic != 0x5349464D) { std::cerr << "Bad magic" << std::endl; return false; }
    f.read(reinterpret_cast<char*>(&data.num_tracks), 4);
    f.read(reinterpret_cast<char*>(&data.num_fixels), 4);
    f.read(reinterpret_cast<char*>(&data.total_entries), 8);
    f.read(reinterpret_cast<char*>(&data.FOD_sum), 8);
    f.read(reinterpret_cast<char*>(&data.TD_sum), 8);
    data.offsets.resize(data.num_tracks + 1);
    f.read(reinterpret_cast<char*>(data.offsets.data()), (data.num_tracks + 1) * 8);
    data.fixel_indices.resize(data.total_entries);
    f.read(reinterpret_cast<char*>(data.fixel_indices.data()), data.total_entries * 4);
    data.segment_lengths.resize(data.total_entries);
    f.read(reinterpret_cast<char*>(data.segment_lengths.data()), data.total_entries * 4);
    data.total_contribution.resize(data.num_tracks);
    f.read(reinterpret_cast<char*>(data.total_contribution.data()), data.num_tracks * 4);
    data.total_length.resize(data.num_tracks);
    f.read(reinterpret_cast<char*>(data.total_length.data()), data.num_tracks * 4);
    data.fixel_FOD.resize(data.num_fixels);
    f.read(reinterpret_cast<char*>(data.fixel_FOD.data()), data.num_fixels * 8);
    data.fixel_TD.resize(data.num_fixels);
    f.read(reinterpret_cast<char*>(data.fixel_TD.data()), data.num_fixels * 8);
    data.fixel_weight.resize(data.num_fixels);
    f.read(reinterpret_cast<char*>(data.fixel_weight.data()), data.num_fixels * 8);
    if (!f) { std::cerr << "Error reading mapping" << std::endl; return false; }
    return true;
}

int main(int argc, char** argv) {
    if (argc < 5) {
        std::cerr << "Usage: " << argv[0] << " <mapping.bin> <tracks.tck> <output.tck> <target_count> [--gpu0 i] [--gpu1 j|-1] [--csv path] [--timing_json path] [--dump_gradients path]" << std::endl;
        return 1;
    }

    const char* mapping_path = argv[1];
    const char* tck_path = argv[2];
    const char* output_path = argv[3];
    size_t target_count = std::stoull(argv[4]);
    double nl_factor = 1.0;
    double q_factor = 1.0;
    int gpu0 = 0, gpu1 = 1;
    std::string csv_path, timing_json, dump_gradients;
    for (int i = 5; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--gpu0" && i+1 < argc) gpu0 = std::stoi(argv[++i]);
        else if (a == "--gpu1" && i+1 < argc) gpu1 = std::stoi(argv[++i]);
        else if (a == "--csv" && i+1 < argc) csv_path = argv[++i];
        else if (a == "--timing_json" && i+1 < argc) timing_json = argv[++i];
        else if (a == "--dump_gradients" && i+1 < argc) dump_gradients = argv[++i];
        else { std::cerr << "Unknown option: " << a << std::endl; return 1; }
    }
    auto wall = [](){ return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count(); };
    const double t_prog0 = wall();

    std::cout << "=== CUDA SIFT V53 - Dual-GPU with Inline Diff ===" << std::endl;
    std::cout << "  Nonlinearity factor: " << nl_factor << std::endl;
    std::cout << "  Quantisation factor: " << q_factor << std::endl;

    MappingData mapping;
    if (!load_mapping(mapping_path, mapping)) return 1;
    const double t_read = wall() - t_prog0;

    double mu = mapping.FOD_sum / mapping.TD_sum;
    printf("Mapping: %u tracks, %u fixels, %lu entries\n",
           mapping.num_tracks, mapping.num_fixels, mapping.total_entries);
    printf("FOD_sum=%.6f, TD_sum=%.6f, mu=%.10f\n",
           mapping.FOD_sum, mapping.TD_sum, mu);

    // Convert offsets from uint64_t to int64_t
    std::vector<int64_t> offsets_i64(mapping.offsets.begin(), mapping.offsets.end());

    std::cout << "\nLoading data to GPU..." << std::endl;

    SIFT::GPU::v28::SIFTerGPU_Sequential sifter(gpu0, gpu1);

    if (!sifter.load_double(
        offsets_i64.data(),
        mapping.fixel_indices.data(),
        mapping.segment_lengths.data(),
        mapping.total_contribution.data(),
        mapping.total_length.data(),
        mapping.fixel_FOD.data(),
        mapping.fixel_TD.data(),
        mapping.fixel_weight.data(),
        mapping.FOD_sum,
        mapping.TD_sum,
        mapping.num_tracks,
        mapping.num_fixels,
        mapping.total_entries
    )) {
        std::cerr << "Failed to load data to GPU" << std::endl;
        return 1;
    }

    cudaDeviceSynchronize();
    const double t_h2d_done = wall() - t_prog0;
    double mem0 = 0, mem1 = 0;
    sifter.device_memory_used_MB(mem0, mem1);
    printf("Device memory in use after upload: GPU%d %.1f MB, GPU%d %.1f MB\n", gpu0, mem0, gpu1, mem1);

    SIFT::GPU::v28::FilteringConfig config;
    config.term_number = target_count;
    config.enforce_quantisation = true;
    config.nonlinearity_factor = nl_factor;
    config.quantisation_factor = q_factor;
    config.csv_path = csv_path;

    std::cout << "\n--- Starting SIFT filtering (V53 dual-GPU, nl_factor=" << nl_factor
              << ", q_factor=" << q_factor << ") ---" << std::endl;

    auto result = sifter.filter_compact(config);

    std::cout << "\n=== Filtering complete ===" << std::endl;
    std::cout << "Removed: " << result.total_removed
              << ", Remaining: " << result.remaining_streamlines << std::endl;
    std::cout << "Final mu: " << std::fixed << std::setprecision(10) << result.final_mu << std::endl;
    std::cout << "Iterations: " << result.num_iterations << std::endl;
    std::cout << "Time: " << std::fixed << std::setprecision(2) << result.elapsed_seconds << " seconds" << std::endl;

    const double t_opt_done = wall() - t_prog0;
    if (!dump_gradients.empty()) sifter.dump_sorted_gradients(dump_gradients, 20000);
    const double t_dump_done = wall() - t_prog0;

    // Write surviving streamlines
    auto surviving = sifter.get_surviving_indices();
    std::cout << "Writing " << surviving.size() << " surviving streamlines to " << output_path << std::endl;

    MRtrix::TCKReader reader(tck_path);

    std::ofstream out(output_path, std::ios::binary);
    out << "mrtrix tracks\ncount: " << surviving.size()
        << "\ndatatype: Float32LE\nfile: . ";

    std::streampos header_offset_pos = out.tellp();
    out << "000000000\nEND\n";

    std::streampos data_start = out.tellp();
    {
        std::ostringstream oss;
        oss << std::setw(9) << std::setfill('0') << data_start;
        out.seekp(header_offset_pos);
        out << oss.str();
        out.seekp(data_start);
    }

    size_t written = 0;
    MRtrix::Streamline track;
    size_t surviving_idx = 0;
    std::vector<size_t> sorted_surviving(surviving.begin(), surviving.end());
    std::sort(sorted_surviving.begin(), sorted_surviving.end());

    for (size_t t = 0; t < mapping.num_tracks && surviving_idx < sorted_surviving.size(); ++t) {
        if (!reader.read(track)) break;
        if (t == sorted_surviving[surviving_idx]) {
            for (const auto& p : track) {
                out.write((char*)&p.x, sizeof(float));
                out.write((char*)&p.y, sizeof(float));
                out.write((char*)&p.z, sizeof(float));
            }
            float nan3[3] = {NAN, NAN, NAN};
            out.write((char*)nan3, sizeof(nan3));
            ++written;
            ++surviving_idx;
            if (written % 1000000 == 0)
                std::cout << "  Written " << (written/1000000) << "M streamlines..." << std::endl;
        }
        track.clear();
    }

    float inf3[3];
    inf3[0] = inf3[1] = inf3[2] = std::numeric_limits<float>::infinity();
    out.write((char*)inf3, sizeof(inf3));
    out.close();

    std::cout << "Wrote " << written << " streamlines" << std::endl;
    const double t_total = wall() - t_prog0;
    const double t_write = t_total - t_dump_done;
    printf("Phase timing (s): read_mapping=%.2f  alloc+h2d=%.2f  optimise=%.2f  write_tck=%.2f  total=%.2f\n",
           t_read, t_h2d_done - t_read, result.elapsed_seconds, t_write, t_total);
    if (!timing_json.empty()) {
        std::ofstream tj(timing_json);
        tj << std::setprecision(17) << "{\"t_read_mapping\":" << t_read << ",\"t_alloc_h2d\":" << (t_h2d_done - t_read)
           << ",\"t_optimise\":" << result.elapsed_seconds << ",\"t_optimise_wall\":" << (t_opt_done - t_h2d_done)
           << ",\"t_write_tck\":" << t_write << ",\"t_total\":" << t_total
           << ",\"iterations\":" << result.num_iterations << ",\"total_removed\":" << result.total_removed
           << ",\"remaining\":" << result.remaining_streamlines << ",\"initial_cost\":" << result.initial_cost
           << ",\"final_cost\":" << result.final_cost << ",\"final_mu\":" << result.final_mu
           << ",\"gpu0_mem_MB\":" << mem0 << ",\"gpu1_mem_MB\":" << mem1 << ",\"gpu0\":" << gpu0 << ",\"gpu1\":" << gpu1
           << ",\"num_tracks\":" << mapping.num_tracks << ",\"num_fixels\":" << mapping.num_fixels << ",\"total_entries\":" << mapping.total_entries << "}\n";
    }
    std::cout << "\n=== Done ===" << std::endl;

    return 0;
}

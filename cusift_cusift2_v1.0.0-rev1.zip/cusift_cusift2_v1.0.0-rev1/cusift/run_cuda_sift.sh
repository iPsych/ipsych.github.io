#!/bin/bash
# CUDA SIFT V53 - Drop-in replacement for MRtrix tcksift
#
# Uses the same argument format as tcksift:
#   ./run_cuda_sift.sh [options] <in_tracks> <in_fod> <out_tracks>
#
# Examples:
#   ./run_cuda_sift.sh -act 5tt_nocoreg.mif -term_number 1000000 tracks_10mio.tck wmfod_norm.mif sift_1mio.tck -force
#   ./run_cuda_sift.sh -act 5tt_nocoreg.mif -term_number 10000000 tracks_100mio.tck wmfod_norm.mif sift_10mio.tck -force

set -euo pipefail

# ---- Default configuration ----
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MRTRIX_BIN="${MRTRIX_BIN:-$(dirname "$SCRIPT_DIR")/mrtrix3/bin}"
CUDA_BINARY="${SCRIPT_DIR}/sift_gpu"
TERM_NUMBER=0
ACT_FILE=""
FORCE=false
NTHREADS=""
GPU0=0
GPU1=1
MAPPING_FILE=""
REUSE_MAPPING=false

# ---- Parse arguments (tcksift-compatible) ----
POSITIONAL=()

while [ $# -gt 0 ]; do
    case "$1" in
        -act)           ACT_FILE="$2"; shift 2 ;;
        -term_number)   TERM_NUMBER="$2"; shift 2 ;;
        -term_ratio)    TERM_RATIO="$2"; shift 2 ;;
        -nthreads)      NTHREADS="$2"; shift 2 ;;
        -force)         FORCE=true; shift ;;
        -gpu0)          GPU0="$2"; shift 2 ;;
        -gpu1)          GPU1="$2"; shift 2 ;;
        -mapping)       MAPPING_FILE="$2"; shift 2 ;;
        -reuse_mapping) REUSE_MAPPING=true; shift ;;
        -help|--help)
            echo "CUDA SIFT V53 - Drop-in replacement for MRtrix tcksift"
            echo ""
            echo "Usage: $0 [options] <in_tracks> <in_fod> <out_tracks>"
            echo ""
            echo "tcksift-compatible options:"
            echo "  -act <5tt.mif>        5TT image for anatomical constraint"
            echo "  -term_number <N>      Target number of remaining streamlines"
            echo "  -nthreads <N>         Number of CPU threads (passed to MRtrix mapping step)"
            echo "  -force                Overwrite output files"
            echo ""
            echo "CUDA-specific options:"
            echo "  -gpu0 <id>            Primary GPU device ID (default: 0)"
            echo "  -gpu1 <id>            Helper GPU device ID (default: 1, -1 for single-GPU)"
            echo "  -mapping <file.bin>   Custom path for mapping binary"
            echo "  -reuse_mapping        Reuse existing mapping file"
            exit 0
            ;;
        -*)
            echo "WARNING: Unknown option '$1' ignored" >&2
            shift
            ;;
        *)
            POSITIONAL+=("$1")
            shift
            ;;
    esac
done

# ---- Validate positional arguments ----
if [ ${#POSITIONAL[@]} -ne 3 ]; then
    echo "ERROR: Expected 3 positional arguments: <in_tracks> <in_fod> <out_tracks>"
    echo "Usage: $0 [options] <in_tracks> <in_fod> <out_tracks>"
    echo ""
    echo "Examples:"
    echo "  $0 -act 5tt_nocoreg.mif -term_number 1000000 tracks_10mio.tck wmfod_norm.mif sift_1mio.tck -force"
    echo "  $0 -act 5tt_nocoreg.mif -term_number 10000000 tracks_100mio.tck wmfod_norm.mif sift_10mio.tck -force"
    exit 1
fi

TRACKS_FILE="${POSITIONAL[0]}"
FOD_FILE="${POSITIONAL[1]}"
OUTPUT_FILE="${POSITIONAL[2]}"

# ---- Validate inputs ----
for f in "$TRACKS_FILE" "$FOD_FILE"; do
    if [ ! -f "$f" ]; then
        echo "ERROR: File not found: $f"
        exit 1
    fi
done

if [ -n "$ACT_FILE" ] && [ ! -f "$ACT_FILE" ]; then
    echo "ERROR: ACT file not found: $ACT_FILE"
    exit 1
fi

if [ -f "$OUTPUT_FILE" ] && [ "$FORCE" = false ]; then
    echo "ERROR: Output file already exists: $OUTPUT_FILE (use -force to overwrite)"
    exit 1
fi

if [ ! -f "$CUDA_BINARY" ]; then
    echo "ERROR: CUDA binary not found: $CUDA_BINARY"
    echo "Run 'make' in $SCRIPT_DIR first."
    exit 1
fi

TCKSIFT_BIN="${MRTRIX_BIN}/tcksift"
if [ ! -f "$TCKSIFT_BIN" ]; then
    echo "ERROR: Modified tcksift not found at: $TCKSIFT_BIN"
    echo "Set MRTRIX_BIN environment variable to point to the MRtrix3 bin directory."
    exit 1
fi

if [ "$TERM_NUMBER" -eq 0 ]; then
    echo "ERROR: -term_number is required"
    exit 1
fi

# Auto-generate mapping path if not specified
if [ -z "$MAPPING_FILE" ]; then
    MAPPING_DIR="$(dirname "$OUTPUT_FILE")"
    MAPPING_BASE="$(basename "$TRACKS_FILE" .tck)"
    MAPPING_FILE="${MAPPING_DIR}/.${MAPPING_BASE}_sift_mapping.bin"
fi

echo "=============================================="
echo "  CUDA SIFT V53"
echo "=============================================="
echo "  Input tracks:  $TRACKS_FILE"
echo "  FOD image:     $FOD_FILE"
echo "  Output:        $OUTPUT_FILE"
echo "  ACT image:     ${ACT_FILE:-none}"
echo "  Term number:   $TERM_NUMBER"
echo "  GPUs:          $GPU0 (primary), $GPU1 (helper)"
echo "=============================================="

# ---- Stage 1: Generate mapping binary ----
if [ "$REUSE_MAPPING" = true ] && [ -f "$MAPPING_FILE" ]; then
    echo ""
    echo "[Stage 1/2] Reusing existing mapping: $MAPPING_FILE"
else
    echo ""
    echo "[Stage 1/2] Generating streamline-to-fixel mapping..."
    echo ""

    TCKSIFT_ARGS=()
    if [ -n "$ACT_FILE" ]; then
        TCKSIFT_ARGS+=("-act" "$ACT_FILE")
    fi
    if [ -n "$NTHREADS" ]; then
        TCKSIFT_ARGS+=("-nthreads" "$NTHREADS")
    fi

    STAGE1_START=$(date +%s)

    # MRtrix requires .tck suffix on output; use temp file with -nofilter
    DUMMY_TCK=$(mktemp /tmp/cuda_sift_dummy_XXXXXX.tck)
    trap "rm -f '$DUMMY_TCK'" EXIT

    "$TCKSIFT_BIN" \
        "${TCKSIFT_ARGS[@]}" \
        -term_number "$TERM_NUMBER" \
        -output_mapping "$MAPPING_FILE" \
        -nofilter \
        -force \
        "$TRACKS_FILE" \
        "$FOD_FILE" \
        "$DUMMY_TCK"

    rm -f "$DUMMY_TCK"

    STAGE1_END=$(date +%s)
    STAGE1_TIME=$((STAGE1_END - STAGE1_START))
    echo ""
    echo "  Mapping generated in ${STAGE1_TIME}s"
    echo "  Size: $(du -h "$MAPPING_FILE" | cut -f1)"
fi

# ---- Stage 2: Run CUDA SIFT filtering ----
echo ""
echo "[Stage 2/2] Running CUDA SIFT filtering..."
echo ""

STAGE2_START=$(date +%s)

"$CUDA_BINARY" \
    "$MAPPING_FILE" \
    "$TRACKS_FILE" \
    "$OUTPUT_FILE" \
    "$TERM_NUMBER" \
    2>&1

STAGE2_END=$(date +%s)
STAGE2_TIME=$((STAGE2_END - STAGE2_START))

# ---- Report results ----
echo ""
echo "=============================================="
echo "  Results"
echo "=============================================="

OUTPUT_COUNT=$(grep -a "^count:" "$OUTPUT_FILE" 2>/dev/null | head -1 | awk '{print $2}' || echo "unknown")
echo "  Output streamlines: $OUTPUT_COUNT"
echo "  Output file: $OUTPUT_FILE"
echo "  Output size: $(du -h "$OUTPUT_FILE" | cut -f1)"

if [ "${STAGE1_TIME:-0}" -gt 0 ]; then
    TOTAL_TIME=$((STAGE1_TIME + STAGE2_TIME))
    echo ""
    echo "  Timing:"
    echo "    Mapping:   ${STAGE1_TIME}s"
    echo "    Filtering: ${STAGE2_TIME}s"
    echo "    Total:     ${TOTAL_TIME}s"
else
    echo ""
    echo "  Filtering: ${STAGE2_TIME}s"
fi

echo "=============================================="

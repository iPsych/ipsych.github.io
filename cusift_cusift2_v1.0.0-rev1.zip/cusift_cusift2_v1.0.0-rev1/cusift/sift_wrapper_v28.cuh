// CUDA SIFT Wrapper - Version 28 (V53: Dual-GPU)
// GPU-parallel gradient + CPU-sequential removal matching MRtrix exactly
// V53: Split gradient computation across 2 GPUs via NVLink

#ifndef SIFT_WRAPPER_V28_CUH
#define SIFT_WRAPPER_V28_CUH

#include <cuda_runtime.h>
#include <vector>
#include <string>
#include <chrono>

namespace SIFT {
namespace GPU {
namespace v28 {

// Packed fixel data for cache-friendly random access in gradient kernel
// 32 bytes = 4 fixels per cache line (128B). All doubles for precision matching MRtrix.
struct FixelPacked {
    double TD, FOD, weight, _pad;  // _pad keeps 32-byte alignment (diff computed inline)
};

enum RecalcReason {
    UNDEFINED,
    NONLINEARITY,
    QUANTISATION,
    TERM_COUNT,
    TERM_RATIO,
    TERM_MU,
    POS_GRADIENT
};

struct MemoryConfig {
    size_t max_streamlines = 200000000;
    size_t max_fixels = 5000000;
};

struct FilteringConfig {
    double term_ratio = 0.0;
    size_t term_number = 0;
    double term_mu = 0.0;
    bool enforce_quantisation = true;
    bool verbose = true;
    size_t progress_interval = 100000;
    bool use_cpu_precision = false;
    std::string csv_path;
    double nonlinearity_factor = 1.0;
    double quantisation_factor = 1.0;
};

struct FilteringResult {
    size_t total_removed;
    size_t remaining_streamlines;
    double initial_cost;
    double final_cost;
    double elapsed_seconds;
    double final_mu;
    size_t num_iterations;
    RecalcReason termination_reason;
};

class SIFTerGPU_Sequential {
public:
    // device_id: primary GPU, helper_device_id: secondary GPU (-1 = single-GPU mode)
    SIFTerGPU_Sequential(int device_id, int helper_device_id = -1,
                          const MemoryConfig& config = MemoryConfig())
        : device_id_(device_id), helper_device_id_(helper_device_id), config_(config) {}

    ~SIFTerGPU_Sequential() { free_memory(); }

    // Load with double-precision fixel data and pre-computed TD/sums
    bool load_double(
        const int64_t* offsets,
        const uint32_t* fixel_indices,
        const float* segment_lengths,
        const float* total_contributions,
        const float* total_lengths,
        const double* fixel_FOD,
        const double* fixel_TD,
        const double* fixel_weight,
        double precomputed_FOD_sum,
        double precomputed_TD_sum,
        size_t num_streamlines,
        size_t num_fixels,
        size_t num_edges
    );

    // Run optimized filtering with GPU compaction (only processes active streamlines)
    FilteringResult filter_compact(const FilteringConfig& config);

    // Get surviving indices after filtering
    std::vector<size_t> get_surviving_indices();

    // Instrumentation only: recompute gradients for the surviving set at the final state,
    // sort them, and write the K smallest normalised gradients (removal candidates) to a text file.
    void dump_sorted_gradients(const std::string& path, size_t K);
    // Instrumentation only: device memory in use (MB) on primary and helper GPU
    void device_memory_used_MB(double& primary, double& helper) const;

    // Accessors
    double calculate_mu() const { return TD_sum_ > 0 ? FOD_sum_ / TD_sum_ : 0.0; }
    double get_FOD_sum() const { return FOD_sum_; }
    double get_TD_sum() const { return TD_sum_; }
    size_t get_num_active() const { return num_streamlines_ - removed_count_; }

private:
    void allocate_gpu_memory();
    void allocate_helper_gpu();  // Allocate GPU1 data
    void free_memory();

    // GPU operations
    double calculate_cost_packed();  // Cost from packed fixel data (inline diff)

    // CPU sequential removal (MRtrix-matching)
    size_t sequential_removal_pass(
        const double* h_abs_gradients,
        const uint32_t* h_sorted_indices,
        size_t num_candidates,
        double current_cf,
        double current_roc_cf,
        const FilteringConfig& config,
        RecalcReason& reason,
        bool abs_grads_in_sort_order = false,
        std::vector<uint32_t>* removed_indices = nullptr
    );

    void upload_fixel_TD();

    // Compact GPU operations
    size_t compact_active_indices();
    double calculate_all_gradients_compact(size_t num_active);  // returns roc_cost
    void sort_gradients_compact(size_t num_active);
    void gather_sorted_abs_gradients(size_t num_active);
    void pack_fixel_data();
    void reorder_streamlines();

    // Multi-GPU: sync dirty fixel TDs to helper GPU
    void sync_fixel_updates_to_helper(const std::vector<uint32_t>& dirty_fixels,
                                       const std::vector<double>& dirty_values);

    // ===== GPU0 (primary) device pointers =====
    int64_t* d_offsets_ = nullptr;
    uint32_t* d_fixel_indices_ = nullptr;
    float* d_segment_lengths_ = nullptr;
    float* d_contributions_ = nullptr;
    double* d_fixel_FOD_ = nullptr;
    double* d_fixel_TD_ = nullptr;
    double* d_fixel_weight_ = nullptr;
    uint8_t* d_active_ = nullptr;

    // Gradient arrays (GPU0)
    double* d_abs_gradients_ = nullptr;
    double* d_norm_gradients_ = nullptr;
    double* d_partial_results_ = nullptr;

    // Sorting buffers (GPU0)
    uint32_t* d_indices_ = nullptr;
    double* d_gradient_sorted_ = nullptr;
    uint32_t* d_indices_sorted_ = nullptr;
    void* d_temp_storage_ = nullptr;
    size_t temp_storage_bytes_ = 0;

    // Compact arrays (GPU0)
    uint32_t* d_active_indices_ = nullptr;
    uint32_t* d_iota_ = nullptr;
    size_t* d_num_selected_ = nullptr;
    void* d_select_temp_ = nullptr;
    size_t select_temp_bytes_ = 0;

    // Packed fixel data (GPU0)
    FixelPacked* d_fixel_packed_ = nullptr;

    // Incremental update buffers (GPU0)
    uint32_t* d_update_indices_ = nullptr;
    double* d_update_values_ = nullptr;
    size_t update_buf_size_ = 0;

    // ===== GPU1 (helper) device pointers =====
    int64_t* d1_offsets_ = nullptr;
    uint32_t* d1_fixel_indices_ = nullptr;
    float* d1_segment_lengths_ = nullptr;
    float* d1_contributions_ = nullptr;
    FixelPacked* d1_fixel_packed_ = nullptr;
    double* d1_abs_gradients_ = nullptr;
    double* d1_norm_gradients_ = nullptr;
    uint32_t* d1_active_indices_ = nullptr;
    // GPU1 gather buffer for abs_gradient transfer
    double* d1_gather_buf_ = nullptr;
    // Incremental update on helper
    uint32_t* d1_update_indices_ = nullptr;
    double* d1_update_values_ = nullptr;
    cudaStream_t helper_stream_ = nullptr;

    // Host data
    std::vector<int64_t> h_offsets_;
    std::vector<uint32_t> h_fixel_indices_;
    std::vector<float> h_segment_lengths_;
    std::vector<float> h_contributions_;
    std::vector<float> h_lengths_;
    std::vector<double> h_fixel_FOD_;
    std::vector<double> h_fixel_TD_;
    std::vector<double> h_fixel_weight_;
    std::vector<uint8_t> h_active_;

    // Non-contributing tracking (matches MRtrix)
    std::vector<uint32_t> noncontributing_indices_;
    double sum_contributing_length_ = 0.0;
    double sum_noncontributing_length_ = 0.0;
    double contributing_length_removed_ = 0.0;
    double noncontributing_length_removed_ = 0.0;
    size_t noncontributing_next_ = 0;

    // Global sums
    double FOD_sum_ = 0.0;
    double TD_sum_ = 0.0;

    // Streamline reorder mapping
    std::vector<uint32_t> reorder_map_;

    // State
    int device_id_;
    int helper_device_id_;
    MemoryConfig config_;
    size_t num_streamlines_ = 0;
    size_t num_fixels_ = 0;
    size_t num_edges_ = 0;
    size_t removed_count_ = 0;
    size_t tracks_remaining_ = 0;
    bool loaded_ = false;
    bool dual_gpu_ = false;
};

}  // namespace v28
}  // namespace GPU
}  // namespace SIFT

#endif  // SIFT_WRAPPER_V28_CUH

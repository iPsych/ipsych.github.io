// TCK File Reader for CUDA SIFT
// Standalone reader for MRtrix .tck track files
// Compatible with MRtrix3 track format

#ifndef TCK_READER_CUH
#define TCK_READER_CUH

#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <cmath>
#include <cstring>
#include <stdexcept>
#include <algorithm>
#include <iostream>
#include <array>

namespace MRtrix {

// 3D point type
struct Point3 {
    float x, y, z;

    Point3() : x(0), y(0), z(0) {}
    Point3(float x_, float y_, float z_) : x(x_), y(y_), z(z_) {}

    bool is_nan() const { return std::isnan(x); }
    bool is_inf() const { return std::isinf(x); }

    Point3 operator-(const Point3& other) const {
        return Point3(x - other.x, y - other.y, z - other.z);
    }

    float length() const {
        return std::sqrt(x*x + y*y + z*z);
    }
};

// Streamline type
using Streamline = std::vector<Point3>;

// Track properties from header
struct TrackProperties {
    std::string datatype;
    int64_t data_offset = 0;
    size_t count = 0;
    size_t total_count = 0;
    bool is_little_endian = true;
    bool is_float64 = false;
    float step_size = 0.0f;  // From tck header (mm)

    // Transform from scanner to voxel space (if needed)
    std::array<float, 9> transform_matrix = {1,0,0, 0,1,0, 0,0,1};
    std::array<float, 3> voxel_size = {1.0f, 1.0f, 1.0f};
    std::array<int, 3> dimensions = {0, 0, 0};
};

// TCK File Reader
class TCKReader {
public:
    TCKReader(const std::string& filename) : filename_(filename) {
        open();
    }

    ~TCKReader() {
        if (file_.is_open()) {
            file_.close();
        }
    }

    // Read header and return properties
    const TrackProperties& properties() const { return props_; }

    // Read a single streamline (returns false at end of file)
    bool read(Streamline& track) {
        track.clear();

        if (!file_.is_open() || file_.eof()) {
            return false;
        }

        while (file_.good()) {
            Point3 p = read_point();

            if (p.is_inf()) {
                // End of file marker
                return false;
            }

            if (p.is_nan()) {
                // End of track marker
                return !track.empty();
            }

            track.push_back(p);
        }

        return !track.empty();
    }

    // Read all streamlines (memory intensive!)
    std::vector<Streamline> read_all() {
        std::vector<Streamline> tracks;
        tracks.reserve(props_.count > 0 ? props_.count : 1000000);

        Streamline track;
        while (read(track)) {
            tracks.push_back(std::move(track));
            track.clear();
        }

        return tracks;
    }

    // Read streamlines with progress callback
    template<typename Callback>
    size_t read_with_progress(Callback callback, size_t report_interval = 1000000) {
        size_t count = 0;
        Streamline track;

        while (read(track)) {
            callback(track);
            ++count;

            if (count % report_interval == 0) {
                std::cerr << "  Read " << (count / 1000000) << "M streamlines...\r" << std::flush;
            }
            track.clear();
        }
        std::cerr << std::endl;

        return count;
    }

    // Reset to beginning of data
    void reset() {
        file_.clear();
        file_.seekg(props_.data_offset);
    }

private:
    std::string filename_;
    std::ifstream file_;
    TrackProperties props_;

    void open() {
        file_.open(filename_, std::ios::binary);
        if (!file_.is_open()) {
            throw std::runtime_error("Cannot open file: " + filename_);
        }

        parse_header();
        file_.seekg(props_.data_offset);
    }

    void parse_header() {
        std::string line;

        // First line should be "mrtrix tracks"
        std::getline(file_, line);
        if (line.find("mrtrix tracks") == std::string::npos) {
            throw std::runtime_error("Not a valid MRtrix tracks file");
        }

        // Read key-value pairs until END
        while (std::getline(file_, line)) {
            // Check for END marker
            if (line.substr(0, 3) == "END") {
                break;
            }

            // Parse key: value
            size_t colon = line.find(':');
            if (colon != std::string::npos) {
                std::string key = line.substr(0, colon);
                std::string value = line.substr(colon + 1);

                // Trim whitespace
                while (!value.empty() && (value[0] == ' ' || value[0] == '\t')) {
                    value = value.substr(1);
                }

                if (key == "datatype") {
                    props_.datatype = value;
                    props_.is_little_endian = (value.find("LE") != std::string::npos);
                    props_.is_float64 = (value.find("64") != std::string::npos);
                }
                else if (key == "file") {
                    // Format: ". offset"
                    size_t space = value.find(' ');
                    if (space != std::string::npos) {
                        props_.data_offset = std::stoll(value.substr(space + 1));
                    }
                }
                else if (key == "count") {
                    props_.count = std::stoull(value);
                }
                else if (key == "total_count") {
                    props_.total_count = std::stoull(value);
                }
                else if (key == "step_size") {
                    props_.step_size = std::stof(value);
                }
            }
        }

        if (props_.data_offset == 0) {
            throw std::runtime_error("Could not find data offset in header");
        }
    }

    Point3 read_point() {
        Point3 p;

        if (props_.is_float64) {
            double coords[3];
            file_.read(reinterpret_cast<char*>(coords), sizeof(coords));
            p.x = static_cast<float>(coords[0]);
            p.y = static_cast<float>(coords[1]);
            p.z = static_cast<float>(coords[2]);
        } else {
            float coords[3];
            file_.read(reinterpret_cast<char*>(coords), sizeof(coords));
            p.x = coords[0];
            p.y = coords[1];
            p.z = coords[2];
        }

        // Handle byte order if needed (assuming native for now)
        // TODO: Add byte swapping for cross-platform compatibility

        return p;
    }
};


// TCK File Writer
class TCKWriter {
public:
    TCKWriter(const std::string& filename, const TrackProperties& props = TrackProperties())
        : filename_(filename), props_(props), count_(0) {
        open();
    }

    ~TCKWriter() {
        close();
    }

    // Write a single streamline
    void write(const Streamline& track) {
        if (track.empty()) return;

        for (const auto& p : track) {
            write_point(p);
        }

        // Write delimiter (NaN)
        Point3 delimiter;
        delimiter.x = delimiter.y = delimiter.z = std::nanf("");
        write_point(delimiter);

        ++count_;
    }

    // Write streamlines with indices (for filtering)
    template<typename IndexIterator>
    void write_filtered(TCKReader& reader, IndexIterator indices_begin, IndexIterator indices_end) {
        // Sort indices for sequential reading
        std::vector<size_t> sorted_indices(indices_begin, indices_end);
        std::sort(sorted_indices.begin(), sorted_indices.end());

        reader.reset();
        Streamline track;
        size_t current_index = 0;
        size_t write_count = 0;
        auto it = sorted_indices.begin();

        while (reader.read(track) && it != sorted_indices.end()) {
            if (current_index == *it) {
                write(track);
                ++it;
                ++write_count;

                if (write_count % 1000000 == 0) {
                    std::cerr << "  Written " << (write_count / 1000000) << "M streamlines...\r" << std::flush;
                }
            }
            ++current_index;
            track.clear();
        }
        std::cerr << std::endl;
    }

    size_t count() const { return count_; }

private:
    std::string filename_;
    TrackProperties props_;
    std::ofstream file_;
    size_t count_;
    int64_t count_offset_;

    void open() {
        file_.open(filename_, std::ios::binary | std::ios::trunc);
        if (!file_.is_open()) {
            throw std::runtime_error("Cannot create file: " + filename_);
        }

        write_header();
    }

    void write_header() {
        // Write header in proper MRtrix format:
        // 1. First line (will be overwritten with spaces at the end)
        // 2. Properties (datatype, file offset)
        // 3. count (placeholder)
        // 4. END marker

        file_ << "mrtrix tracks\n";  // Will add spaces later
        file_ << "datatype: Float32LE\n";

        // Calculate data offset - reserve space for count/total_count/END
        // The format after count will be: "count: N\ntotal_count: M\nEND\n"
        int64_t header_start = file_.tellp();
        int64_t data_offset = header_start + 80;  // Reserve space for file:, count, total_count, END
        data_offset += (4 - (data_offset % 4)) % 4;  // Align to 4 bytes

        file_ << "file: . " << data_offset << "\n";
        file_ << "count: ";
        count_offset_ = file_.tellp();
        file_ << "0\n";  // Placeholder for count
        file_ << "total_count: 0\n";
        file_ << "END\n";

        // Seek to data start
        file_.seekp(data_offset);
    }

    void write_point(const Point3& p) {
        float coords[3] = {p.x, p.y, p.z};
        file_.write(reinterpret_cast<char*>(coords), sizeof(coords));
    }

    void close() {
        if (!file_.is_open()) return;

        // Write barrier (Inf)
        float barrier[3] = {INFINITY, INFINITY, INFINITY};
        file_.write(reinterpret_cast<char*>(barrier), sizeof(barrier));

        // Update count in header - overwrite from count position
        // Format: "count: N\ntotal_count: M\nEND\n"
        file_.seekp(count_offset_);
        file_ << count_ << "\n";
        file_ << "total_count: " << count_ << "\n";
        file_ << "END\n";

        file_.close();
    }
};

} // namespace MRtrix

#endif // TCK_READER_CUH

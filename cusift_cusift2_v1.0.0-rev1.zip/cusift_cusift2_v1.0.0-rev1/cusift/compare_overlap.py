#!/usr/bin/env python3
"""Compare CUDA SIFT output against gold standard sift_1mio.tck.
Hashes first 5 points of each streamline for identity matching."""

import struct
import sys
import hashlib

def read_tck_streamlines(path, max_read=0):
    """Read .tck file and return list of streamline hashes + count."""
    hashes = set()
    with open(path, 'rb') as f:
        # Read header
        header = b''
        while True:
            line = f.readline()
            header += line
            if b'END' in line:
                break

        # Find data offset - format is "file: . OFFSET"
        offset = None
        for line in header.split(b'\n'):
            if line.startswith(b'file:'):
                parts = line.decode().strip().split()
                offset = int(parts[-1])
                break

        f.seek(offset)

        count = 0
        current_points = []
        while True:
            data = f.read(12)  # 3 floats
            if len(data) < 12:
                break
            x, y, z = struct.unpack('<fff', data)

            if all(abs(v) == float('inf') for v in (x, y, z)):
                # End of file marker (NaN)
                break

            if any(v != v for v in (x, y, z)):
                # NaN = end of streamline
                if current_points:
                    # Hash first 5 points
                    key_points = current_points[:5]
                    h = hashlib.md5(str(key_points).encode()).hexdigest()
                    hashes.add(h)
                    count += 1
                current_points = []
                continue

            current_points.append((round(x, 4), round(y, 4), round(z, 4)))

    return hashes, count

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: compare_overlap.py <cuda_output.tck> <gold_standard.tck>")
        sys.exit(1)

    cuda_path = sys.argv[1]
    gold_path = sys.argv[2]

    print(f"Reading CUDA output: {cuda_path}")
    cuda_hashes, cuda_count = read_tck_streamlines(cuda_path)
    print(f"  Streamlines: {cuda_count}, unique hashes: {len(cuda_hashes)}")

    print(f"Reading gold standard: {gold_path}")
    gold_hashes, gold_count = read_tck_streamlines(gold_path)
    print(f"  Streamlines: {gold_count}, unique hashes: {len(gold_hashes)}")

    overlap = cuda_hashes & gold_hashes
    only_cuda = cuda_hashes - gold_hashes
    only_gold = gold_hashes - cuda_hashes

    print(f"\n=== Overlap Results ===")
    print(f"Overlap:         {len(overlap)}")
    print(f"As % of CUDA:    {100.0 * len(overlap) / len(cuda_hashes):.2f}%")
    print(f"As % of Gold:    {100.0 * len(overlap) / len(gold_hashes):.2f}%")
    print(f"Jaccard:         {100.0 * len(overlap) / len(cuda_hashes | gold_hashes):.2f}%")
    print(f"Only in CUDA:    {len(only_cuda)}")
    print(f"Only in Gold:    {len(only_gold)}")

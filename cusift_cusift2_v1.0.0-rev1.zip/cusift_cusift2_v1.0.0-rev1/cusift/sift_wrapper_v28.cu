// CUDA SIFT Wrapper Implementation - Version 28
// GPU-parallel gradient + CPU-sequential removal matching MRtrix exactly
//
// Architecture:
//   GPU: compute all gradients in parallel -> sort by normalized gradient
//   CPU: iterate sorted candidates 1-by-1, apply MRtrix acceptance checks
//   On check failure: GPU recomputes all gradients (new iteration)
//
// Dual-GPU support: gradient computation split across GPU0 + GPU1 via P2P.
//
// Matches MRtrix sifter.cpp perform_filtering() logic exactly.

#include "sift_wrapper_v28.cuh"
#include <cub/cub.cuh>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <numeric>
#include <algorithm>
#include <fstream>

namespace SIFT {
namespace GPU {
namespace v28 {

// =============================================================================
// CUDA Kernels
// =============================================================================

__global__ void kernel_init_indices(uint32_t* indices, size_t n) {
    size_t idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) indices[idx] = idx;
}

// Cost from packed fixel data (computes diff inline)
__global__ void kernel_calc_cost_packed(
    const FixelPacked* __restrict__ fixel_packed,
    double* partial_results,
    size_t num_fixels,
    double mu
) {
    extern __shared__ double sdata[];
    size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    double local_sum = 0.0;
    for (size_t i = tid; i < num_fixels; i += blockDim.x * gridDim.x) {
        FixelPacked fp = fixel_packed[i];
        double diff = fp.TD * mu - fp.FOD;
        local_sum += (diff * diff) * fp.weight;
    }
    sdata[threadIdx.x] = local_sum;
    __syncthreads();
    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (threadIdx.x < s) sdata[threadIdx.x] += sdata[threadIdx.x + s];
        __syncthreads();
    }
    if (threadIdx.x == 0) partial_results[blockIdx.x] = sdata[0];
}

// ROC cost from packed fixel data (computes diff inline, no separate d_fixel_diff_ needed)
__global__ void kernel_calc_roc_cost_packed(
    const FixelPacked* __restrict__ fixel_packed,
    double* partial_results,
    size_t num_fixels,
    double mu
) {
    extern __shared__ double sdata[];
    size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    double local_sum = 0.0;
    for (size_t i = tid; i < num_fixels; i += blockDim.x * gridDim.x) {
        FixelPacked fp = fixel_packed[i];
        double diff = fp.TD * mu - fp.FOD;
        local_sum += ((2.0 * fp.TD) * diff) * fp.weight;
    }
    sdata[threadIdx.x] = local_sum;
    __syncthreads();
    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (threadIdx.x < s) sdata[threadIdx.x] += sdata[threadIdx.x + s];
        __syncthreads();
    }
    if (threadIdx.x == 0) partial_results[blockIdx.x] = sdata[0];
}

// Pack SoA fixel arrays into 32-byte AoS struct for cache-friendly random access
__global__ void kernel_pack_fixels(
    const double* __restrict__ fixel_TD,
    const double* __restrict__ fixel_FOD,
    const double* __restrict__ fixel_weight,
    FixelPacked* __restrict__ fixel_packed,
    size_t num_fixels
) {
    size_t idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < num_fixels) {
        FixelPacked fp;
        fp.TD = fixel_TD[idx];
        fp.FOD = fixel_FOD[idx];
        fp.weight = fixel_weight[idx];
        fp._pad = 0.0;
        fixel_packed[idx] = fp;
    }
}

// Compact gradient kernel with packed fixel data (32-byte AoS: double TD, FOD, weight + pad)
// Single 32-byte read per fixel with inline diff computation
// Used on BOTH GPU0 and GPU1 (same kernel, different device pointers)
__global__ void kernel_calc_gradients_compact_packed(
    const uint32_t* active_indices,
    size_t num_active,
    const int64_t* offsets,
    const uint32_t* fixel_indices,
    const float* segment_lengths,
    const float* contributions,
    const FixelPacked* __restrict__ fixel_packed,
    double* abs_gradients,
    double* norm_gradients,
    double mu, double FOD_sum, double TD_sum, double roc_cost
) {
    size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= num_active) return;

    uint32_t tid = active_indices[i];
    float total_contribution = contributions[tid];
    int64_t start = offsets[tid];
    int64_t end = offsets[tid + 1];

    if (end <= start || total_contribution <= 0.0f) {
        abs_gradients[tid] = 1e30;
        norm_gradients[i] = 1e30;
        return;
    }

    double TD_sum_if_removed = TD_sum - total_contribution;
    if (TD_sum_if_removed <= 0.0) {
        abs_gradients[tid] = 1e30;
        norm_gradients[i] = 1e30;
        return;
    }
    double mu_new = FOD_sum / TD_sum_if_removed;
    double mu_change = mu_new - mu;

    double gradient = roc_cost * mu_change;

    for (int64_t e = start; e < end; ++e) {
        uint32_t f = fixel_indices[e];
        double length = segment_lengths[e];
        FixelPacked fp = fixel_packed[f];  // single 32-byte read

        double diff_f = fp.TD * mu - fp.FOD;  // inline diff (skip precompute + pack)
        double undo = (((2.0 * fp.TD) * diff_f) * fp.weight) * mu_change;
        double cost_old = (diff_f * diff_f) * fp.weight;
        double TD_f_new = max(fp.TD - length, 0.0);
        double diff_new = (TD_f_new * mu_new) - fp.FOD;
        double cost_new = (diff_new * diff_new) * fp.weight;

        gradient = gradient - undo + (cost_new - cost_old);
    }

    abs_gradients[tid] = gradient;
    norm_gradients[i] = gradient / total_contribution;
}

// Gather kernel: dst[i] = src[indices[i]]
__global__ void kernel_gather_double(
    const double* src, const uint32_t* indices, double* dst, size_t n
) {
    size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) dst[i] = src[indices[i]];
}

// Scatter kernels for incremental H2D updates
__global__ void kernel_scatter_fixel_TD(
    double* fixel_TD, const uint32_t* indices, const double* values, size_t n
) {
    size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) fixel_TD[indices[i]] = values[i];
}

__global__ void kernel_clear_active(
    uint8_t* active, const uint32_t* indices, size_t n
) {
    size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) active[indices[i]] = 0;
}

// Scatter-update TD field in packed fixel array (avoids full repack per iteration)
__global__ void kernel_scatter_packed_TD(
    FixelPacked* fixel_packed, const uint32_t* indices, const double* values, size_t n
) {
    size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) fixel_packed[indices[i]].TD = values[i];
}

// =============================================================================
// Class Implementation
// =============================================================================

bool SIFTerGPU_Sequential::load_double(
    const int64_t* offsets,
    const uint32_t* fixel_indices,
    const float* segment_lengths,
    const float* total_contributions,
    const float* total_lengths,
    const double* fixel_FOD,
    const double* fixel_TD,
    const double* fixel_weight,
    double precomputed_FOD_sum,
    double precomputed_TD_sum,
    size_t num_streamlines,
    size_t num_fixels,
    size_t num_edges
) {
    try {
        num_streamlines_ = num_streamlines;
        num_fixels_ = num_fixels;
        num_edges_ = num_edges;

        h_offsets_.assign(offsets, offsets + num_streamlines + 1);
        h_fixel_indices_.assign(fixel_indices, fixel_indices + num_edges);
        h_segment_lengths_.assign(segment_lengths, segment_lengths + num_edges);
        h_contributions_.assign(total_contributions, total_contributions + num_streamlines);
        h_lengths_.assign(total_lengths, total_lengths + num_streamlines);

        // Use double-precision FOD/weight directly (no float roundtrip)
        h_fixel_FOD_.assign(fixel_FOD, fixel_FOD + num_fixels);
        h_fixel_weight_.assign(fixel_weight, fixel_weight + num_fixels);

        // Use pre-computed TD from MRtrix (exact match)
        h_fixel_TD_.assign(fixel_TD, fixel_TD + num_fixels);

        // Use pre-computed global sums from MRtrix (exact match)
        FOD_sum_ = precomputed_FOD_sum;
        TD_sum_ = precomputed_TD_sum;

        h_active_.assign(num_streamlines, 1);
        tracks_remaining_ = num_streamlines;

        noncontributing_indices_.clear();
        sum_contributing_length_ = 0.0;
        sum_noncontributing_length_ = 0.0;

        for (size_t s = 0; s < num_streamlines; ++s) {
            int64_t start = h_offsets_[s];
            int64_t end = h_offsets_[s + 1];
            if (end > start && h_contributions_[s] > 0) {
                sum_contributing_length_ += h_lengths_[s];
            } else {
                sum_noncontributing_length_ += h_lengths_[s];
                noncontributing_indices_.push_back(s);
            }
        }
        std::random_shuffle(noncontributing_indices_.begin(), noncontributing_indices_.end());

        std::cout << "\n  Sequential SIFT GPU (v28 - double precision load)" << std::endl;
        std::cout << "  Streamlines: " << num_streamlines << std::endl;
        std::cout << "  Fixels: " << num_fixels << std::endl;
        std::cout << "  Edges: " << num_edges << " (ALL on GPU)" << std::endl;
        std::cout << "  FOD_sum: " << std::scientific << FOD_sum_ << std::endl;
        std::cout << "  TD_sum: " << std::scientific << TD_sum_ << std::endl;
        std::cout << "  Initial mu: " << calculate_mu() << std::endl;
        std::cout << "  Non-contributing: " << noncontributing_indices_.size()
                  << " (" << (100.0 * noncontributing_indices_.size() / num_streamlines) << "%)" << std::endl;

        // Reorder streamlines by first fixel index for L2 cache locality
        reorder_streamlines();

        allocate_gpu_memory();

        // Allocate helper GPU if requested
        if (helper_device_id_ >= 0) {
            allocate_helper_gpu();
        }

        loaded_ = true;
        return true;

    } catch (const std::exception& e) {
        std::cerr << "Error loading data: " << e.what() << std::endl;
        return false;
    }
}

void SIFTerGPU_Sequential::reorder_streamlines() {
    auto t0 = std::chrono::high_resolution_clock::now();

    // Compute sort key: first fixel index for each streamline
    std::vector<uint32_t> perm(num_streamlines_);
    std::iota(perm.begin(), perm.end(), 0);

    std::sort(perm.begin(), perm.end(), [&](uint32_t a, uint32_t b) {
        int64_t sa = h_offsets_[a], ea = h_offsets_[a + 1];
        int64_t sb = h_offsets_[b], eb = h_offsets_[b + 1];
        uint32_t ka = (ea > sa) ? h_fixel_indices_[sa] : UINT32_MAX;
        uint32_t kb = (eb > sb) ? h_fixel_indices_[sb] : UINT32_MAX;
        return ka < kb;
    });

    // Build reverse map: reorder_map_[new_idx] = original_idx
    reorder_map_ = perm;

    // Rebuild CSR arrays in new order
    std::vector<int64_t> new_offsets(num_streamlines_ + 1);
    std::vector<uint32_t> new_fixel_indices;
    std::vector<float> new_segment_lengths;
    std::vector<float> new_contributions(num_streamlines_);
    std::vector<float> new_lengths(num_streamlines_);
    std::vector<uint8_t> new_active(num_streamlines_);

    new_fixel_indices.reserve(num_edges_);
    new_segment_lengths.reserve(num_edges_);

    int64_t edge_offset = 0;
    for (size_t new_idx = 0; new_idx < num_streamlines_; ++new_idx) {
        uint32_t old_idx = perm[new_idx];
        new_offsets[new_idx] = edge_offset;

        int64_t s = h_offsets_[old_idx];
        int64_t e = h_offsets_[old_idx + 1];
        for (int64_t j = s; j < e; ++j) {
            new_fixel_indices.push_back(h_fixel_indices_[j]);
            new_segment_lengths.push_back(h_segment_lengths_[j]);
        }
        edge_offset += (e - s);

        new_contributions[new_idx] = h_contributions_[old_idx];
        new_lengths[new_idx] = h_lengths_[old_idx];
        new_active[new_idx] = h_active_[old_idx];
    }
    new_offsets[num_streamlines_] = edge_offset;

    // Swap into member arrays
    h_offsets_ = std::move(new_offsets);
    h_fixel_indices_ = std::move(new_fixel_indices);
    h_segment_lengths_ = std::move(new_segment_lengths);
    h_contributions_ = std::move(new_contributions);
    h_lengths_ = std::move(new_lengths);
    h_active_ = std::move(new_active);

    // Rebuild non-contributing list in new indices
    std::vector<uint32_t> old_to_new(num_streamlines_);
    for (size_t i = 0; i < num_streamlines_; ++i) {
        old_to_new[perm[i]] = i;
    }
    for (auto& idx : noncontributing_indices_) {
        idx = old_to_new[idx];
    }

    auto t1 = std::chrono::high_resolution_clock::now();
    double dt = std::chrono::duration<double>(t1 - t0).count();
    std::cout << "  Streamline reorder (by first fixel): " << std::fixed
              << std::setprecision(1) << dt << "s" << std::endl;
}

void SIFTerGPU_Sequential::allocate_gpu_memory() {
    cudaSetDevice(device_id_);

    size_t mem_offsets = (num_streamlines_ + 1) * sizeof(int64_t);
    size_t mem_edges_fi = num_edges_ * sizeof(uint32_t);
    size_t mem_edges_sl = num_edges_ * sizeof(float);
    size_t mem_contributions = num_streamlines_ * sizeof(float);
    size_t mem_active = num_streamlines_ * sizeof(uint8_t);
    size_t mem_gradients = num_streamlines_ * sizeof(double) * 2;  // abs + norm
    size_t mem_sorting = num_streamlines_ * (sizeof(uint32_t) * 2 + sizeof(double));
    size_t mem_partial = 1024 * sizeof(double);
    size_t mem_packed = num_fixels_ * sizeof(FixelPacked);
    size_t mem_fixels = num_fixels_ * sizeof(double) * 3;  // FOD, TD, weight

    size_t total_gpu = mem_offsets + mem_edges_fi + mem_edges_sl + mem_contributions +
                       mem_fixels + mem_active + mem_gradients + mem_sorting +
                       mem_partial + mem_packed;

    std::cout << "\n  GPU Memory Requirements (v28 - All data on GPU):" << std::endl;
    std::cout << "    Edge data on GPU: " << ((mem_edges_fi + mem_edges_sl) / 1e9) << " GB" << std::endl;
    std::cout << "    TOTAL GPU: " << (total_gpu / 1e9) << " GB" << std::endl;

    size_t free_mem, total_gpu_mem;
    cudaMemGetInfo(&free_mem, &total_gpu_mem);
    std::cout << "    Available GPU memory: " << (free_mem / 1e9) << " / "
              << (total_gpu_mem / 1e9) << " GB" << std::endl;

    if (total_gpu > free_mem) {
        std::cerr << "  WARNING: May not fit in GPU memory!" << std::endl;
    }

    auto check = [](cudaError_t err, const char* name) {
        if (err != cudaSuccess) {
            std::cerr << "CUDA alloc FAILED: " << name << " - " << cudaGetErrorString(err) << std::endl;
            return false;
        }
        return true;
    };

    bool ok = true;
    ok &= check(cudaMalloc(&d_offsets_, mem_offsets), "offsets");
    ok &= check(cudaMalloc(&d_fixel_indices_, mem_edges_fi), "fixel_indices");
    ok &= check(cudaMalloc(&d_segment_lengths_, mem_edges_sl), "segment_lengths");
    ok &= check(cudaMalloc(&d_contributions_, mem_contributions), "contributions");
    ok &= check(cudaMalloc(&d_fixel_FOD_, num_fixels_ * sizeof(double)), "fixel_FOD");
    ok &= check(cudaMalloc(&d_fixel_TD_, num_fixels_ * sizeof(double)), "fixel_TD");
    ok &= check(cudaMalloc(&d_fixel_weight_, num_fixels_ * sizeof(double)), "fixel_weight");
    ok &= check(cudaMalloc(&d_active_, mem_active), "active");
    ok &= check(cudaMalloc(&d_abs_gradients_, num_streamlines_ * sizeof(double)), "abs_gradients");
    ok &= check(cudaMalloc(&d_norm_gradients_, num_streamlines_ * sizeof(double)), "norm_gradients");
    ok &= check(cudaMalloc(&d_partial_results_, mem_partial), "partial_results");
    ok &= check(cudaMalloc(&d_indices_, num_streamlines_ * sizeof(uint32_t)), "indices");
    ok &= check(cudaMalloc(&d_gradient_sorted_, num_streamlines_ * sizeof(double)), "gradient_sorted");
    ok &= check(cudaMalloc(&d_indices_sorted_, num_streamlines_ * sizeof(uint32_t)), "indices_sorted");

    // CUB sort temp storage
    d_temp_storage_ = nullptr;
    temp_storage_bytes_ = 0;
    cub::DeviceRadixSort::SortPairs(d_temp_storage_, temp_storage_bytes_,
                                     d_norm_gradients_, d_gradient_sorted_,
                                     d_indices_, d_indices_sorted_,
                                     num_streamlines_);
    ok &= check(cudaMalloc(&d_temp_storage_, temp_storage_bytes_), "temp_storage");

    // Compact arrays for active-only processing
    ok &= check(cudaMalloc(&d_active_indices_, num_streamlines_ * sizeof(uint32_t)), "active_indices");
    ok &= check(cudaMalloc(&d_iota_, num_streamlines_ * sizeof(uint32_t)), "iota");
    ok &= check(cudaMalloc(&d_num_selected_, sizeof(size_t)), "num_selected");

    // CUB select temp storage
    d_select_temp_ = nullptr;
    select_temp_bytes_ = 0;
    cub::DeviceSelect::Flagged(d_select_temp_, select_temp_bytes_,
                                d_iota_, d_active_, d_active_indices_, d_num_selected_,
                                num_streamlines_);
    ok &= check(cudaMalloc(&d_select_temp_, select_temp_bytes_), "select_temp");

    // Packed fixel array for gradient kernel cache optimization
    ok &= check(cudaMalloc(&d_fixel_packed_, num_fixels_ * sizeof(FixelPacked)), "fixel_packed");

    // Incremental update buffers (for scatter uploads)
    update_buf_size_ = std::min(num_fixels_, (size_t)500000);
    ok &= check(cudaMalloc(&d_update_indices_, update_buf_size_ * sizeof(uint32_t)), "update_indices");
    ok &= check(cudaMalloc(&d_update_values_, update_buf_size_ * sizeof(double)), "update_values");

    if (!ok) {
        std::cerr << "  FATAL: GPU memory allocation failed!" << std::endl;
        return;
    }

    // Upload ALL data to GPU
    cudaMemcpy(d_offsets_, h_offsets_.data(), mem_offsets, cudaMemcpyHostToDevice);
    cudaMemcpy(d_fixel_indices_, h_fixel_indices_.data(), mem_edges_fi, cudaMemcpyHostToDevice);
    cudaMemcpy(d_segment_lengths_, h_segment_lengths_.data(), mem_edges_sl, cudaMemcpyHostToDevice);
    cudaMemcpy(d_contributions_, h_contributions_.data(), mem_contributions, cudaMemcpyHostToDevice);
    cudaMemcpy(d_fixel_FOD_, h_fixel_FOD_.data(), num_fixels_ * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemcpy(d_fixel_TD_, h_fixel_TD_.data(), num_fixels_ * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemcpy(d_fixel_weight_, h_fixel_weight_.data(), num_fixels_ * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemcpy(d_active_, h_active_.data(), mem_active, cudaMemcpyHostToDevice);

    // Initialize iota array on GPU (permanent [0,1,2,...,n-1])
    {
        int bs = 256;
        int nb = (num_streamlines_ + bs - 1) / bs;
        kernel_init_indices<<<nb, bs>>>(d_iota_, num_streamlines_);
        kernel_init_indices<<<nb, bs>>>(d_indices_, num_streamlines_);
        cudaDeviceSynchronize();
    }

    // Initial pack of fixel data (done once; TD updated incrementally via scatter)
    pack_fixel_data();

    std::cout << "  GPU memory allocated and data uploaded: SUCCESS" << std::endl;
}

void SIFTerGPU_Sequential::allocate_helper_gpu() {
    if (helper_device_id_ < 0) return;

    std::cout << "\n  Allocating helper GPU (device " << helper_device_id_ << ")..." << std::endl;

    // Enable P2P access between GPU0 and GPU1
    int can_access_0to1 = 0, can_access_1to0 = 0;
    cudaDeviceCanAccessPeer(&can_access_0to1, device_id_, helper_device_id_);
    cudaDeviceCanAccessPeer(&can_access_1to0, helper_device_id_, device_id_);
    std::cout << "    P2P access: GPU" << device_id_ << "->GPU" << helper_device_id_
              << " = " << can_access_0to1 << ", GPU" << helper_device_id_
              << "->GPU" << device_id_ << " = " << can_access_1to0 << std::endl;

    cudaSetDevice(device_id_);
    cudaDeviceEnablePeerAccess(helper_device_id_, 0);
    cudaSetDevice(helper_device_id_);
    cudaDeviceEnablePeerAccess(device_id_, 0);

    // Allocate on GPU1
    auto check = [](cudaError_t err, const char* name) {
        if (err != cudaSuccess) {
            std::cerr << "CUDA alloc FAILED (GPU1): " << name << " - " << cudaGetErrorString(err) << std::endl;
            return false;
        }
        return true;
    };

    size_t mem_offsets = (num_streamlines_ + 1) * sizeof(int64_t);
    size_t mem_edges_fi = num_edges_ * sizeof(uint32_t);
    size_t mem_edges_sl = num_edges_ * sizeof(float);
    size_t mem_contributions = num_streamlines_ * sizeof(float);

    bool ok = true;
    ok &= check(cudaMalloc(&d1_offsets_, mem_offsets), "d1_offsets");
    ok &= check(cudaMalloc(&d1_fixel_indices_, mem_edges_fi), "d1_fixel_indices");
    ok &= check(cudaMalloc(&d1_segment_lengths_, mem_edges_sl), "d1_segment_lengths");
    ok &= check(cudaMalloc(&d1_contributions_, mem_contributions), "d1_contributions");
    ok &= check(cudaMalloc(&d1_fixel_packed_, num_fixels_ * sizeof(FixelPacked)), "d1_fixel_packed");
    ok &= check(cudaMalloc(&d1_abs_gradients_, num_streamlines_ * sizeof(double)), "d1_abs_gradients");
    ok &= check(cudaMalloc(&d1_norm_gradients_, num_streamlines_ * sizeof(double)), "d1_norm_gradients");
    ok &= check(cudaMalloc(&d1_active_indices_, num_streamlines_ * sizeof(uint32_t)), "d1_active_indices");
    ok &= check(cudaMalloc(&d1_gather_buf_, num_streamlines_ * sizeof(double)), "d1_gather_buf");
    ok &= check(cudaMalloc(&d1_update_indices_, update_buf_size_ * sizeof(uint32_t)), "d1_update_indices");
    ok &= check(cudaMalloc(&d1_update_values_, update_buf_size_ * sizeof(double)), "d1_update_values");

    if (!ok) {
        std::cerr << "  FATAL: Helper GPU memory allocation failed!" << std::endl;
        cudaSetDevice(device_id_);
        return;
    }

    // Copy edge data from host to GPU1
    cudaMemcpy(d1_offsets_, h_offsets_.data(), mem_offsets, cudaMemcpyHostToDevice);
    cudaMemcpy(d1_fixel_indices_, h_fixel_indices_.data(), mem_edges_fi, cudaMemcpyHostToDevice);
    cudaMemcpy(d1_segment_lengths_, h_segment_lengths_.data(), mem_edges_sl, cudaMemcpyHostToDevice);
    cudaMemcpy(d1_contributions_, h_contributions_.data(), mem_contributions, cudaMemcpyHostToDevice);

    // Copy fixel_packed from GPU0 to GPU1 via P2P
    cudaMemcpyPeer(d1_fixel_packed_, helper_device_id_,
                    d_fixel_packed_, device_id_,
                    num_fixels_ * sizeof(FixelPacked));

    // Create helper stream on GPU1
    cudaStreamCreate(&helper_stream_);

    // Switch back to primary GPU
    cudaSetDevice(device_id_);

    dual_gpu_ = true;

    size_t free_mem, total_mem;
    cudaSetDevice(helper_device_id_);
    cudaMemGetInfo(&free_mem, &total_mem);
    cudaSetDevice(device_id_);

    std::cout << "    Helper GPU allocated: " << ((total_mem - free_mem) / 1e9)
              << " GB used, " << (free_mem / 1e9) << " GB free" << std::endl;
    std::cout << "    Dual-GPU mode: ENABLED" << std::endl;
}

void SIFTerGPU_Sequential::sync_fixel_updates_to_helper(
    const std::vector<uint32_t>& dirty_fixels,
    const std::vector<double>& dirty_values
) {
    if (!dual_gpu_ || dirty_fixels.empty()) return;

    size_t n = dirty_fixels.size();
    if (n > update_buf_size_) {
        // Fallback: full copy of packed fixels from GPU0 to GPU1
        cudaMemcpyPeer(d1_fixel_packed_, helper_device_id_,
                        d_fixel_packed_, device_id_,
                        num_fixels_ * sizeof(FixelPacked));
        return;
    }

    // Copy dirty indices and values to GPU1's update buffers
    cudaSetDevice(helper_device_id_);
    cudaMemcpy(d1_update_indices_, dirty_fixels.data(),
               n * sizeof(uint32_t), cudaMemcpyHostToDevice);
    cudaMemcpy(d1_update_values_, dirty_values.data(),
               n * sizeof(double), cudaMemcpyHostToDevice);

    // Scatter-update TD in GPU1's packed array
    int bsz = 256;
    int nb = (n + bsz - 1) / bsz;
    kernel_scatter_packed_TD<<<nb, bsz, 0, helper_stream_>>>(
        d1_fixel_packed_, d1_update_indices_, d1_update_values_, n);
    cudaStreamSynchronize(helper_stream_);

    cudaSetDevice(device_id_);
}

void SIFTerGPU_Sequential::free_memory() {
    auto safe_free = [](void*& p) { if (p) { cudaFree(p); p = nullptr; } };

    // GPU0
    cudaSetDevice(device_id_);
    safe_free((void*&)d_offsets_);
    safe_free((void*&)d_fixel_indices_);
    safe_free((void*&)d_segment_lengths_);
    safe_free((void*&)d_contributions_);
    safe_free((void*&)d_fixel_FOD_);
    safe_free((void*&)d_fixel_TD_);
    safe_free((void*&)d_fixel_weight_);
    safe_free((void*&)d_active_);
    safe_free((void*&)d_abs_gradients_);
    safe_free((void*&)d_norm_gradients_);
    safe_free((void*&)d_partial_results_);
    safe_free((void*&)d_indices_);
    safe_free((void*&)d_gradient_sorted_);
    safe_free((void*&)d_indices_sorted_);
    safe_free((void*&)d_temp_storage_);
    safe_free((void*&)d_active_indices_);
    safe_free((void*&)d_iota_);
    safe_free((void*&)d_num_selected_);
    safe_free((void*&)d_select_temp_);
    safe_free((void*&)d_fixel_packed_);
    safe_free((void*&)d_update_indices_);
    safe_free((void*&)d_update_values_);

    // GPU1
    if (dual_gpu_) {
        cudaSetDevice(helper_device_id_);
        safe_free((void*&)d1_offsets_);
        safe_free((void*&)d1_fixel_indices_);
        safe_free((void*&)d1_segment_lengths_);
        safe_free((void*&)d1_contributions_);
        safe_free((void*&)d1_fixel_packed_);
        safe_free((void*&)d1_abs_gradients_);
        safe_free((void*&)d1_norm_gradients_);
        safe_free((void*&)d1_active_indices_);
        safe_free((void*&)d1_gather_buf_);
        safe_free((void*&)d1_update_indices_);
        safe_free((void*&)d1_update_values_);
        if (helper_stream_) {
            cudaStreamDestroy(helper_stream_);
            helper_stream_ = nullptr;
        }
        cudaSetDevice(device_id_);
        dual_gpu_ = false;
    }
}

double SIFTerGPU_Sequential::calculate_cost_packed() {
    double mu = calculate_mu();
    int block_size = 256;
    int num_blocks = std::min(1024, (int)((num_fixels_ + block_size - 1) / block_size));
    kernel_calc_cost_packed<<<num_blocks, block_size, block_size * sizeof(double)>>>(
        d_fixel_packed_, d_partial_results_, num_fixels_, mu
    );
    std::vector<double> partial(num_blocks);
    cudaMemcpy(partial.data(), d_partial_results_, num_blocks * sizeof(double), cudaMemcpyDeviceToHost);
    double cost = 0.0;
    for (double p : partial) cost += p;
    return cost;
}

void SIFTerGPU_Sequential::upload_fixel_TD() {
    cudaMemcpy(d_fixel_TD_, h_fixel_TD_.data(), num_fixels_ * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemcpy(d_active_, h_active_.data(), num_streamlines_ * sizeof(uint8_t), cudaMemcpyHostToDevice);
}

// =============================================================================
// Compact GPU operations (active-only processing)
// =============================================================================

size_t SIFTerGPU_Sequential::compact_active_indices() {
    cub::DeviceSelect::Flagged(d_select_temp_, select_temp_bytes_,
                                d_iota_, d_active_, d_active_indices_, d_num_selected_,
                                num_streamlines_);
    size_t num_active = 0;
    cudaMemcpy(&num_active, d_num_selected_, sizeof(size_t), cudaMemcpyDeviceToHost);
    return num_active;
}

void SIFTerGPU_Sequential::pack_fixel_data() {
    int block_size = 256;
    int num_blocks = (num_fixels_ + block_size - 1) / block_size;
    kernel_pack_fixels<<<num_blocks, block_size>>>(
        d_fixel_TD_, d_fixel_FOD_, d_fixel_weight_,
        d_fixel_packed_, num_fixels_
    );
}

double SIFTerGPU_Sequential::calculate_all_gradients_compact(size_t num_active) {
    double mu = calculate_mu();

    // ROC cost from packed data on GPU0 (computes diff inline)
    int block_size = 256;
    int roc_blocks = std::min(1024, (int)((num_fixels_ + block_size - 1) / block_size));
    kernel_calc_roc_cost_packed<<<roc_blocks, block_size, block_size * sizeof(double)>>>(
        d_fixel_packed_, d_partial_results_, num_fixels_, mu
    );
    std::vector<double> partial(roc_blocks);
    cudaMemcpy(partial.data(), d_partial_results_, roc_blocks * sizeof(double), cudaMemcpyDeviceToHost);
    double roc_cost = 0.0;
    for (double p : partial) roc_cost += p;

    if (dual_gpu_ && num_active > 1) {
        // ---- Dual-GPU: split gradient work across GPU0 and GPU1 ----
        size_t gpu0_count = num_active / 2;
        size_t gpu1_count = num_active - gpu0_count;

        // Copy active_indices[gpu0_count..num_active-1] to GPU1's d1_active_indices_
        cudaMemcpyPeer(d1_active_indices_, helper_device_id_,
                        (uint8_t*)d_active_indices_ + gpu0_count * sizeof(uint32_t), device_id_,
                        gpu1_count * sizeof(uint32_t));

        // Launch gradient kernel on GPU0 (first half)
        int num_blocks_gpu0 = (gpu0_count + block_size - 1) / block_size;
        kernel_calc_gradients_compact_packed<<<num_blocks_gpu0, block_size>>>(
            d_active_indices_, gpu0_count,
            d_offsets_, d_fixel_indices_, d_segment_lengths_,
            d_contributions_, d_fixel_packed_,
            d_abs_gradients_, d_norm_gradients_,
            mu, FOD_sum_, TD_sum_, roc_cost
        );

        // Launch gradient kernel on GPU1 (second half)
        cudaSetDevice(helper_device_id_);
        int num_blocks_gpu1 = (gpu1_count + block_size - 1) / block_size;
        kernel_calc_gradients_compact_packed<<<num_blocks_gpu1, block_size, 0, helper_stream_>>>(
            d1_active_indices_, gpu1_count,
            d1_offsets_, d1_fixel_indices_, d1_segment_lengths_,
            d1_contributions_, d1_fixel_packed_,
            d1_abs_gradients_, d1_norm_gradients_,
            mu, FOD_sum_, TD_sum_, roc_cost
        );

        // Wait for GPU1 to finish
        cudaStreamSynchronize(helper_stream_);

        // Copy GPU1's abs_gradients results to GPU0
        // GPU1 writes abs_gradients[tid] at original streamline positions (sparse),
        // but we need ALL of them. Copy the full array and let GPU0's values coexist.
        // Actually: GPU1 only wrote to indices in active_indices[gpu0_count..num_active-1].
        // We need those specific entries. The simplest correct approach: copy the entire
        // abs_gradients array from GPU1 would overwrite GPU0's entries. Instead, we rely
        // on the fact that GPU0 and GPU1 write to DISJOINT original indices.
        // Copy full d1_abs_gradients_ over d_abs_gradients_ won't work (GPU1 has stale zeros
        // for GPU0's indices). We use a gather approach:
        // GPU1's norm_gradients[0..gpu1_count-1] -> GPU0's d_norm_gradients_[gpu0_count..num_active-1]
        cudaMemcpyPeer((uint8_t*)d_norm_gradients_ + gpu0_count * sizeof(double), device_id_,
                        d1_norm_gradients_, helper_device_id_,
                        gpu1_count * sizeof(double));

        // For abs_gradients: GPU1 wrote to original streamline index positions (sparse).
        // Gather on GPU1 into contiguous d1_gather_buf_, P2P copy to GPU0, scatter.
        cudaSetDevice(helper_device_id_);
        {
            int nb_g = (gpu1_count + block_size - 1) / block_size;
            kernel_gather_double<<<nb_g, block_size, 0, helper_stream_>>>(
                d1_abs_gradients_, d1_active_indices_, d1_gather_buf_, gpu1_count
            );
            cudaStreamSynchronize(helper_stream_);
        }

        // P2P copy contiguous gathered abs_gradient values to GPU0's d_gradient_sorted_ (as temp)
        cudaMemcpyPeer(d_gradient_sorted_, device_id_,
                       d1_gather_buf_, helper_device_id_,
                       gpu1_count * sizeof(double));

        // Scatter on GPU0: abs_gradients[active_indices[gpu0_count+i]] = gradient_sorted[i]
        cudaSetDevice(device_id_);
        {
            int nb_s = (gpu1_count + block_size - 1) / block_size;
            kernel_scatter_fixel_TD<<<nb_s, block_size>>>(
                d_abs_gradients_, d_active_indices_ + gpu0_count, d_gradient_sorted_, gpu1_count
            );
        }

        cudaSetDevice(device_id_);
        cudaDeviceSynchronize();

    } else {
        // ---- Single-GPU path ----
        int num_blocks = (num_active + block_size - 1) / block_size;
        kernel_calc_gradients_compact_packed<<<num_blocks, block_size>>>(
            d_active_indices_, num_active,
            d_offsets_, d_fixel_indices_, d_segment_lengths_,
            d_contributions_, d_fixel_packed_,
            d_abs_gradients_, d_norm_gradients_,
            mu, FOD_sum_, TD_sum_, roc_cost
        );
        cudaDeviceSynchronize();
    }

    return roc_cost;
}

void SIFTerGPU_Sequential::gather_sorted_abs_gradients(size_t num_active) {
    int block_size = 256;
    int num_blocks = (num_active + block_size - 1) / block_size;
    kernel_gather_double<<<num_blocks, block_size>>>(
        d_abs_gradients_, d_indices_sorted_, d_gradient_sorted_, num_active
    );
    // No sync needed - subsequent cudaMemcpy is implicitly synchronous
}

void SIFTerGPU_Sequential::sort_gradients_compact(size_t num_active) {
    // Sort double keys with active_indices as values
    // After sort: d_indices_sorted_ has original streamline indices in gradient order
    cub::DeviceRadixSort::SortPairs(d_temp_storage_, temp_storage_bytes_,
                                     d_norm_gradients_, d_gradient_sorted_,
                                     d_active_indices_, d_indices_sorted_,
                                     num_active);
    cudaDeviceSynchronize();
}

// =============================================================================
// CPU sequential removal (MRtrix-matching)
// =============================================================================

size_t SIFTerGPU_Sequential::sequential_removal_pass(
    const double* h_abs_gradients,
    const uint32_t* h_sorted_indices,
    size_t num_candidates,
    double current_cf,
    double current_roc_cf,
    const FilteringConfig& config,
    RecalcReason& reason,
    bool abs_grads_in_sort_order,
    std::vector<uint32_t>* removed_indices
) {
    size_t removed_this_iteration = 0;
    reason = UNDEFINED;

    // Iterate through sorted candidates
    for (size_t i = 0; i < num_candidates; ++i) {
        uint32_t candidate_index = h_sorted_indices[i];

        // Skip inactive
        if (!h_active_[candidate_index]) continue;

        // Check termination criteria
        if (config.term_number > 0 && tracks_remaining_ == config.term_number) {
            reason = TERM_COUNT;
            break;
        }
        if (config.term_mu > 0.0 && calculate_mu() > config.term_mu) {
            reason = TERM_MU;
            break;
        }

        // Non-contributing interleaving (matches MRtrix)
        if (sum_noncontributing_length_ > 0.0 &&
            noncontributing_next_ < noncontributing_indices_.size() &&
            (contributing_length_removed_ / sum_contributing_length_) >
            (noncontributing_length_removed_ / sum_noncontributing_length_)) {

            uint32_t nc_idx = noncontributing_indices_[noncontributing_next_];
            if (h_active_[nc_idx]) {
                noncontributing_length_removed_ += h_lengths_[nc_idx];
                h_active_[nc_idx] = 0;
                if (removed_indices) removed_indices->push_back(nc_idx);
                ++removed_this_iteration;
                --tracks_remaining_;
                ++removed_count_;
                ++noncontributing_next_;
                // Don't advance sorted iterator - retry this candidate
                --i;
                continue;
            }
            ++noncontributing_next_;
            --i;
            continue;
        }

        // Get the absolute gradient for this candidate
        double abs_gradient = abs_grads_in_sort_order ? h_abs_gradients[i] : h_abs_gradients[candidate_index];

        // Positive gradient = no more improvements (includes non-contributing with +1e30)
        if (abs_gradient >= 0.0) {
            reason = POS_GRADIENT;
            break;
        }

        // === MRtrix acceptance checks (sifter.cpp lines 200-266) ===

        float total_contribution = h_contributions_[candidate_index];
        if (total_contribution <= 0.0f) continue;

        double old_mu = calculate_mu();
        double new_mu = FOD_sum_ / (TD_sum_ - total_contribution);
        double mu_change = new_mu - old_mu;

        // Compute actual cost change using FRESH fixel data
        double this_actual_cf_change = current_roc_cf * mu_change;
        double quantisation = 0.0;

        int64_t start = h_offsets_[candidate_index];
        int64_t end = h_offsets_[candidate_index + 1];

        for (int64_t e = start; e < end; ++e) {
            uint32_t f = h_fixel_indices_[e];
            float length = h_segment_lengths_[e];
            double w = h_fixel_weight_[f];
            double TD_f = h_fixel_TD_[f];
            double FOD_f = h_fixel_FOD_[f];
            double diff_f = TD_f * old_mu - FOD_f;

            // Quantisation: match MRtrix calc_quantisation(mu, length)
            double manual_TD = (FOD_f / old_mu) + length;
            double q_diff = (manual_TD * old_mu) - FOD_f;
            quantisation += (q_diff * q_diff) * w;

            // Undo: match MRtrix get_d_cost_d_mu(mu) * mu_change
            double undo_change_mu_only = (((2.0 * TD_f) * diff_f) * w) * mu_change;

            // Cost change: get_cost_wo_track(new_mu, length) - get_cost(old_mu)
            double cost_old = (diff_f * diff_f) * w;
            double TD_f_new = std::max(TD_f - (double)length, 0.0);
            double diff_new = (TD_f_new * new_mu) - FOD_f;
            double cost_new = (diff_new * diff_new) * w;
            double change_remove_tck = cost_new - cost_old;

            this_actual_cf_change = this_actual_cf_change - undo_change_mu_only + change_remove_tck;
        }

        // Three acceptance criteria (MRtrix sifter.cpp line 226)
        double streamline_density_ratio = abs_gradient / (sum_contributing_length_ - contributing_length_removed_);
        double required_cf_change_ratio = -config.term_ratio * streamline_density_ratio * current_cf;
        double required_cf_change_quantisation = config.enforce_quantisation ?
            (-0.5 * quantisation * config.quantisation_factor) : 0.0;
        double this_nonlinearity = abs_gradient - this_actual_cf_change;
        if (config.nonlinearity_factor != 1.0 && config.nonlinearity_factor > 0.0)
            this_nonlinearity /= config.nonlinearity_factor;

        double threshold = std::min({required_cf_change_ratio,
                                     required_cf_change_quantisation,
                                     this_nonlinearity});

        if (this_actual_cf_change < threshold) {
            // ACCEPT: remove this streamline
            for (int64_t e = start; e < end; ++e) {
                uint32_t f = h_fixel_indices_[e];
                h_fixel_TD_[f] = std::max(h_fixel_TD_[f] - (double)h_segment_lengths_[e], 0.0);
            }
            TD_sum_ -= total_contribution;
            contributing_length_removed_ += h_lengths_[candidate_index];
            h_active_[candidate_index] = 0;
            if (removed_indices) removed_indices->push_back(candidate_index);
            ++removed_this_iteration;
            --tracks_remaining_;
            ++removed_count_;

        } else {
            // REJECT: determine reason and break for gradient recalculation
            if (this_actual_cf_change >= this_nonlinearity)
                reason = NONLINEARITY;
            else if (config.term_ratio > 0.0 && this_actual_cf_change >= required_cf_change_ratio)
                reason = TERM_RATIO;
            else
                reason = QUANTISATION;
            break;
        }
    }

    return removed_this_iteration;
}

void SIFTerGPU_Sequential::dump_sorted_gradients(const std::string& path, size_t K) {
    cudaSetDevice(device_id_);
    size_t num_active = compact_active_indices();
    calculate_all_gradients_compact(num_active);
    sort_gradients_compact(num_active);
    K = std::min(K, num_active);
    std::vector<double> g_norm(K), g_abs(K);
    std::vector<uint32_t> idx(K);
    // sorted keys (normalised gradients) must be read BEFORE the gather overwrites the buffer
    cudaMemcpy(g_norm.data(), d_gradient_sorted_, K * sizeof(double), cudaMemcpyDeviceToHost);
    cudaMemcpy(idx.data(), d_indices_sorted_, K * sizeof(uint32_t), cudaMemcpyDeviceToHost);
    gather_sorted_abs_gradients(num_active);
    std::vector<double> all_abs(num_streamlines_);
    cudaMemcpy(all_abs.data(), d_abs_gradients_, num_streamlines_ * sizeof(double), cudaMemcpyDeviceToHost);
    std::ofstream out(path);
    out << std::setprecision(17) << "rank,streamline,norm_gradient,abs_gradient\n";
    for (size_t i = 0; i < K; ++i) {
        uint32_t s = idx[i];
        out << i << "," << (reorder_map_.empty() ? s : reorder_map_[s]) << "," << g_norm[i] << "," << all_abs[s] << "\n";
    }
}

void SIFTerGPU_Sequential::device_memory_used_MB(double& primary, double& helper) const {
    size_t f = 0, t = 0;
    cudaSetDevice(device_id_);
    cudaMemGetInfo(&f, &t);
    primary = (t - f) / 1048576.0;
    helper = 0.0;
    if (dual_gpu_) { cudaSetDevice(helper_device_id_); cudaMemGetInfo(&f, &t); helper = (t - f) / 1048576.0; cudaSetDevice(device_id_); }
}

std::vector<size_t> SIFTerGPU_Sequential::get_surviving_indices() {
    std::vector<size_t> surviving;
    surviving.reserve(tracks_remaining_);
    for (size_t i = 0; i < num_streamlines_; ++i) {
        if (h_active_[i]) {
            surviving.push_back(reorder_map_.empty() ? i : reorder_map_[i]);
        }
    }
    // Sort by original index to maintain deterministic output order
    std::sort(surviving.begin(), surviving.end());
    return surviving;
}

FilteringResult SIFTerGPU_Sequential::filter_compact(const FilteringConfig& config) {
    auto start_time = std::chrono::high_resolution_clock::now();

    double initial_cost = calculate_cost_packed();
    double initial_mu = calculate_mu();

    std::cout << "\n=== Starting Compact SIFT Filtering (v28 - GPU compaction) ===" << std::endl;
    std::cout << "  Initial cost: " << std::scientific << initial_cost << std::endl;
    std::cout << "  Initial mu: " << initial_mu << std::endl;
    std::cout << "  Target count: " << config.term_number << std::endl;
    std::cout << "  Enforce quantisation: " << (config.enforce_quantisation ? "YES" : "NO") << std::endl;
    std::cout << "  Nonlinearity factor: " << config.nonlinearity_factor << std::endl;
    std::cout << "  Dual-GPU: " << (dual_gpu_ ? "YES" : "NO") << std::endl;

    // Initialize abs_gradients to 1e30 (inactive sentinel)
    {
        std::vector<double> init_grads(num_streamlines_, 1e30);
        cudaMemcpy(d_abs_gradients_, init_grads.data(),
                   num_streamlines_ * sizeof(double), cudaMemcpyHostToDevice);
    }

    // Pinned memory for faster D2H transfers (~2x PCIe bandwidth vs pageable)
    uint32_t* h_sorted_indices = nullptr;
    double* h_sorted_abs_gradients = nullptr;
    cudaMallocHost(&h_sorted_indices, num_streamlines_ * sizeof(uint32_t));
    cudaMallocHost(&h_sorted_abs_gradients, num_streamlines_ * sizeof(double));

    size_t iteration = 0;
    bool another_iteration = true;
    RecalcReason last_reason = UNDEFINED;
    bool enforce_quant = config.enforce_quantisation;
    size_t last_progress_removed = 0;

    FilteringConfig mutable_config = config;

    std::ofstream csv_out;
    if (!config.csv_path.empty()) {
        csv_out.open(config.csv_path);
        csv_out << "#Iteration,Removed,Total_removed,Remaining,Cost,TD,Mu,Reason,NumActive,GPU_s,CPU_s" << std::endl;
        csv_out << std::setprecision(17);
    }

    size_t last_iter_removed = 200000;  // Start generous, adapt dynamically

    // CUDA events for detailed timing (every 1000th iteration)
    cudaEvent_t t0, t1;
    cudaEventCreate(&t0);
    cudaEventCreate(&t1);

    do {
        ++iteration;
        auto iter_start = std::chrono::high_resolution_clock::now();
        bool do_timing = (iteration % 1000 == 1);
        float ms_compact = 0, ms_grad = 0, ms_sort = 0;
        float ms_d2h = 0, ms_upload = 0;

        // Step 1: Compact active indices
        if (do_timing) cudaEventRecord(t0);
        size_t num_active = compact_active_indices();
        if (do_timing) { cudaEventRecord(t1); cudaEventSynchronize(t1); cudaEventElapsedTime(&ms_compact, t0, t1); }

        // Step 2: Compute gradients only for active streamlines (also returns roc_cost)
        if (do_timing) cudaEventRecord(t0);
        double current_roc_cf = calculate_all_gradients_compact(num_active);
        if (do_timing) { cudaEventRecord(t1); cudaEventSynchronize(t1); cudaEventElapsedTime(&ms_grad, t0, t1); }

        // Step 3: Compute cost only if needed (term_ratio > 0 or CSV enabled)
        double current_cf = 0.0;
        if (config.term_ratio > 0.0 || csv_out.is_open()) {
            current_cf = calculate_cost_packed();
        }

        // Step 4: Sort only active streamlines
        if (do_timing) cudaEventRecord(t0);
        sort_gradients_compact(num_active);
        if (do_timing) { cudaEventRecord(t1); cudaEventSynchronize(t1); cudaEventElapsedTime(&ms_sort, t0, t1); }

        // Step 5: Gather abs_gradients, download top-K (adaptive based on last removal count)
        if (do_timing) cudaEventRecord(t0);
        size_t download_count = std::min(num_active, std::max((size_t)2000, last_iter_removed * 4));
        gather_sorted_abs_gradients(download_count);
        cudaMemcpy(h_sorted_indices, d_indices_sorted_,
                   download_count * sizeof(uint32_t), cudaMemcpyDeviceToHost);
        cudaMemcpy(h_sorted_abs_gradients, d_gradient_sorted_,
                   download_count * sizeof(double), cudaMemcpyDeviceToHost);
        if (do_timing) { cudaEventRecord(t1); cudaEventSynchronize(t1); cudaEventElapsedTime(&ms_d2h, t0, t1); }

        auto gpu_end = std::chrono::high_resolution_clock::now();
        double gpu_time = std::chrono::duration<double>(gpu_end - iter_start).count();

        // Step 6: CPU sequential removal - track removed streamlines
        RecalcReason reason = UNDEFINED;
        mutable_config.enforce_quantisation = enforce_quant;
        std::vector<uint32_t> removed_sids;
        removed_sids.reserve(1024);
        size_t removed_this_iter = sequential_removal_pass(
            h_sorted_abs_gradients,
            h_sorted_indices,
            download_count,
            current_cf,
            current_roc_cf,
            mutable_config,
            reason,
            true,  // abs_grads are in sort order
            &removed_sids
        );

        // If we exhausted downloaded candidates without a stopping condition,
        // download the rest and continue (rare edge case in early iterations)
        if (reason == UNDEFINED && removed_this_iter > 0 && download_count < num_active) {
            size_t remaining = num_active - download_count;
            gather_sorted_abs_gradients(num_active);  // re-gather full set
            cudaMemcpy(h_sorted_indices, d_indices_sorted_ + download_count,
                       remaining * sizeof(uint32_t), cudaMemcpyDeviceToHost);
            cudaMemcpy(h_sorted_abs_gradients, d_gradient_sorted_ + download_count,
                       remaining * sizeof(double), cudaMemcpyDeviceToHost);
            size_t extra = sequential_removal_pass(
                h_sorted_abs_gradients,
                h_sorted_indices,
                remaining,
                current_cf,
                current_roc_cf,
                mutable_config,
                reason,
                true,
                &removed_sids
            );
            removed_this_iter += extra;
        }

        last_iter_removed = std::max(removed_this_iter, (size_t)1);

        auto cpu_end = std::chrono::high_resolution_clock::now();
        double cpu_time = std::chrono::duration<double>(cpu_end - gpu_end).count();

        // Incremental upload: only update changed fixels and removed streamlines
        if (do_timing) cudaEventRecord(t0);
        if (!removed_sids.empty()) {
            // Collect unique dirty fixels from removed streamlines
            static std::vector<bool> fixel_dirty;
            if (fixel_dirty.size() != num_fixels_) fixel_dirty.resize(num_fixels_, false);
            std::vector<uint32_t> dirty_fixels;
            std::vector<double> dirty_values;

            for (uint32_t sid : removed_sids) {
                int64_t s = h_offsets_[sid];
                int64_t e = h_offsets_[sid + 1];
                for (int64_t ee = s; ee < e; ++ee) {
                    uint32_t f = h_fixel_indices_[ee];
                    if (!fixel_dirty[f]) {
                        fixel_dirty[f] = true;
                        dirty_fixels.push_back(f);
                    }
                }
            }
            for (size_t j = 0; j < dirty_fixels.size(); ++j) {
                dirty_values.push_back(h_fixel_TD_[dirty_fixels[j]]);
                fixel_dirty[dirty_fixels[j]] = false;
            }

            if (dirty_fixels.size() <= update_buf_size_) {
                // Scatter fixel_TD updates on GPU0
                cudaMemcpy(d_update_indices_, dirty_fixels.data(),
                           dirty_fixels.size() * sizeof(uint32_t), cudaMemcpyHostToDevice);
                cudaMemcpy(d_update_values_, dirty_values.data(),
                           dirty_fixels.size() * sizeof(double), cudaMemcpyHostToDevice);
                int bsz = 256;
                int nb = (dirty_fixels.size() + bsz - 1) / bsz;
                kernel_scatter_fixel_TD<<<nb, bsz>>>(
                    d_fixel_TD_, d_update_indices_, d_update_values_, dirty_fixels.size());
                // Also update TD in packed array (avoids full repack)
                kernel_scatter_packed_TD<<<nb, bsz>>>(
                    d_fixel_packed_, d_update_indices_, d_update_values_, dirty_fixels.size());

                // Clear active flags for removed streamlines
                cudaMemcpy(d_update_indices_, removed_sids.data(),
                           removed_sids.size() * sizeof(uint32_t), cudaMemcpyHostToDevice);
                nb = (removed_sids.size() + bsz - 1) / bsz;
                kernel_clear_active<<<nb, bsz>>>(
                    d_active_, d_update_indices_, removed_sids.size());

                // Sync fixel TD updates to helper GPU
                sync_fixel_updates_to_helper(dirty_fixels, dirty_values);
            } else {
                upload_fixel_TD();
                pack_fixel_data();  // Full repack after full upload
                if (dual_gpu_) {
                    // Full copy of packed fixels to helper GPU
                    cudaMemcpyPeer(d1_fixel_packed_, helper_device_id_,
                                    d_fixel_packed_, device_id_,
                                    num_fixels_ * sizeof(FixelPacked));
                }
            }
        }
        if (do_timing) { cudaEventRecord(t1); cudaEventSynchronize(t1); cudaEventElapsedTime(&ms_upload, t0, t1); }

        // Progress reporting
        if (removed_count_ - last_progress_removed >= config.progress_interval || removed_this_iter == 0) {
            double mu = calculate_mu();
            auto now = std::chrono::high_resolution_clock::now();
            double elapsed = std::chrono::duration<double>(now - start_time).count();

            const char* reason_str = "?";
            switch (reason) {
                case NONLINEARITY: reason_str = "Nonlinearity"; break;
                case QUANTISATION: reason_str = "Quantisation"; break;
                case TERM_COUNT:   reason_str = "TermCount"; break;
                case TERM_RATIO:   reason_str = "TermRatio"; break;
                case TERM_MU:      reason_str = "TermMu"; break;
                case POS_GRADIENT: reason_str = "PosGrad"; break;
                default:           reason_str = "Undefined"; break;
            }

            std::cout << "  Iter " << std::setw(5) << iteration
                      << " | removed " << std::setw(7) << removed_this_iter
                      << " | total " << std::setw(9) << removed_count_
                      << " | remaining " << std::setw(9) << tracks_remaining_
                      << " | active " << std::setw(9) << num_active
                      << " | mu " << std::fixed << std::setprecision(6) << mu
                      << " | GPU " << std::fixed << std::setprecision(2) << gpu_time << "s"
                      << " | CPU " << cpu_time << "s"
                      << " | " << reason_str
                      << " | elapsed " << std::setprecision(0) << elapsed << "s"
                      << std::endl;
            last_progress_removed = removed_count_;
        }
        if (do_timing) {
            std::cout << "    [BREAKDOWN iter=" << iteration << " active=" << num_active
                      << "] compact=" << std::fixed << std::setprecision(1) << ms_compact
                      << "ms grad=" << ms_grad << "ms sort=" << ms_sort
                      << "ms gather+D2H=" << ms_d2h << "ms H2D=" << ms_upload
                      << "ms CPU=" << (cpu_time*1000.0) << "ms" << std::endl;
        }

        if (csv_out.is_open()) {
            const char* reason_str2 = "?";
            switch (reason) {
                case NONLINEARITY: reason_str2 = "Non-linearity"; break;
                case QUANTISATION: reason_str2 = "Quantisation"; break;
                case TERM_COUNT:   reason_str2 = "Term-count"; break;
                case TERM_RATIO:   reason_str2 = "Term-ratio"; break;
                case TERM_MU:      reason_str2 = "Term-mu"; break;
                case POS_GRADIENT: reason_str2 = "Pos-gradient"; break;
                default:           reason_str2 = "Undefined"; break;
            }
            auto now = std::chrono::high_resolution_clock::now();
            double gpu_t = std::chrono::duration<double>(gpu_end - iter_start).count();
            double cpu_t = std::chrono::duration<double>(cpu_end - gpu_end).count();
            csv_out << iteration << "," << removed_this_iter << "," << removed_count_
                    << "," << tracks_remaining_ << "," << current_cf << "," << TD_sum_
                    << "," << calculate_mu() << "," << reason_str2
                    << "," << num_active << "," << gpu_t << "," << cpu_t << std::endl;
        }

        last_reason = reason;

        if (reason == TERM_COUNT || reason == TERM_MU) {
            another_iteration = false;
        } else if (removed_this_iter == 0) {
            if (enforce_quant && (config.term_number > 0 || config.term_ratio > 0.0 || config.term_mu > 0.0)) {
                std::cout << "  WARNING: Reached quantisation limit but termination criterion not met." << std::endl;
                std::cout << "  Disabling quantisation check." << std::endl;
                enforce_quant = false;
            } else {
                another_iteration = false;
            }
        }

    } while (another_iteration);

    double final_cost = calculate_cost_packed();
    double final_mu = calculate_mu();
    auto end_time = std::chrono::high_resolution_clock::now();
    double elapsed = std::chrono::duration<double>(end_time - start_time).count();

    const char* term_str = "Unknown";
    switch (last_reason) {
        case NONLINEARITY: term_str = "Nonlinearity"; break;
        case QUANTISATION: term_str = "Quantisation"; break;
        case TERM_COUNT:   term_str = "Target count reached"; break;
        case TERM_RATIO:   term_str = "Term ratio"; break;
        case TERM_MU:      term_str = "Target mu reached"; break;
        case POS_GRADIENT: term_str = "Positive gradient"; break;
        default:           term_str = "Undefined"; break;
    }

    std::cout << "\n=== Compact Filtering Complete ===" << std::endl;
    std::cout << "  Termination: " << term_str << std::endl;
    std::cout << "  Iterations: " << iteration << std::endl;
    std::cout << "  Total removed: " << removed_count_ << std::endl;
    std::cout << "  Remaining: " << tracks_remaining_ << std::endl;
    std::cout << "  Final cost: " << std::scientific << final_cost << std::endl;
    std::cout << "  Final mu: " << final_mu << std::endl;
    std::cout << "  Time: " << std::fixed << std::setprecision(1) << elapsed << " seconds" << std::endl;

    // Free timing events and pinned memory
    cudaEventDestroy(t0);
    cudaEventDestroy(t1);
    cudaFreeHost(h_sorted_indices);
    cudaFreeHost(h_sorted_abs_gradients);

    return FilteringResult{
        removed_count_,
        tracks_remaining_,
        initial_cost,
        final_cost,
        elapsed,
        final_mu,
        iteration,
        last_reason
    };
}

}  // namespace v28
}  // namespace GPU
}  // namespace SIFT

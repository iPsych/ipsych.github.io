# cuSIFT / cuSIFT2 — GPU-accelerated SIFT and SIFT2 tractogram filtering

CUDA implementations of the spherical-deconvolution informed filtering of tractograms algorithms
SIFT (Smith et al. 2013) and SIFT2 (Smith et al. 2015), validated against the MRtrix3 reference
implementations (`tcksift`, `tcksift2`). This repository accompanies the paper
*GPU-accelerated spherical-deconvolution informed filtering of tractograms for quantitative diffusion MRI connectomics*
(Kang & Ryu, Medical Engineering & Physics, under revision; manuscript MEP-100700).

Release used for the paper: **v1.0.0-rev1** (every number in the paper was produced with this tag; source md5 sums
are listed in `benchmark/results/environment.txt`).

## Layout

| Directory | Content |
|---|---|
| `cusift/` | GPU SIFT: `sift_wrapper_v28.cu/.cuh` (kernels, sort, host removal loop), `sift_gpu_main.cu` (driver), `tck_reader.cuh`, `run_cuda_sift.sh` (drop-in wrapper with `tcksift` arguments) |
| `cusift2/` | GPU SIFT2: `sift2_kernels.cu/.cuh`, `sift2_cuda.cu` (driver), `run_cuda_sift2.sh` |
| `mrtrix3_patch/` | The 96-line patch that adds `-output_mapping` to MRtrix3 `tcksift` (against commit `a488fa32`, v3.0.8) |
| `benchmark/scripts/` | Benchmark campaign used in the paper (`campaign.sh` and the per-run scripts; `common.sh` holds all paths) |
| `benchmark/analysis/` | Analysis: exact streamline-set comparison, weight statistics, mapping verification, connectome comparison, table/figure generation |
| `benchmark/results/` | Derived outputs (run records, comparisons, connectome metrics, ADNI summaries, `extra.json` with every macro used in the paper, `environment.txt`) |
| `bin/` | Pre-built Linux x86-64 binaries (`sift_gpu`, `sift2_cuda` = v3, CUDA 12 / sm_86; md5 sums in `bin/MD5SUMS`) for reviewers who do not wish to compile |

## Two-stage pipeline

1. **Stage 1 (CPU, MRtrix3 reference code):** `tcksift -output_mapping mapping.bin -nofilter ...` builds the
   streamline-to-fixel mapping exactly as the reference does and serialises it (CSR format, see `sift_gpu_main.cu::load_mapping`).
   No computation of the reference code is changed by the patch; when `-output_mapping` is not given the patched command is
   identical to stock `tcksift`.
2. **Stage 2 (GPU):** `sift_gpu` / `sift2_cuda` load the mapping, run the optimisation on the GPU and write the output in the
   reference format (`.tck` for SIFT, per-streamline weight text file for SIFT2).

The wrapper scripts run both stages with `tcksift`/`tcksift2`-compatible arguments:

```bash
./cusift/run_cuda_sift.sh   -act 5tt.mif -term_number 1000000 tracks.tck wmfod.mif sift_gpu.tck -force
./cusift2/run_cuda_sift2.sh -act 5tt.mif tracks.tck wmfod.mif sift2_gpu_weights.txt -force
```

## Building

Requirements: NVIDIA GPU with compute capability 8.6 (RTX 3090; adjust `GPU_ARCH` in the Makefiles for other devices),
CUDA Toolkit 12.2 (CUB is bundled), GCC 11, and an MRtrix3 build with the patch applied.

```bash
# MRtrix3 with the patch
git clone https://github.com/MRtrix3/mrtrix3 && cd mrtrix3 && git checkout a488fa32
git apply ../mrtrix3_patch/mrtrix3_output_mapping.patch && ./configure && ./build bin/tcksift bin/tcksift2
# GPU programs
cd cusift  && make      # -> sift_gpu
cd cusift2 && make      # -> sift2_cuda
```

Build flags: `-O3 -std=c++17 -arch=sm_86`, no fast-math. All SIFT/SIFT2 arithmetic is double precision.

## Program options (instrumentation only; the computation is unaffected)

`sift_gpu <mapping.bin> <tracks.tck> <out.tck> <target_count> [--gpu0 i] [--gpu1 j|-1] [--csv per_iteration.csv] [--timing_json t.json] [--dump_gradients g.csv]`

`sift2_cuda <mapping.bin> <out_weights.txt> [--csv per_iteration.csv] [--timing_json t.json] [--newton_dump prefix] [--reorder length|none|key:<file>] [tcksift2 parameters: --reg_tv ...]`

`--reorder length` (default since v3, the version reported in the paper) physically sorts the streamlines by fixel count before upload, which reduces warp divergence in the Newton kernel and roughly halves its runtime; it does not change the result. `--reorder none` reproduces the unsorted layout whose timings are given in Supplementary Table S5.

## Reproducing the benchmark

`benchmark/scripts/campaign.sh P1 P2 P3 P6 P4 P5 P7 P8` runs the benchmark-tier campaign (see the script for the phases;
paths are set in `common.sh`); `campaign2.sh` (thread-scaling floors, size sweep, connectomes), `campaign3.sh` (v3 re-timing,
reorder experiment, re-seeded tractograms), `campaign_adni.sh` / `campaign_adni88.sh` (ADNI agreement tiers) and
`adni_cohort_preproc.sh` (ADNI preprocessing) are the later campaigns. Every run writes a `.json` record, the timestamped stderr of the command, the per-iteration
CSV and the output; `benchmark/analysis/analyze.py` collects them and `make_tables.py`, `connectome.py summary`, `adni88_summary.py` and the `fig_*.py` scripts generate every
table, number and figure of the paper (`build_docs.sh` runs the whole chain).

## Licence

The CUDA implementations, scripts, analysis code and derived outputs are released under the Creative Commons
Attribution-NonCommercial 4.0 International licence (CC BY-NC 4.0; see `LICENSE`): free for research and other
non-commercial use with attribution; commercial use requires permission from the authors.
The MRtrix3 patch (`mrtrix3_patch/`) modifies files of MRtrix3 and is therefore distributed under MRtrix3's licence,
the Mozilla Public License 2.0 (`mrtrix3_patch/LICENSE-MPL-2.0`).

## Citation

See `CITATION.cff`.

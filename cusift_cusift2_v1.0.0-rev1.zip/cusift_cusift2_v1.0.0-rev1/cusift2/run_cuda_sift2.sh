#!/bin/bash
# CUDA SIFT2 - Drop-in replacement for MRtrix tcksift2
#
# Usage (same as tcksift2):
#   ./run_cuda_sift2.sh [options] <in_tracks> <in_fod> <out_weights>
#
# Examples:
#   ./run_cuda_sift2.sh -act 5tt_nocoreg.mif tracks_10mio.tck wmfod_norm.mif sift2_weights.txt
#   ./run_cuda_sift2.sh -act 5tt_nocoreg.mif -reg_tv 0.1 tracks_10mio.tck wmfod_norm.mif sift2_weights.txt -force

set -euo pipefail

# ---- Default configuration ----
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MRTRIX_BIN="${MRTRIX_BIN:-$(dirname "$SCRIPT_DIR")/mrtrix3/bin}"
CUDA_BINARY="${SCRIPT_DIR}/sift2_cuda"
ACT_FILE=""
FORCE=false
NTHREADS=""
MAPPING_FILE=""
REUSE_MAPPING=false

# SIFT2-specific options (passed to CUDA binary)
REG_TIK=""
REG_TV=""
MIN_TD_FRAC=""
MIN_ITERS=""
MAX_ITERS=""
MAX_COEFF_STEP=""
MIN_CF_DECREASE=""

# ---- Parse arguments (tcksift2-compatible) ----
POSITIONAL=()

while [ $# -gt 0 ]; do
    case "$1" in
        -act)           ACT_FILE="$2"; shift 2 ;;
        -nthreads)      NTHREADS="$2"; shift 2 ;;
        -force)         FORCE=true; shift ;;
        -mapping)       MAPPING_FILE="$2"; shift 2 ;;
        -reuse_mapping) REUSE_MAPPING=true; shift ;;
        -reg_tikhonov)  REG_TIK="$2"; shift 2 ;;
        -reg_tv)        REG_TV="$2"; shift 2 ;;
        -min_td_frac)   MIN_TD_FRAC="$2"; shift 2 ;;
        -min_iters)     MIN_ITERS="$2"; shift 2 ;;
        -max_iters)     MAX_ITERS="$2"; shift 2 ;;
        -max_coeff_step) MAX_COEFF_STEP="$2"; shift 2 ;;
        -min_cf_decrease) MIN_CF_DECREASE="$2"; shift 2 ;;
        -help|--help)
            echo "CUDA SIFT2 - Drop-in replacement for MRtrix tcksift2"
            echo ""
            echo "Usage: $0 [options] <in_tracks> <in_fod> <out_weights>"
            echo ""
            echo "tcksift2-compatible options:"
            echo "  -act <5tt.mif>        5TT image for anatomical constraint"
            echo "  -nthreads <N>         CPU threads (passed to MRtrix mapping step)"
            echo "  -force                Overwrite output files"
            echo "  -reg_tikhonov <val>   Tikhonov regularization coefficient (default: 0.0)"
            echo "  -reg_tv <val>         TV regularization coefficient (default: 0.1)"
            echo "  -min_td_frac <val>    Min TD fraction for fixel exclusion (default: 0.10)"
            echo "  -min_iters <N>        Minimum iterations (default: 10)"
            echo "  -max_iters <N>        Maximum iterations (default: 1000)"
            echo ""
            echo "CUDA-specific options:"
            echo "  -mapping <file.bin>   Custom path for mapping binary"
            echo "  -reuse_mapping        Reuse existing mapping file"
            exit 0
            ;;
        -*)
            echo "WARNING: Unknown option '$1' ignored" >&2
            shift
            ;;
        *)
            POSITIONAL+=("$1")
            shift
            ;;
    esac
done

# ---- Validate positional arguments ----
if [ ${#POSITIONAL[@]} -ne 3 ]; then
    echo "ERROR: Expected 3 positional arguments: <in_tracks> <in_fod> <out_weights>"
    echo "Usage: $0 [options] <in_tracks> <in_fod> <out_weights>"
    exit 1
fi

TRACKS_FILE="${POSITIONAL[0]}"
FOD_FILE="${POSITIONAL[1]}"
OUTPUT_FILE="${POSITIONAL[2]}"

# ---- Validate inputs ----
for f in "$TRACKS_FILE" "$FOD_FILE"; do
    if [ ! -f "$f" ]; then
        echo "ERROR: File not found: $f"
        exit 1
    fi
done

if [ -n "$ACT_FILE" ] && [ ! -f "$ACT_FILE" ]; then
    echo "ERROR: ACT file not found: $ACT_FILE"
    exit 1
fi

if [ -f "$OUTPUT_FILE" ] && [ "$FORCE" = false ]; then
    echo "ERROR: Output file already exists: $OUTPUT_FILE (use -force to overwrite)"
    exit 1
fi

if [ ! -f "$CUDA_BINARY" ]; then
    echo "ERROR: CUDA binary not found: $CUDA_BINARY"
    echo "Run 'make' in $SCRIPT_DIR first."
    exit 1
fi

TCKSIFT_BIN="${MRTRIX_BIN}/tcksift"
if [ ! -f "$TCKSIFT_BIN" ]; then
    echo "ERROR: Modified tcksift not found at: $TCKSIFT_BIN"
    echo "Set MRTRIX_BIN environment variable to point to the MRtrix3 bin directory."
    exit 1
fi

# Auto-generate mapping path if not specified
if [ -z "$MAPPING_FILE" ]; then
    MAPPING_DIR="$(dirname "$OUTPUT_FILE")"
    MAPPING_BASE="$(basename "$TRACKS_FILE" .tck)"
    MAPPING_FILE="${MAPPING_DIR}/.${MAPPING_BASE}_sift_mapping.bin"
fi

echo "=============================================="
echo "  CUDA SIFT2 v1"
echo "=============================================="
echo "  Input tracks:  $TRACKS_FILE"
echo "  FOD image:     $FOD_FILE"
echo "  Output:        $OUTPUT_FILE"
echo "  ACT image:     ${ACT_FILE:-none}"
echo "=============================================="

# ---- Stage 1: Generate mapping binary ----
if [ "$REUSE_MAPPING" = true ] && [ -f "$MAPPING_FILE" ]; then
    echo ""
    echo "[Stage 1/2] Reusing existing mapping: $MAPPING_FILE"
else
    echo ""
    echo "[Stage 1/2] Generating streamline-to-fixel mapping..."
    echo ""

    TCKSIFT_ARGS=()
    if [ -n "$ACT_FILE" ]; then
        TCKSIFT_ARGS+=("-act" "$ACT_FILE")
    fi
    if [ -n "$NTHREADS" ]; then
        TCKSIFT_ARGS+=("-nthreads" "$NTHREADS")
    fi

    STAGE1_START=$(date +%s)

    # Use dummy term_number (won't filter since -nofilter is set)
    DUMMY_TCK=$(mktemp /tmp/cuda_sift2_dummy_XXXXXX.tck)
    trap "rm -f '$DUMMY_TCK'" EXIT

    "$TCKSIFT_BIN" \
        "${TCKSIFT_ARGS[@]}" \
        -term_number 1 \
        -output_mapping "$MAPPING_FILE" \
        -nofilter \
        -force \
        "$TRACKS_FILE" \
        "$FOD_FILE" \
        "$DUMMY_TCK"

    rm -f "$DUMMY_TCK"

    STAGE1_END=$(date +%s)
    STAGE1_TIME=$((STAGE1_END - STAGE1_START))
    echo ""
    echo "  Mapping generated in ${STAGE1_TIME}s"
    echo "  Size: $(du -h "$MAPPING_FILE" | cut -f1)"
fi

# ---- Stage 2: Run CUDA SIFT2 optimization ----
echo ""
echo "[Stage 2/2] Running CUDA SIFT2 optimization..."
echo ""

STAGE2_START=$(date +%s)

CUDA_ARGS=("$MAPPING_FILE" "$OUTPUT_FILE")
[ -n "$REG_TIK" ]        && CUDA_ARGS+=("--reg_tik" "$REG_TIK")
[ -n "$REG_TV" ]          && CUDA_ARGS+=("--reg_tv" "$REG_TV")
[ -n "$MIN_TD_FRAC" ]     && CUDA_ARGS+=("--min_td_frac" "$MIN_TD_FRAC")
[ -n "$MIN_ITERS" ]       && CUDA_ARGS+=("--min_iters" "$MIN_ITERS")
[ -n "$MAX_ITERS" ]       && CUDA_ARGS+=("--max_iters" "$MAX_ITERS")
[ -n "$MAX_COEFF_STEP" ]  && CUDA_ARGS+=("--max_coeff_step" "$MAX_COEFF_STEP")
[ -n "$MIN_CF_DECREASE" ] && CUDA_ARGS+=("--min_cf_decrease" "$MIN_CF_DECREASE")

"$CUDA_BINARY" "${CUDA_ARGS[@]}" 2>&1

STAGE2_END=$(date +%s)
STAGE2_TIME=$((STAGE2_END - STAGE2_START))

# ---- Report results ----
echo ""
echo "=============================================="
echo "  Results"
echo "=============================================="
echo "  Output weights: $OUTPUT_FILE"

WEIGHT_COUNT=$(wc -l < "$OUTPUT_FILE" 2>/dev/null || echo "unknown")
echo "  Weight entries: $WEIGHT_COUNT"

if [ "${STAGE1_TIME:-0}" -gt 0 ]; then
    TOTAL_TIME=$((STAGE1_TIME + STAGE2_TIME))
    echo ""
    echo "  Timing:"
    echo "    Mapping:       ${STAGE1_TIME}s"
    echo "    Optimization:  ${STAGE2_TIME}s"
    echo "    Total:         ${TOTAL_TIME}s"
else
    echo ""
    echo "  Optimization: ${STAGE2_TIME}s"
fi

echo "=============================================="

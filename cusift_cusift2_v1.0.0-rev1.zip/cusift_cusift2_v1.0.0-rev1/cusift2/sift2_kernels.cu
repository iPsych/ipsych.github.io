// CUDA SIFT2 Kernels - Implementation
// Ports MRtrix3 SIFT2 algorithm to GPU
//
// Key kernels:
//   1. coeff_optimize: Newton optimization of per-streamline coefficients
//   2. fixel_update:   Recompute fixel TD and mean_coeff from updated coefficients
//   3. cost_function:  Evaluate cost function for convergence check

#include "sift2_kernels.cuh"
#include <cub/cub.cuh>
#include <cfloat>
#include <cmath>
#include <cstdio>

namespace SIFT2 {

// ============================================================================
// Device helper functions
// ============================================================================

// TV regularisation (asymmetric penalty) - matches MRtrix regularisation.h
__device__ __forceinline__
double tvreg(double coeff, double base) {
    if (coeff <= base) {
        double d = coeff - base;
        return d * d;
    } else {
        double d = exp(coeff) - exp(base);
        return d * d;
    }
}

// TV regularisation derivatives accumulated into result
// Matches MRtrix dxtvreg_dcoeffx()
__device__ __forceinline__
void tvreg_derivatives(
    double coeff, double expcoeff, double multiplier,
    double base, double expbase,
    double& cost, double& first_deriv, double& second_deriv, double& third_deriv)
{
    if (coeff <= base) {
        double d = coeff - base;
        cost         += multiplier * d * d;
        first_deriv  += multiplier * 2.0 * d;
        second_deriv += multiplier * 2.0;
    } else {
        double d = expcoeff - expbase;
        cost         += multiplier * d * d;
        first_deriv  += multiplier * 2.0 * expcoeff * d;
        second_deriv += multiplier * 2.0 * expcoeff * (2.0 * expcoeff - expbase);
        third_deriv  += multiplier * 2.0 * expcoeff * (4.0 * expcoeff - expbase);
    }
}

// ============================================================================
// Kernel 1: Coefficient Optimization
// ============================================================================

// Each thread optimizes one streamline's coefficient using Newton's method.
// This matches CoefficientOptimiserIterative::get_coeff_change() and
// the Newton loop in coeff_optimiser.cpp lines 324-378.
__global__
void kernel_coeff_optimize(
    const uint64_t* __restrict__ offsets,
    const uint32_t* __restrict__ fixel_indices,
    const float*    __restrict__ segment_lengths,
    double*         coefficients,
    const float*    __restrict__ total_contribution,
    const double*   __restrict__ fixel_FOD,
    const double*   __restrict__ fixel_weight,
    const double*   __restrict__ fixel_orig_TD,
    const int32_t*  __restrict__ fixel_excluded,
    const double*   __restrict__ fixel_TD,
    const double*   __restrict__ fixel_mean_coeff,
    double mu,
    double reg_tik,
    double reg_tv,
    double max_coeff_step,
    double min_coeff,
    double max_coeff,
    uint32_t num_tracks,
    int32_t* hit_max_coeff,
    uint8_t* newton_iters)
{
    uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= num_tracks) return;

    const uint64_t start = offsets[tid];
    const uint64_t end   = offsets[tid + 1];
    const uint32_t num_fixels_for_track = (uint32_t)(end - start);

    if (num_fixels_for_track == 0) return;

    const double Fs = coefficients[tid];
    const double expFs = exp(Fs);
    const double tc = (double)total_contribution[tid];

    // Pre-scale reg_tv by total contribution (matches MRtrix LineSearchFunctor constructor)
    double local_reg_tv = (tc > 0.0) ? (reg_tv / tc) : 0.0;

    // ---- Newton iteration loop ----
    // Matches coeff_optimiser.cpp lines 332-369
    double dFs = 0.0;
    double change = 0.0;
    int iter = 0;

    do {
        // Evaluate cost function and derivatives at (Fs + dFs)
        // Matches LineSearchFunctor::get(dFs) in line_search.cpp
        double coefficient = Fs + dFs;
        double factor = exp(coefficient);

        double data_cost = 0.0, data_d1 = 0.0, data_d2 = 0.0, data_d3 = 0.0;
        double tv_cost = 0.0, tv_d1 = 0.0, tv_d2 = 0.0, tv_d3 = 0.0;

        for (uint32_t j = 0; j < num_fixels_for_track; ++j) {
            uint32_t fi = fixel_indices[start + j];
            if (fixel_excluded[fi]) continue;

            double length = (double)segment_lengths[start + j];
            double PM = fixel_weight[fi];
            double FOD = fixel_FOD[fi];
            double TD_minus_me = fixel_TD[fi] - length * expFs;  // TD without this streamline
            double orig_TD = fixel_orig_TD[fi];
            double meanFs_val = fixel_mean_coeff[fi];

            double cost_frac = (orig_TD > 0.0) ? (length / orig_TD) : 0.0;
            double SL_eff = PM * length;
            double dTD_dFs = (orig_TD - length) * expFs;

            // Data term contributions
            double contribution = length * factor;
            double scaled_contribution = mu * contribution;
            double roc_contribution = mu * (contribution + dTD_dFs);
            double diff = mu * (TD_minus_me + contribution + dTD_dFs * dFs) - FOD;

            data_cost += cost_frac * PM * diff * diff;
            data_d1   += 2.0 * PM * cost_frac * roc_contribution * diff;
            data_d2   += 2.0 * PM * cost_frac * (roc_contribution * roc_contribution + scaled_contribution * diff);
            data_d3   += 2.0 * PM * cost_frac * scaled_contribution * (3.0 * roc_contribution + diff);

            // TV regularisation
            double expmeanFs = exp(meanFs_val);
            tvreg_derivatives(coefficient, factor, SL_eff, meanFs_val, expmeanFs,
                              tv_cost, tv_d1, tv_d2, tv_d3);
        }

        // Tikhonov regularisation
        double tik_d1   = reg_tik * 2.0 * coefficient;
        double tik_d2   = reg_tik * 2.0;

        // Total
        double total_d1 = data_d1 + tik_d1 + local_reg_tv * tv_d1;
        double total_d2 = data_d2 + tik_d2 + local_reg_tv * tv_d2;

        // Newton update (matches coeff_optimiser.cpp lines 337-339)
        change = (total_d2 != 0.0) ? (-total_d1 / total_d2) : 0.0;
        if (total_d2 < 0.0)
            change = -change;  // heading toward maximum, reverse

        if (!isfinite(change))
            change = 0.0;

        // Clamp step size
        if (change > max_coeff_step)
            change = max_coeff_step;
        else if (change < -max_coeff_step)
            change = -max_coeff_step;

        // Early exit if outside bounds and moving further out
        if (dFs >= max_coeff_step && change > 0.0) {
            dFs = max_coeff_step;
            change = 0.0;
        } else if (dFs <= -max_coeff_step && change < 0.0) {
            dFs = -max_coeff_step;
            change = 0.0;
        } else {
            dFs += change;
        }

    } while (++iter < 100 && fabs(change) > 0.001);

    if (newton_iters) newton_iters[tid] = (uint8_t)iter;  // instrumentation only

    // Apply step clamping (matches coeff_optimiser.cpp lines 107-117)
    if (dFs >= max_coeff_step)
        dFs = max_coeff_step;
    else if (dFs <= -max_coeff_step)
        dFs = -max_coeff_step;

    // Apply coefficient bounds
    double new_coeff = Fs + dFs;
    if (new_coeff < min_coeff) {
        new_coeff = min_coeff;
    } else if (new_coeff > max_coeff) {
        // Signal that this streamline hit max_coeff (for fixel exclusion on CPU)
        hit_max_coeff[tid] = 1;
        new_coeff = max_coeff;
    }

    coefficients[tid] = new_coeff;
}


// ============================================================================
// Kernel 2: Fixel Update
// ============================================================================

// Clear fixel arrays before accumulation
__global__
void kernel_clear_fixels(
    double*   fixel_TD,
    double*   fixel_mean_coeff_sum,
    uint32_t* fixel_count,
    uint32_t  num_fixels)
{
    uint32_t idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= num_fixels) return;
    fixel_TD[idx] = 0.0;
    fixel_mean_coeff_sum[idx] = 0.0;
    fixel_count[idx] = 0;
}

// Accumulate TD and mean_coeff contributions from all streamlines
// Uses atomicAdd for double (supported on sm_60+)
__global__
void kernel_accumulate_fixels(
    const uint64_t* __restrict__ offsets,
    const uint32_t* __restrict__ fixel_indices,
    const float*    __restrict__ segment_lengths,
    const double*   __restrict__ coefficients,
    double          min_coeff,
    double*         fixel_TD,
    double*         fixel_mean_coeff_sum,
    uint32_t*       fixel_count,
    uint32_t        num_tracks)
{
    uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= num_tracks) return;

    const double coeff = coefficients[tid];
    const double weighting_factor = (coeff > min_coeff) ? exp(coeff) : 0.0;
    const uint64_t start = offsets[tid];
    const uint64_t end   = offsets[tid + 1];

    for (uint64_t j = start; j < end; ++j) {
        uint32_t fi = fixel_indices[j];
        double length = (double)segment_lengths[j];
        atomicAdd(&fixel_TD[fi], length * weighting_factor);
        atomicAdd(&fixel_mean_coeff_sum[fi], length * coeff);
        atomicAdd(&fixel_count[fi], 1u);
    }
}

// Normalize mean_coeff: divide accumulated sum by orig_TD
// Also compute weighted TD_sum
__global__
void kernel_normalize_fixels(
    double*         fixel_mean_coeff,      // in: accumulated sum, out: normalized mean
    const double*   fixel_orig_TD,
    const double*   fixel_TD,
    const double*   fixel_weight,
    const uint32_t* fixel_count,
    double*         partial_TD_sum,        // one element per block for reduction
    uint32_t        num_fixels)
{
    uint32_t idx = blockIdx.x * blockDim.x + threadIdx.x;

    double local_td_sum = 0.0;
    if (idx < num_fixels) {
        double orig_td = fixel_orig_TD[idx];
        if (orig_td > 0.0) {
            fixel_mean_coeff[idx] /= orig_td;
        }
        // Match MRtrix: if count < 2, set mean_coeff to 0
        if (fixel_count[idx] < 2) {
            fixel_mean_coeff[idx] = 0.0;
        }
        // TD_sum = sum of weight * TD
        local_td_sum = fixel_weight[idx] * fixel_TD[idx];
    }

    // Block-level reduction for TD_sum
    typedef cub::BlockReduce<double, 256> BlockReduceT;
    __shared__ typename BlockReduceT::TempStorage temp_storage;
    double block_sum = BlockReduceT(temp_storage).Sum(local_td_sum);

    if (threadIdx.x == 0) {
        partial_TD_sum[blockIdx.x] = block_sum;
    }
}

// Final reduction of TD_sum
__global__
void kernel_reduce_TD_sum(
    const double* partial_sums,
    double*       TD_sum_out,
    uint32_t      num_blocks)
{
    double sum = 0.0;
    for (uint32_t i = threadIdx.x; i < num_blocks; i += blockDim.x) {
        sum += partial_sums[i];
    }

    typedef cub::BlockReduce<double, 256> BlockReduceT;
    __shared__ typename BlockReduceT::TempStorage temp_storage;
    double total = BlockReduceT(temp_storage).Sum(sum);

    if (threadIdx.x == 0) {
        *TD_sum_out = total;
    }
}


// ============================================================================
// Kernel 3: Cost Function + Regularization
// ============================================================================

__global__
void kernel_cost_function(
    const uint64_t* __restrict__ offsets,
    const uint32_t* __restrict__ fixel_indices,
    const float*    __restrict__ segment_lengths,
    const double*   __restrict__ coefficients,
    const float*    __restrict__ total_contribution,
    double          min_coeff,
    const double*   __restrict__ fixel_FOD,
    const double*   __restrict__ fixel_TD,
    const double*   __restrict__ fixel_weight,
    const double*   __restrict__ fixel_orig_TD,
    const int32_t*  __restrict__ fixel_excluded,
    const double*   __restrict__ fixel_mean_coeff,
    double          mu,
    double          reg_tik,
    double          reg_tv,
    uint32_t        num_tracks,
    double*         partial_cf_reg_tik,
    double*         partial_cf_reg_tv,
    uint32_t*       partial_nonzero)
{
    uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x;

    double local_cf_tik = 0.0;
    double local_cf_tv = 0.0;
    uint32_t local_nonzero = 0;

    if (tid < num_tracks) {
        const double coeff = coefficients[tid];
        const uint64_t start = offsets[tid];
        const uint64_t end   = offsets[tid + 1];
        const double tc = (double)total_contribution[tid];
        const uint32_t dim = (uint32_t)(end - start);

        // Count nonzero streamlines
        if (dim > 0 && coeff > min_coeff) {
            local_nonzero = 1;
        }

        // Data term: sum over fixels of cost_frac * weight * (mu*TD - FOD)^2
        // (This is the per-streamline share of the total cost, but for convergence
        //  we actually need the full fixel-based cost. We compute it per-fixel below.)
        // Actually, the MRtrix cost function is computed per-fixel in calc_cost_function().
        // For the per-streamline sum_costs (used for debugging), they use operator()(0.0).
        // For convergence, they use calc_cost_function() which sums per-fixel.
        // We compute per-fixel cost separately. Here we compute regularization only.

        // Tikhonov
        local_cf_tik = reg_tik * coeff * coeff;

        // TV regularisation (reported cost): the reference RegularisationCalculator sums over ALL fixels of the
        // streamline, including excluded ones (they are skipped only in the optimiser, Kernel 1). v2 fix.
        if (tc > 0.0) {
            double inv_tc = 1.0 / tc;
            for (uint64_t j = start; j < end; ++j) {
                uint32_t fi = fixel_indices[j];
                double length = (double)segment_lengths[j];
                double PM = fixel_weight[fi];
                double SL_eff = PM * length;
                double meanFs = fixel_mean_coeff[fi];
                local_cf_tv += SL_eff * tvreg(coeff, meanFs);
            }
            local_cf_tv *= reg_tv * inv_tc;
        }
    }

    // Block reduction
    typedef cub::BlockReduce<double, 256> BlockReduceD;
    typedef cub::BlockReduce<uint32_t, 256> BlockReduceU;
    __shared__ union {
        typename BlockReduceD::TempStorage d;
        typename BlockReduceU::TempStorage u;
    } temp_storage;

    double sum_tik = BlockReduceD(temp_storage.d).Sum(local_cf_tik);
    __syncthreads();
    double sum_tv = BlockReduceD(temp_storage.d).Sum(local_cf_tv);
    __syncthreads();
    uint32_t sum_nz = BlockReduceU(temp_storage.u).Sum(local_nonzero);

    if (threadIdx.x == 0) {
        partial_cf_reg_tik[blockIdx.x] = sum_tik;
        partial_cf_reg_tv[blockIdx.x] = sum_tv;
        partial_nonzero[blockIdx.x] = sum_nz;
    }
}

// Compute per-fixel data cost (the actual cost function used for convergence)
// cost = sum over fixels of: weight * (mu * TD - FOD)^2
__global__
void kernel_fixel_cost(
    const double* __restrict__ fixel_FOD,
    const double* __restrict__ fixel_TD,
    const double* __restrict__ fixel_weight,
    double        mu,
    uint32_t      num_fixels,
    double*       partial_cost)
{
    uint32_t idx = blockIdx.x * blockDim.x + threadIdx.x;
    double local_cost = 0.0;
    if (idx < num_fixels) {
        double diff = mu * fixel_TD[idx] - fixel_FOD[idx];
        local_cost = fixel_weight[idx] * diff * diff;
    }

    typedef cub::BlockReduce<double, 256> BlockReduceT;
    __shared__ typename BlockReduceT::TempStorage temp_storage;
    double block_sum = BlockReduceT(temp_storage).Sum(local_cost);

    if (threadIdx.x == 0) {
        partial_cost[blockIdx.x] = block_sum;
    }
}

// Generic final reduction kernel
__global__
void kernel_final_reduce_double(
    const double* partial,
    double*       output,
    uint32_t      num_blocks)
{
    double sum = 0.0;
    for (uint32_t i = threadIdx.x; i < num_blocks; i += blockDim.x) {
        sum += partial[i];
    }
    typedef cub::BlockReduce<double, 256> BlockReduceT;
    __shared__ typename BlockReduceT::TempStorage temp_storage;
    double total = BlockReduceT(temp_storage).Sum(sum);
    if (threadIdx.x == 0) *output = total;
}

__global__
void kernel_final_reduce_uint32(
    const uint32_t* partial,
    uint32_t*       output,
    uint32_t        num_blocks)
{
    uint32_t sum = 0;
    for (uint32_t i = threadIdx.x; i < num_blocks; i += blockDim.x) {
        sum += partial[i];
    }
    typedef cub::BlockReduce<uint32_t, 256> BlockReduceT;
    __shared__ typename BlockReduceT::TempStorage temp_storage;
    uint32_t total = BlockReduceT(temp_storage).Sum(sum);
    if (threadIdx.x == 0) *output = total;
}


// ============================================================================
// Launch functions
// ============================================================================

void launch_coeff_optimize(
    const uint64_t* d_offsets,
    const uint32_t* d_fixel_indices,
    const float*    d_segment_lengths,
    double*         d_coefficients,
    const float*    d_total_contribution,
    const double*   d_fixel_FOD,
    const double*   d_fixel_weight,
    const double*   d_fixel_orig_TD,
    const int32_t*  d_fixel_excluded,
    const double*   d_fixel_TD,
    const double*   d_fixel_mean_coeff,
    double mu, double reg_tik, double reg_tv,
    double max_coeff_step, double min_coeff, double max_coeff,
    uint32_t num_tracks,
    int32_t* d_hit_max_coeff,
    cudaStream_t stream,
    uint8_t* d_newton_iters)
{
    // Clear hit_max_coeff flags
    cudaMemsetAsync(d_hit_max_coeff, 0, num_tracks * sizeof(int32_t), stream);

    const int block = 128;  // Fewer threads per block due to high register usage
    const int grid = (num_tracks + block - 1) / block;

    kernel_coeff_optimize<<<grid, block, 0, stream>>>(
        d_offsets, d_fixel_indices, d_segment_lengths,
        d_coefficients, d_total_contribution,
        d_fixel_FOD, d_fixel_weight, d_fixel_orig_TD, d_fixel_excluded,
        d_fixel_TD, d_fixel_mean_coeff,
        mu, reg_tik, reg_tv, max_coeff_step, min_coeff, max_coeff,
        num_tracks, d_hit_max_coeff, d_newton_iters);
}

void launch_fixel_update(
    const uint64_t* d_offsets,
    const uint32_t* d_fixel_indices,
    const float*    d_segment_lengths,
    const double*   d_coefficients,
    double          min_coeff,
    double*         d_fixel_TD,
    double*         d_fixel_mean_coeff_sum,
    uint32_t*       d_fixel_count,
    const double*   d_fixel_orig_TD,
    uint32_t num_tracks, uint32_t num_fixels,
    double*         d_TD_sum_out,
    const double*   d_fixel_weight,
    cudaStream_t stream)
{
    const int block = 256;

    // Step 1: Clear fixel arrays
    int grid_fixels = (num_fixels + block - 1) / block;
    kernel_clear_fixels<<<grid_fixels, block, 0, stream>>>(
        d_fixel_TD, d_fixel_mean_coeff_sum, d_fixel_count, num_fixels);

    // Step 2: Accumulate from all streamlines
    int grid_tracks = (num_tracks + block - 1) / block;
    kernel_accumulate_fixels<<<grid_tracks, block, 0, stream>>>(
        d_offsets, d_fixel_indices, d_segment_lengths,
        d_coefficients, min_coeff,
        d_fixel_TD, d_fixel_mean_coeff_sum, d_fixel_count,
        num_tracks);

    // Step 3: Normalize mean_coeff and compute TD_sum
    // Need temporary buffer for partial sums
    double* d_partial_td;
    cudaMalloc(&d_partial_td, grid_fixels * sizeof(double));

    kernel_normalize_fixels<<<grid_fixels, block, 0, stream>>>(
        d_fixel_mean_coeff_sum, d_fixel_orig_TD, d_fixel_TD, d_fixel_weight,
        d_fixel_count, d_partial_td, num_fixels);

    // Final reduction for TD_sum
    kernel_reduce_TD_sum<<<1, block, 0, stream>>>(
        d_partial_td, d_TD_sum_out, grid_fixels);

    cudaFree(d_partial_td);
}

void launch_cost_function(
    const uint64_t* d_offsets,
    const uint32_t* d_fixel_indices,
    const float*    d_segment_lengths,
    const double*   d_coefficients,
    const float*    d_total_contribution,
    double          min_coeff,
    const double*   d_fixel_FOD,
    const double*   d_fixel_TD,
    const double*   d_fixel_weight,
    const double*   d_fixel_orig_TD,
    const int32_t*  d_fixel_excluded,
    const double*   d_fixel_mean_coeff,
    double mu, double reg_tik, double reg_tv,
    uint32_t num_tracks,
    double* d_cf_reg_tik,
    double* d_cf_reg_tv,
    uint32_t* d_nonzero_count,
    cudaStream_t stream)
{
    const int block = 256;
    int grid_tracks = (num_tracks + block - 1) / block;

    // Allocate partial reduction buffers
    double* d_partial_tik;
    double* d_partial_tv;
    uint32_t* d_partial_nz;
    cudaMalloc(&d_partial_tik, grid_tracks * sizeof(double));
    cudaMalloc(&d_partial_tv, grid_tracks * sizeof(double));
    cudaMalloc(&d_partial_nz, grid_tracks * sizeof(uint32_t));

    kernel_cost_function<<<grid_tracks, block, 0, stream>>>(
        d_offsets, d_fixel_indices, d_segment_lengths,
        d_coefficients, d_total_contribution, min_coeff,
        d_fixel_FOD, d_fixel_TD, d_fixel_weight, d_fixel_orig_TD,
        d_fixel_excluded, d_fixel_mean_coeff,
        mu, reg_tik, reg_tv, num_tracks,
        d_partial_tik, d_partial_tv, d_partial_nz);

    // Final reductions
    kernel_final_reduce_double<<<1, block, 0, stream>>>(d_partial_tik, d_cf_reg_tik, grid_tracks);
    kernel_final_reduce_double<<<1, block, 0, stream>>>(d_partial_tv, d_cf_reg_tv, grid_tracks);
    kernel_final_reduce_uint32<<<1, block, 0, stream>>>(d_partial_nz, d_nonzero_count, grid_tracks);

    cudaFree(d_partial_tik);
    cudaFree(d_partial_tv);
    cudaFree(d_partial_nz);
}

} // namespace SIFT2

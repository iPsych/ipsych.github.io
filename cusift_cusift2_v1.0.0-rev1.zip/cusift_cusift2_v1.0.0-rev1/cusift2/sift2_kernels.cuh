// CUDA SIFT2 Kernels - Header
// GPU-accelerated coefficient optimization for SIFT2
// Matches MRtrix3 tcksift2 algorithm

#ifndef SIFT2_KERNELS_CUH
#define SIFT2_KERNELS_CUH

#include <cstdint>
#include <cuda_runtime.h>

namespace SIFT2 {

// Default parameters matching MRtrix3
constexpr double DEFAULT_REG_TIKHONOV = 0.0;
constexpr double DEFAULT_REG_TV = 0.1;
constexpr double DEFAULT_MIN_TD_FRAC = 0.10;
constexpr int    DEFAULT_MIN_ITERS = 10;
constexpr int    DEFAULT_MAX_ITERS = 1000;
constexpr double DEFAULT_MAX_COEFF_STEP = 1.0;
constexpr double DEFAULT_MIN_CF_DECREASE = 2.5e-5;
// min_coeff and max_coeff default to +/- infinity (handled in code)

// Per-iteration statistics returned to host
struct IterationResult {
    double cf_data;
    double cf_reg_tik;
    double cf_reg_tv;
    double TD_sum;
    uint32_t nonzero_streamlines;
    uint32_t fixels_excluded;
};

// Launch coefficient optimization kernel
// Each thread optimizes one streamline's coefficient via Newton's method
void launch_coeff_optimize(
    // CSR structure
    const uint64_t* d_offsets,
    const uint32_t* d_fixel_indices,
    const float*    d_segment_lengths,
    // Per-streamline data
    double*         d_coefficients,
    const float*    d_total_contribution,
    // Per-fixel read-only data
    const double*   d_fixel_FOD,
    const double*   d_fixel_weight,
    const double*   d_fixel_orig_TD,
    const int32_t*  d_fixel_excluded,
    // Per-fixel read (updated each iteration)
    const double*   d_fixel_TD,
    const double*   d_fixel_mean_coeff,
    // Parameters
    double mu,
    double reg_tik,
    double reg_tv,
    double max_coeff_step,
    double min_coeff,
    double max_coeff,
    uint32_t num_tracks,
    // Output: flags for fixel exclusion (set when streamline hits max_coeff)
    int32_t* d_hit_max_coeff,  // per-streamline flag
    cudaStream_t stream = 0,
    uint8_t* d_newton_iters = nullptr  // optional: Newton iterations per streamline (instrumentation only)
);

// Launch fixel update kernel (clear + accumulate + normalize)
void launch_fixel_update(
    // CSR structure
    const uint64_t* d_offsets,
    const uint32_t* d_fixel_indices,
    const float*    d_segment_lengths,
    // Per-streamline
    const double*   d_coefficients,
    double          min_coeff,
    // Per-fixel (read-write)
    double*         d_fixel_TD,
    double*         d_fixel_mean_coeff_sum,  // accumulator (before normalization)
    uint32_t*       d_fixel_count,
    // Per-fixel (read-only, for normalization)
    const double*   d_fixel_orig_TD,
    // Sizes
    uint32_t num_tracks,
    uint32_t num_fixels,
    // Output: TD_sum via reduction
    double*         d_TD_sum_out,
    // For weighted TD_sum
    const double*   d_fixel_weight,
    cudaStream_t stream = 0
);

// Launch cost function + regularization kernel
void launch_cost_function(
    // CSR structure
    const uint64_t* d_offsets,
    const uint32_t* d_fixel_indices,
    const float*    d_segment_lengths,
    // Per-streamline
    const double*   d_coefficients,
    const float*    d_total_contribution,
    double          min_coeff,
    // Per-fixel
    const double*   d_fixel_FOD,
    const double*   d_fixel_TD,
    const double*   d_fixel_weight,
    const double*   d_fixel_orig_TD,
    const int32_t*  d_fixel_excluded,
    const double*   d_fixel_mean_coeff,
    // Parameters
    double mu,
    double reg_tik,
    double reg_tv,
    uint32_t num_tracks,
    // Outputs (device memory, single values)
    double* d_cf_reg_tik,
    double* d_cf_reg_tv,
    uint32_t* d_nonzero_count,
    cudaStream_t stream = 0
);

} // namespace SIFT2

#endif // SIFT2_KERNELS_CUH

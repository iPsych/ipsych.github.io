#!/usr/bin/env python3
"""Compare SIFT2 weight files between CUDA and MRtrix gold standard.

Usage:
    python3 compare_weights.py <cuda_weights.txt> <gold_weights.txt>

Computes:
    - Pearson correlation coefficient (R and R²)
    - Mean absolute difference
    - Max absolute difference
    - Weight statistics (mean, std, min, max)
    - Number of zero weights
"""

import sys
import numpy as np


def load_weights(path):
    """Load a SIFT2 weights text file.
    Handles both MRtrix format (space-separated, optional # comment header)
    and one-per-line format."""
    weights = []
    with open(path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            # Try space-separated (MRtrix format)
            tokens = line.split()
            for t in tokens:
                try:
                    weights.append(float(t))
                except ValueError:
                    pass
    return np.array(weights, dtype=np.float64)


def main():
    if len(sys.argv) < 3:
        print("Usage: python3 compare_weights.py <cuda_weights> <gold_weights>")
        sys.exit(1)

    cuda_path = sys.argv[1]
    gold_path = sys.argv[2]

    print(f"Loading CUDA weights: {cuda_path}")
    cuda_w = load_weights(cuda_path)
    print(f"  Count: {len(cuda_w)}")

    print(f"Loading gold standard: {gold_path}")
    gold_w = load_weights(gold_path)
    print(f"  Count: {len(gold_w)}")

    if len(cuda_w) != len(gold_w):
        print(f"\nERROR: Different number of weights ({len(cuda_w)} vs {len(gold_w)})")
        sys.exit(1)

    n = len(cuda_w)

    # Basic statistics
    print(f"\n=== Weight Statistics ===")
    for name, w in [("CUDA", cuda_w), ("Gold", gold_w)]:
        nz = np.count_nonzero(w)
        print(f"  {name}:")
        print(f"    Non-zero: {nz} ({100*nz/n:.2f}%)")
        print(f"    Mean:     {np.mean(w):.6f}")
        print(f"    Std:      {np.std(w):.6f}")
        print(f"    Min:      {np.min(w):.6f}")
        print(f"    Max:      {np.max(w):.6f}")
        if nz < n:
            nz_w = w[w > 0]
            print(f"    Mean (non-zero): {np.mean(nz_w):.6f}")

    # Differences
    diff = cuda_w - gold_w
    abs_diff = np.abs(diff)

    print(f"\n=== Comparison ===")
    print(f"  Mean abs diff:    {np.mean(abs_diff):.8f}")
    print(f"  Median abs diff:  {np.median(abs_diff):.8f}")
    print(f"  Max abs diff:     {np.max(abs_diff):.8f}")
    print(f"  RMS diff:         {np.sqrt(np.mean(diff**2)):.8f}")

    # Relative difference (for non-zero gold weights)
    mask = gold_w > 0
    if np.any(mask):
        rel_diff = np.abs(diff[mask]) / gold_w[mask]
        print(f"  Mean relative diff: {np.mean(rel_diff):.6f} ({100*np.mean(rel_diff):.4f}%)")
        print(f"  Max relative diff:  {np.max(rel_diff):.6f} ({100*np.max(rel_diff):.4f}%)")

    # Correlation
    if np.std(cuda_w) > 0 and np.std(gold_w) > 0:
        r = np.corrcoef(cuda_w, gold_w)[0, 1]
        r2 = r * r
        print(f"\n  Pearson R:  {r:.10f}")
        print(f"  Pearson R²: {r2:.10f}")
    else:
        print("\n  Cannot compute correlation (zero variance)")

    # Agreement on zero/nonzero
    cuda_zero = cuda_w == 0
    gold_zero = gold_w == 0
    both_zero = np.sum(cuda_zero & gold_zero)
    both_nonzero = np.sum(~cuda_zero & ~gold_zero)
    cuda_only_zero = np.sum(cuda_zero & ~gold_zero)
    gold_only_zero = np.sum(~cuda_zero & gold_zero)

    print(f"\n=== Zero/Non-zero Agreement ===")
    print(f"  Both zero:       {both_zero}")
    print(f"  Both non-zero:   {both_nonzero}")
    print(f"  CUDA zero only:  {cuda_only_zero}")
    print(f"  Gold zero only:  {gold_only_zero}")
    print(f"  Agreement:       {100*(both_zero+both_nonzero)/n:.4f}%")


if __name__ == "__main__":
    main()

#!/bin/bash
# Second campaign (run AFTER campaign.sh has finished; never edit a running bash script).
# usage: campaign2.sh <phase> ...   phases: Q1 (SIFT2 fixed-iteration test) Q2 (Newton dump + reordering) Q3 (re-seeded tractograms) Q4 (connectomes)
set -uo pipefail
source "$(dirname "$0")/common.sh"
S=$REV/scripts; A=$REV/analysis
log() { echo "[$(date -Is)] $*"; }
SUBJECTS="UKB HCP1 HCP3 HCP2"
B=$(cat $RUNS/best_threads.txt 2>/dev/null || echo 48)

Q0() {  # re-run every GPU SIFT2 result produced with the v1 binary (excluded fixels omitted from the REPORTED TV cost); v1 outputs are kept in v1/
  for s in $SUBJECTS; do
    for f in $RUNS/$s/gpu_sift2_*.json; do [ -f "$f" ] || continue; case $f in *.timing.json) continue;; esac
      grep -q '"binary":"v2"' $f && continue
      mkdir -p $RUNS/$s/v1; b=${f%.json}; mv $b.* $RUNS/$s/v1/ 2>/dev/null; done
    map=$RUNS/$s/cpu_sift_t4_ref1.mapping.bin; [ -f $map ] || continue
    $S/run_gpu_sift2.sh $s $map warmup; for r in 1 2 3 4 5; do $S/run_gpu_sift2.sh $s $map rep$r; done; COLD=1 $S/run_gpu_sift2.sh $s $map cold
  done
}
Q1() {  # termination-step effect: corrected GPU program forced to one outer iteration MORE than the reference (and to the reference's count)
  for s in $SUBJECTS; do
    map=$RUNS/$s/cpu_sift_t4_ref1.mapping.bin
    ncpu=$(python3 -c "rows=[l for l in open('$RUNS/$s/cpu_sift2_t4_ref1.csv') if l.strip() and l[0].isdigit()]; print(int(float(rows[-1].split(',')[0])))" 2>/dev/null || echo 0)
    [ "$ncpu" -gt 0 ] || continue
    SIFT2_BIN_OVERRIDE=$REV/code/sift2/sift2_cuda $S/run_gpu_sift2.sh $s $map v1   # submitted-version binary (reported TV cost without excluded fixels)
    $S/run_gpu_sift2.sh $s $map fixiter_same --min_iters $ncpu --max_iters $ncpu
    $S/run_gpu_sift2.sh $s $map fixiter_plus1 --min_iters $((ncpu+1)) --max_iters $((ncpu+1))
  done
}
Q2() {  # Newton-iteration dump and physical reordering experiments (UKB and HCP2)
  for s in UKB HCP2; do
    map=$RUNS/$s/cpu_sift_t4_ref1.mapping.bin
    $S/run_gpu_sift2.sh $s $map newtondump --newton_dump $RUNS/$s/newton
    # reorder key = Newton count of outer iteration 2 of the dump run (float32 per streamline)
    python3 - <<PY
import numpy as np, os
f='$RUNS/$s/newton_iter2.u8'
if os.path.exists(f): np.fromfile(f,dtype=np.uint8).astype(np.float32).tofile('$RUNS/$s/newton_key.f32')
PY
    for r in 1 2 3; do $S/run_gpu_sift2.sh $s $map reorder_length_r$r --reorder length; done
    for r in 1 2 3; do $S/run_gpu_sift2.sh $s $map reorder_newton_r$r --reorder key:$RUNS/$s/newton_key.f32; done
    for r in 1 2 3; do $S/run_gpu_sift2.sh $s $map reorder_none_r$r; done
  done
  # keep canonical names for analyze.py
  for s in UKB HCP2; do for k in length newton; do [ -f $RUNS/$s/gpu_sift2_reorder_${k}_r1.txt ] && ln -sf $RUNS/$s/gpu_sift2_reorder_${k}_r1.txt $RUNS/$s/gpu_sift2_reorder_${k}.txt; done; done
}
Q3() {  # re-seeded tractograms (variability floor for the connectome comparison), UKB and HCP2, reference at best threads
  for s in UKB HCP2; do
    d=$(subj_dir $s); t=$RUNS/$s/tracks_10000000_seedB.tck
    [ -f $t ] || $MRTRIX_STOCK/tckgen $d/wmfod_norm.mif $t -act $d/5tt_coreg.mif -seed_gmwmi $d/gmwm_seed.mif -select 10000000 -maxlength 250 -cutoff 0.06 -nthreads 24 -force -quiet
    export TRACKS=$t
    $S/run_cpu_sift.sh $s $B seedB
    $S/run_cpu_sift2.sh $s $B seedB
    unset TRACKS
  done
}
Q5() {  # per-process device-memory measurement (one extra run per subject and program; nvidia-smi --query-compute-apps)
  for s in $SUBJECTS; do map=$RUNS/$s/cpu_sift_t4_ref1.mapping.bin; [ -f $map ] || continue
    $S/run_gpu_sift.sh $s $map mem; $S/run_gpu_sift2.sh $s $map mem; done
}
Q6() {  # thread-count reproducibility of the reference: 96-thread points (skipped in P3) and REPEATS of the divergent thread counts
  for s in UKB HCP2; do
    $S/run_cpu_sift2.sh $s 96 scal; $S/run_cpu_sift.sh $s 96 scal
    $S/run_cpu_sift.sh $s 16 scal2; $S/run_cpu_sift.sh $s 2 scal2; $S/run_cpu_sift.sh $s 1 scal2
  done
}
Q4() {  # connectomes for every subject: GPU vs CPU4, CPU4 vs CPUbest, re-seed
  export CONN_THREADS=8
  for s in $SUBJECTS; do
    d=$(subj_dir $s); T=$d/tracks_10000000.tck
    python3 $A/connectome.py build $s sift_cpu4 sift $RUNS/$s/cpu_sift_t4_ref1.tck
    python3 $A/connectome.py build $s sift_gpu sift $RUNS/$s/gpu_sift_rep1.tck
    python3 $A/connectome.py build $s sift2_cpu4 sift2 $T $RUNS/$s/cpu_sift2_t4_ref1.txt
    python3 $A/connectome.py build $s sift2_gpu sift2 $T $RUNS/$s/gpu_sift2_rep1.txt
    [ -f $RUNS/$s/cpu_sift_t${B}_best_ref1.tck ] && python3 $A/connectome.py build $s sift_cpubest sift $RUNS/$s/cpu_sift_t${B}_best_ref1.tck
    [ -f $RUNS/$s/cpu_sift2_t${B}_best_ref1.txt ] && python3 $A/connectome.py build $s sift2_cpubest sift2 $T $RUNS/$s/cpu_sift2_t${B}_best_ref1.txt
    python3 $A/connectome.py compare $s sift_gpu sift_cpu4; python3 $A/connectome.py compare $s sift2_gpu sift2_cpu4
    for T in 16 2 24; do if [ -f $RUNS/$s/cpu_sift_t${T}_scal.tck ]; then python3 $A/connectome.py build $s sift_cpu${T} sift $RUNS/$s/cpu_sift_t${T}_scal.tck; python3 $A/connectome.py compare $s sift_cpu${T} sift_cpu4; fi; done
    [ -f $RUNS/$s/conn/conn_sift_cpubest.csv ] && python3 $A/connectome.py compare $s sift_cpubest sift_cpu4
    [ -f $RUNS/$s/conn/conn_sift2_cpubest.csv ] && python3 $A/connectome.py compare $s sift2_cpubest sift2_cpu4
    if [ -f $RUNS/$s/cpu_sift_t${B}_seedB.tck ]; then
      python3 $A/connectome.py build $s sift_seedB sift $RUNS/$s/cpu_sift_t${B}_seedB.tck
      python3 $A/connectome.py build $s sift2_seedB sift2 $RUNS/$s/tracks_10000000_seedB.tck $RUNS/$s/cpu_sift2_t${B}_seedB.txt
      python3 $A/connectome.py compare $s sift_seedB sift_cpu4; python3 $A/connectome.py compare $s sift2_seedB sift2_cpu4
    fi
  done
}
for ph in "$@"; do log "=== phase $ph start ==="; $ph; log "=== phase $ph end ==="; done

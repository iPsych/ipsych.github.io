#!/bin/bash
# Shared configuration for the MEP-100700 revision benchmark campaign.
export REV=/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision
export RUNS=/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs
export DATA=/media/ipsych/Data_4TB_01/mrtrix_sandbox/test_Data
export MRTRIX_PATCHED=/media/ipsych/Data_4TB_01/mrtrix_sandbox/mrtrix3/bin   # 3.0.8-10-ga488fa32 + export patch
export TCKSIFT=$MRTRIX_PATCHED/tcksift
export TCKSIFT2=$MRTRIX_PATCHED/tcksift2
export MRTRIX_STOCK=/home/ipsych/anaconda3/envs/mrtrix3/bin                 # 3.0.5, used only for non-timed utilities
export SIFT_GPU=$REV/code/sift/sift_gpu
export SIFT2_GPU=$REV/code/sift2/sift2_cuda_v3
export PYTHON=python3
export COLD=${COLD:-0}
export TERM_N=1000000

subj_dir() {
  case "$1" in
    UKB)  echo "$DATA/UKB/results" ;;
    HCP1) echo "$DATA/HCP/105216/results" ;;
    HCP2) echo "$DATA/HCP/124826/results" ;;
    HCP3) echo "$DATA/HCP/137128/results" ;;
    ADNI*) echo "/media/ipsych/Storage_Z8_2/ADNI3_CN/mrtrix_superager_work/${ADNI_MAP[$1]:-$1}" ;;
    *) echo "unknown subject $1" >&2; return 1 ;;
  esac
}
declare -A ADNI_MAP=([ADNI1]=sub-941S1195 [ADNI2]=sub-941S4365 [ADNI3]=sub-002S1280 [ADNI4]=sub-002S4213 [ADNI5]=sub-002S4225 [ADNI6]=sub-002S5178 [ADNI7]=sub-003S4644 [ADNI8]=sub-005S0602 [ADNI9]=sub-005S0610 [ADNI10]=sub-006S0498 [ADNI11]=sub-006S0731 [ADNI12]=sub-012S4643 [ADNI13]=sub-013S4580 [ADNI14]=sub-016S4951 [ADNI15]=sub-007S1222 [ADNI16]=sub-007S4387 [ADNI17]=sub-007S4488 [ADNI18]=sub-007S4637 [ADNI19]=sub-007S5265 [ADNI20]=sub-023S0031 [ADNI21]=sub-023S4164 [ADNI22]=sub-023S4448 [ADNI23]=sub-036S4491 [ADNI24]=sub-067S0056 [ADNI25]=sub-067S0059 [ADNI26]=sub-073S4393)
# inputs (may be overridden for the size sweep via TRACKS env var)
subj_tracks() { if [ -n "${TRACKS:-}" ]; then echo "$TRACKS"; elif [ -f "$(subj_dir $1)/tracks_10000000.tck" ]; then echo "$(subj_dir $1)/tracks_10000000.tck"; else echo "$(subj_dir $1)/tracks_10mio.tck"; fi; }
subj_fod()    { echo "$(subj_dir $1)/wmfod_norm.mif"; }
subj_act()    { if [ -f "$(subj_dir $1)/5tt_coreg.mif" ]; then echo "$(subj_dir $1)/5tt_coreg.mif"; else echo "$(subj_dir $1)/5tt_nocoreg.mif"; fi; }

machine_state() {  # $1 = file to append to
  { echo "date=$(date -Is)"; echo "uptime=$(uptime)"; nvidia-smi --query-gpu=index,utilization.gpu,memory.used,temperature.gpu,clocks.sm --format=csv,noheader | sed 's/^/gpu=/';
    echo "governor=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)"; } >> "$1"
}
evict() { $PYTHON $REV/scripts/evict.py "$@"; }
now() { date +%s.%N; }

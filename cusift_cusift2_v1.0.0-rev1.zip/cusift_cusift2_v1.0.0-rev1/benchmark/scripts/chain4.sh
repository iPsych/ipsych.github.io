#!/bin/bash
while kill -0 3915924 2>/dev/null; do sleep 120; done
cd /media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision && bash scripts/campaign_adni88.sh >> logs/campaign_adni88.log 2>&1

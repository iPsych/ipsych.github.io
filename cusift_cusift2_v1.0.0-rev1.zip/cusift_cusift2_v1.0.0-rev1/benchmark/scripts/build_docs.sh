#!/bin/bash
# Regenerate everything from the raw run outputs: results -> tables/numbers -> figures -> PDFs -> latexdiff.
set -euo pipefail
REV=/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision; A=$REV/analysis
DOC=/media/ipsych/Storage_Z8_3/M2561_CUDA_SIFT_SIFT2/M2561_CUDA_SIFT_SIFT2/Submission_MEP_IOP/1st_Revision/revised
RUNS=/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs; DATA=/media/ipsych/Data_4TB_01/mrtrix_sandbox/test_Data
LD=/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision/scripts/latexdiff-so
step=${1:-all}
if [ "$step" = all ] || [ "$step" = analyze ]; then python3 $A/analyze.py; python3 $A/connectome.py summary; python3 $A/adni88_summary.py || true; fi
if [ "$step" = all ] || [ "$step" = figures ]; then
  python3 $A/fig_si.py --figdir $DOC/figures || true
  python3 $A/fig_e2e_scaling.py --subject UKB --out $DOC/figures/fig_e2e_scaling.pdf || true
  python3 $A/fig_size_sweep.py --out $DOC/figures/fig_size_sweep.pdf || true
  python3 $A/fig_connectome.py --out $DOC/figures/fig_connectome.pdf || true
  # SIFT discrepant streamlines: main figure = subject with most discrepancies (chosen in make_figs_tck.py), SI = the others
  python3 $A/make_figs_tck.py || true
fi
if [ "$step" = all ] || [ "$step" = tables ]; then python3 $A/make_tables.py; fi
if [ "$step" = all ] || [ "$step" = pdf ]; then
  cd $DOC
  for f in main supplementary response cover_letter_revision; do pdflatex -interaction=nonstopmode -halt-on-error $f.tex >/dev/null 2>&1 || { echo "LaTeX error in $f"; grep -A3 '^!' $f.log | head; }; pdflatex -interaction=nonstopmode -halt-on-error $f.tex >/dev/null 2>&1 || true; done
  /usr/bin/perl $LD --flatten --graphics-markup=none main_submitted.tex main.tex > main_diff.tex 2>/dev/null
  pdflatex -interaction=nonstopmode main_diff.tex >/dev/null 2>&1 || true; pdflatex -interaction=nonstopmode main_diff.tex >/dev/null 2>&1 || true
  echo "TBD macros left: $(grep -c 'TBD' tables/numbers.tex)"; for f in main supplementary response main_diff; do echo "$f: $(pdfinfo $f.pdf 2>/dev/null | grep Pages)"; done
fi

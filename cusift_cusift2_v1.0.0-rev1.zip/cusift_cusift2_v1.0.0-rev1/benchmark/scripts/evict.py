#!/usr/bin/env python3
"""Evict the given files from the Linux page cache without root (POSIX_FADV_DONTNEED).
Only clean pages are dropped, so call os.sync() first for files written recently."""
import os, sys
os.sync()
for p in sys.argv[1:]:
    try:
        fd = os.open(p, os.O_RDONLY)
        os.fdatasync(fd) if False else None
        os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
        os.close(fd)
    except OSError as e:
        print(f"evict: {p}: {e}", file=sys.stderr)

#!/bin/bash
# Benchmark campaign for the MEP-100700 revision. Resumable: every step skips if its .json exists.
# usage: campaign.sh <phase> [<phase> ...]     phases: P1 P2 P3 P4 P5 P6 P7 P8
set -uo pipefail
source "$(dirname "$0")/common.sh"
S=$REV/scripts
log() { echo "[$(date -Is)] $*"; }
SUBJECTS="UKB HCP1 HCP3 HCP2"

best_threads() {  # argmin wall over UKB tcksift thread-scaling results, fallback 48
  python3 - <<'PY'
import json,glob,os
R=os.environ['RUNS']; best=None
for f in glob.glob(f"{R}/UKB/cpu_sift_t*_scal.json")+glob.glob(f"{R}/UKB/cpu_sift_t4_ref1.json"):
    j=json.load(open(f)); 
    if best is None or j['wall_s']<best[1]: best=(j['threads'],j['wall_s'])
print(best[0] if best else 48)
PY
}

P1() {  # mapping determinism (D08): same input, 1 thread twice, 48 threads once
  for tag in det_a det_b; do $S/run_stage1.sh UKB 1 $tag; done
  $S/run_stage1.sh UKB 48 det_c
  md5sum $RUNS/UKB/stage1_t1_det_a.mapping.bin $RUNS/UKB/stage1_t1_det_b.mapping.bin $RUNS/UKB/stage1_t48_det_c.mapping.bin > $RUNS/UKB/mapping_md5.txt
  cat $RUNS/UKB/mapping_md5.txt
}
P2() {  # reference runs at 4 threads (export the shared mapping) + GPU repeats on that mapping
  for s in $SUBJECTS; do
    $S/run_cpu_sift.sh $s 4 ref1 export
    $S/run_cpu_sift2.sh $s 4 ref1
    map=$RUNS/$s/cpu_sift_t4_ref1.mapping.bin
    $S/run_gpu_sift.sh $s $map warmup
    for r in 1 2 3 4 5; do $S/run_gpu_sift.sh $s $map rep$r; done
    $S/run_gpu_sift2.sh $s $map warmup
    for r in 1 2 3 4 5; do $S/run_gpu_sift2.sh $s $map rep$r; done
    $S/run_gpu_sift.sh $s $map single -1
    COLD=1 $S/run_stage1.sh $s 4 cold
    COLD=1 $S/run_gpu_sift.sh $s $map cold
    COLD=1 $S/run_gpu_sift2.sh $s $map cold
    $S/run_stage1.sh $s 4 warm
  done
}
P3() {  # CPU thread scaling, UKB
  for T in 8 16 24 48 2 1; do $S/run_cpu_sift2.sh UKB $T scal; $S/run_cpu_sift.sh UKB $T scal; done
}
P4() {  # CPU thread scaling, HCP2 (slowest subject); 1 thread last
  for T in 8 16 24 48 2; do $S/run_cpu_sift2.sh HCP2 $T scal; $S/run_cpu_sift.sh HCP2 $T scal; done
}
P5() {  # repeats at 4 threads
  for r in ref2 ref3; do for s in $SUBJECTS; do $S/run_cpu_sift2.sh $s 4 $r; $S/run_cpu_sift.sh $s 4 $r; done; done
}
P6() {  # repeats at the best thread count (from UKB scaling) + Stage 1 at best threads
  B=$(best_threads); log "best threads = $B"; echo $B > $RUNS/best_threads.txt
  for s in $SUBJECTS; do $S/run_stage1.sh $s $B best; done
  for r in ref1 ref2 ref3; do for s in $SUBJECTS; do $S/run_cpu_sift2.sh $s $B best_$r; $S/run_cpu_sift.sh $s $B best_$r; done; done
}
P7() {  # tractogram-size sweep on UKB and HCP2
  B=$(cat $RUNS/best_threads.txt 2>/dev/null || best_threads)
  for s in UKB HCP2; do
    d=$(subj_dir $s); full=$d/tracks_10000000.tck
    for N in 1000000 2000000 5000000; do
      t=$RUNS/$s/tracks_${N}.tck
      [ -f $t ] || $MRTRIX_STOCK/tckedit $full $t -number $N -force -quiet
      export TRACKS=$t; export TERM_N=$((N/10))
      $S/run_cpu_sift.sh $s $B size${N} export
      $S/run_gpu_sift.sh $s $RUNS/$s/cpu_sift_t${B}_size${N}.mapping.bin size${N}
      $S/run_cpu_sift2.sh $s $B size${N}
      $S/run_gpu_sift2.sh $s $RUNS/$s/cpu_sift_t${B}_size${N}.mapping.bin size${N}
      unset TRACKS; export TERM_N=1000000
    done
  done
  # 2e7 streamlines for UKB (generated once with all cores; not a timed step)
  s=UKB; d=$(subj_dir $s); t=$RUNS/$s/tracks_20000000.tck
  [ -f $t ] || $MRTRIX_STOCK/tckgen $d/wmfod_norm.mif $t -act $d/5tt_coreg.mif -seed_gmwmi $d/gmwm_seed.mif -select 20000000 -maxlength 250 -cutoff 0.06 -nthreads 24 -force -quiet
  export TRACKS=$t; export TERM_N=2000000
  $S/run_cpu_sift.sh $s $B size20000000 export
  $S/run_gpu_sift.sh $s $RUNS/$s/cpu_sift_t${B}_size20000000.mapping.bin size20000000
  $S/run_cpu_sift2.sh $s $B size20000000
  $S/run_gpu_sift2.sh $s $RUNS/$s/cpu_sift_t${B}_size20000000.mapping.bin size20000000
  unset TRACKS; export TERM_N=1000000
}
P8() {  # HCP2 single-thread point (long)
  $S/run_cpu_sift2.sh HCP2 1 scal; $S/run_cpu_sift.sh HCP2 1 scal
}
for ph in "$@"; do log "=== phase $ph start ==="; $ph; log "=== phase $ph end ==="; done

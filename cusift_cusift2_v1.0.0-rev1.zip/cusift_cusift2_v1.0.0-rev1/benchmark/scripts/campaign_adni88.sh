#!/bin/bash
# All-88 ADNI3-CN comparison at the independent-run level: GPU SIFT (on a mapping exported by the patched tcksift, -nofilter)
# against the user's own stock-tcksift output (sift_1mio.tck, 32 threads, no exported mapping).  Tier-1 subjects reuse their
# existing mapping and GPU run.  Outputs under $RUNS/adni88/<sub>/ (kept outside the ADNI* glob used by analyze.py).
set -uo pipefail
source "$(dirname "$0")/common.sh"
W=/media/ipsych/Storage_Z8_2/ADNI3_CN/mrtrix_superager_work; O=$RUNS/adni88; A=$REV/analysis; mkdir -p $O
declare -A T1; for k in "${!ADNI_MAP[@]}"; do T1[${ADNI_MAP[$k]}]=$k; done
log() { echo "[$(date -Is)] $*"; }
for d in $W/sub-*; do sub=$(basename $d); [ -f $d/tracks_10mio.tck ] && [ -f $d/sift_1mio.tck ] || continue
  o=$O/$sub; mkdir -p $o; [ -f $o/cmp_vs_user.json ] && continue
  log "=== $sub ==="
  if [ -n "${T1[$sub]:-}" ] && [ -f $RUNS/${T1[$sub]}/gpu_sift_rep1.tck ]; then gpu=$RUNS/${T1[$sub]}/gpu_sift_rep1.tck; echo "tier1 ${T1[$sub]}" > $o/source.txt
  else
    [ -f $o/map.bin ] || { /usr/bin/time -v $TCKSIFT $d/tracks_10mio.tck $d/wmfod_norm.mif $o/nofilter.tck -act $d/5tt_nocoreg.mif -nofilter -output_mapping $o/map.bin -nthreads 48 -force -quiet > $o/map.log 2> $o/map.time; rm -f $o/nofilter.tck; }
    [ -f $o/gpu_sift.tck ] || /usr/bin/time -v $SIFT_GPU $o/map.bin $d/tracks_10mio.tck $o/gpu_sift.tck 1000000 --gpu0 0 --gpu1 1 --csv $o/gpu_sift.csv --timing_json $o/gpu_sift.timing.json > $o/gpu_sift.log 2> $o/gpu_sift.time
    gpu=$o/gpu_sift.tck; echo "own" > $o/source.txt
  fi
  python3 $A/compare_sift.py $gpu $d/sift_1mio.tck $o/cmp_vs_user.json > /dev/null && log "done $sub $(python3 -c "import json;r=json.load(open('$o/cmp_vs_user.json'));print('onlyA',r['onlyA'],'overlap %.2f%%'%r['overlap_pct'])")"
done
log "campaign_adni88 finished"

#!/bin/bash
# GPU SIFT on a precomputed mapping.  usage: run_gpu_sift.sh <subj> <mapping.bin> <tag> [gpu1 (-1 = single GPU)]
set -euo pipefail
source "$(dirname "$0")/common.sh"
subj=$1; map=$2; tag=$3; gpu1=${4:-1}
o=$RUNS/$subj; mkdir -p $o; base=$o/gpu_sift_${tag}
if [ -f $base.json ]; then echo "skip $base"; exit 0; fi
tracks=$(subj_tracks $subj)
[ "$COLD" = "1" ] && evict $map $tracks
machine_state $base.state
nvidia-smi --query-gpu=index,memory.used --format=csv,noheader,nounits -lms 250 > $base.nvsmi &
nvpid=$!; nvidia-smi --query-compute-apps=gpu_uuid,pid,process_name,used_memory --format=csv,noheader,nounits -lms 250 > $base.nvapps &
nvapid=$!
t0=$(now)
/usr/bin/time -v $SIFT_GPU $map $tracks $base.tck $TERM_N --gpu0 0 --gpu1 $gpu1 --csv $base.csv --timing_json $base.timing.json --dump_gradients $base.grad.csv > $base.log 2> $base.time
t1=$(now)
kill $nvpid $nvapid 2>/dev/null || true
rss=$(grep "Maximum resident" $base.time | awk '{print $NF}')
pp=$(awk -F', ' '$3 ~ /sift/ {if($4>m[$1])m[$1]=$4} END{n=0; for(k in m){n++; printf "%s%d", (n>1?",":""), m[k]}}' $base.nvapps); [ -n "$pp" ] || pp=0
el=$(python3 -c "print($t1-$t0)")
peak0=$(awk -F', ' '$1==0{if($2>m)m=$2}END{print m+0}' $base.nvsmi); peak1=$(awk -F', ' '$1==1{if($2>m)m=$2}END{print m+0}' $base.nvsmi)
echo "{\"subject\":\"$subj\",\"cmd\":\"sift_gpu\",\"tag\":\"$tag\",\"gpu1\":$gpu1,\"wall_s\":$el,\"max_rss_kB\":$rss,\"cold\":$COLD,\"mapping\":\"$map\",\"proc_peak_MB\":\"$pp\",\"nvsmi_peak_MB_gpu0\":$peak0,\"nvsmi_peak_MB_gpu1\":$peak1}" > $base.json
echo "done $base wall=${el}s"

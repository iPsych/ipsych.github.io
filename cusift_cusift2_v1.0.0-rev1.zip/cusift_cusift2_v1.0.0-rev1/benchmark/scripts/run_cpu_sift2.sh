#!/bin/bash
# CPU reference SIFT2 (MRtrix3 tcksift2 from the same build; command unpatched).
# usage: run_cpu_sift2.sh <subj> <threads> <tag>
set -euo pipefail
source "$(dirname "$0")/common.sh"
subj=$1; T=$2; tag=$3
d=$(subj_dir $subj); o=$RUNS/$subj; mkdir -p $o
base=$o/cpu_sift2_t${T}_${tag}
if [ -f $base.json ]; then echo "skip $base"; exit 0; fi
tracks=$(subj_tracks $subj); fod=$(subj_fod $subj); act=$(subj_act $subj)
[ "$COLD" = "1" ] && evict $tracks $fod $act
machine_state $base.state
t0=$(now); echo "$t0 START" > $base.ts
/usr/bin/time -v $TCKSIFT2 -act $act -nthreads $T -csv $base.csv -out_mu $base.mu -force $tracks $fod $base.txt -info > $base.log 2> >(python3 $REV/scripts/ts.py > $base.time)
t1=$(now); echo "$t1 END" >> $base.ts; sleep 0.5
rss=$(grep "Maximum resident" $base.time | awk '{print $NF}')
el=$(python3 -c "print($t1-$t0)")
echo "{\"subject\":\"$subj\",\"cmd\":\"tcksift2\",\"threads\":$T,\"tag\":\"$tag\",\"wall_s\":$el,\"max_rss_kB\":$rss,\"cold\":$COLD,\"tracks\":\"$tracks\"}" > $base.json
echo "done $base wall=${el}s"

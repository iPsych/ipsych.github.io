#!/bin/bash
# wait for campaign.sh (742413) to exit, then run campaign2 and the ADNI tier
while kill -0 742413 2>/dev/null; do sleep 60; done
cd /media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision
bash scripts/campaign2.sh Q0 Q1 Q5 Q2 Q3 Q6 Q4 >> logs/campaign2.log 2>&1
bash scripts/campaign_adni.sh >> logs/campaign_adni.log 2>&1
echo "[$(date -Is)] chain finished" >> logs/campaign2.log

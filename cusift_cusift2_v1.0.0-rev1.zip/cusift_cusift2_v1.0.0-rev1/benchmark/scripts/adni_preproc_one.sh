#!/usr/bin/env bash
set -euo pipefail

subj="${1:-sub-941S1195}"
ROOT="/media/ipsych/Storage_Z8_2/ADNI3_CN"
BIDS="$ROOT/BIDS_DTI_T1_89"
export SUBJECTS_DIR="$ROOT/fs74_subjects"
OUTROOT="$ROOT/mrtrix_superager_work"
OUT="$OUTROOT/$subj"
NTHREADS="${NTHREADS:-12}"

set +u
source /home/ipsych/anaconda3/etc/profile.d/conda.sh
conda activate mrtrix3
set -u

export FREESURFER_HOME="/usr/local/freesurfer/7.4.1"
export FS_LICENSE="$FREESURFER_HOME/license.txt"
set +eu
source "$FREESURFER_HOME/SetUpFreeSurfer.sh" >/dev/null
set -eu

mkdir -p "$OUT" "$OUT/INPUTS" "$OUT/OUTPUTS"
cd "$OUTROOT"

dwi="$(find "$BIDS/$subj" -path '*/dwi/*_dwi.nii.gz' | sort | head -n 1)"
[ -n "$dwi" ] || { echo "No DWI found for $subj"; exit 1; }
base="${dwi%.nii.gz}"
bvec="${base}.bvec"
bval="${base}.bval"
[ -s "$bvec" ] && [ -s "$bval" ] || { echo "Missing bvec/bval for $dwi"; exit 1; }
[ -s "$SUBJECTS_DIR/$subj/mri/T1.mgz" ] || { echo "Missing FS T1.mgz for $subj"; exit 1; }
[ -s "$SUBJECTS_DIR/$subj/mri/aseg.mgz" ] || { echo "Missing FS aseg.mgz for $subj"; exit 1; }

echo "SUBJECT=$subj"
echo "DWI=$dwi"
echo "BVEC=$bvec"
echo "BVAL=$bval"
echo "OUT=$OUT"
echo "CONDA_DEFAULT_ENV=${CONDA_DEFAULT_ENV:-}"
echo "MRCONVERT=$(command -v mrconvert)"
echo "DWIFSLPREPROC=$(command -v dwifslpreproc)"
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-<unset>}"
echo "EDDY_CUDA=$(command -v eddy_cuda10.2 || true)"
echo "EDDY_CPU=$(command -v eddy_cpu || true)"
nvidia-smi -L 2>/dev/null || true
ls -l /dev/nvidia* 2>/dev/null || true

# Step_01 style input conversion and denoise / Gibbs ringing correction.
mrconvert "$SUBJECTS_DIR/$subj/mri/T1.mgz" "$OUT/T1_raw.mif" -force
mrconvert "$dwi" "$OUT/dwi_raw.mif" -fslgrad "$bvec" "$bval" -force
dwidenoise "$OUT/dwi_raw.mif" "$OUT/dwi_den.mif" -noise "$OUT/noise.mif" -force
mrdegibbs -axes 0,1 "$OUT/dwi_den.mif" "$OUT/dwi_den_unr.mif" -force
dwiextract "$OUT/dwi_den_unr.mif" - -bzero -fslgrad "$bvec" "$bval" | mrmath - mean "$OUT/mean_b0_AP.mif" -axis 3 -force

mrconvert "$SUBJECTS_DIR/$subj/mri/T1.mgz" "$OUT/INPUTS/T1.nii.gz" -force
mrconvert "$dwi" "$OUT/INPUTS/DWI.nii.gz" -force
mrconvert "$OUT/mean_b0_AP.mif" "$OUT/INPUTS/b0.nii.gz" -force
cp "$bvec" "$OUT/INPUTS/bvec"
cp "$bval" "$OUT/INPUTS/bval"

# SuperAger Step_02 style preprocessing. ADNI has no Synb0 topup output staged,
# so this one-subject smoke run uses the script's rpe_none branch.
dwifslpreproc "$OUT/dwi_den_unr.mif" "$OUT/dwi_den_unr_preproc.mif" \
  -pe_dir AP -rpe_none \
  -eddy_options " --slm=linear --data_is_shelled" \
  -fslgrad "$bvec" "$bval" -force

dwibiascorrect ants "$OUT/dwi_den_unr_preproc.mif" "$OUT/dwi_den_unr_preproc_unbiased.mif" -bias "$OUT/bias.mif" -force
dwiextract "$OUT/dwi_den_unr_preproc_unbiased.mif" - -bzero | mrmath - mean "$OUT/mean_b0_preprocessed.mif" -axis 3 -force
mrconvert "$OUT/mean_b0_preprocessed.mif" "$OUT/mean_b0_preprocessed.nii.gz" -force

# The original SuperAger script imports FreeSurfer's precomputed dmri LTA.
# ADNI was not processed with FreeSurfer dmri, so register b0 to T1 directly.
mrconvert "$OUT/T1_raw.mif" "$OUT/T1_raw.nii.gz" -force
flirt -in "$OUT/mean_b0_preprocessed.nii.gz" -ref "$OUT/T1_raw.nii.gz" \
  -omat "$OUT/diff2struct_fsl.mat" -dof 6 -cost mutualinfo
transformconvert "$OUT/diff2struct_fsl.mat" "$OUT/mean_b0_preprocessed.nii.gz" "$OUT/T1_raw.nii.gz" \
  flirt_import "$OUT/diff2struct_mrtrix.txt" -force
mrtransform "$OUT/mean_b0_preprocessed.mif" -linear "$OUT/diff2struct_mrtrix.txt" "$OUT/mean_b0_preprocessed_coreg.mif" -interp nearest -force
mrtransform "$OUT/dwi_den_unr_preproc_unbiased.mif" -linear "$OUT/diff2struct_mrtrix.txt" "$OUT/dwi_den_unr_preproc_unbiased_coreg.mif" -interp nearest -force

dwi2mask "$OUT/dwi_den_unr_preproc_unbiased_coreg.mif" "$OUT/mask_den_unr_preproc_unb.mif" -fslgrad "$bvec" "$bval" -force
dwi2response dhollander "$OUT/dwi_den_unr_preproc_unbiased_coreg.mif" "$OUT/wm.txt" "$OUT/gm.txt" "$OUT/csf.txt" \
  -voxels "$OUT/voxels.mif" -mask "$OUT/mask_den_unr_preproc_unb.mif" -force
dwi2fod msmt_csd "$OUT/dwi_den_unr_preproc_unbiased_coreg.mif" -mask "$OUT/mask_den_unr_preproc_unb.mif" \
  "$OUT/wm.txt" "$OUT/wmfod.mif" "$OUT/gm.txt" "$OUT/gmfod.mif" "$OUT/csf.txt" "$OUT/csffod.mif" -force
mtnormalise "$OUT/wmfod.mif" "$OUT/wmfod_norm.mif" "$OUT/csffod.mif" "$OUT/csffod_norm.mif" \
  -mask "$OUT/mask_den_unr_preproc_unb.mif" -force

5ttgen freesurfer "$SUBJECTS_DIR/$subj/mri/aseg.mgz" "$OUT/5tt_nocoreg.mif" -force
5tt2gmwmi "$OUT/5tt_nocoreg.mif" "$OUT/gmwmSeed_nocoreg.mif" -force
tckgen -act "$OUT/5tt_nocoreg.mif" -backtrack -seed_gmwmi "$OUT/gmwmSeed_nocoreg.mif" \
  -nthreads "$NTHREADS" -select 10000000 "$OUT/wmfod_norm.mif" "$OUT/tracks_10mio.tck" -force

echo "DONE $subj"

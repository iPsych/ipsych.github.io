#!/usr/bin/env python3
"""Timestamp every stderr chunk (split on \\r and \\n) with the epoch time: '<epoch> <text>'."""
import sys, time, os
inp = os.fdopen(0, 'rb', buffering=0); out = os.fdopen(1, 'wb', buffering=0)
buf = b''
while True:
    chunk = inp.read(65536)
    if not chunk: break
    buf += chunk
    while True:
        i = min([k for k in (buf.find(b'\r'), buf.find(b'\n')) if k >= 0], default=-1)
        if i < 0: break
        line = buf[:i]; buf = buf[i+1:]
        if line.strip():
            out.write(b'%.6f %s\n' % (time.time(), line.strip()))
if buf.strip(): out.write(b'%.6f %s\n' % (time.time(), buf.strip()))

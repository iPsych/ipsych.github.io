#!/bin/bash
# Stage 1 of the GPU pathway: mapping build + serialisation only (tcksift -nofilter -output_mapping).
# usage: run_stage1.sh <subj> <threads> <tag>
set -euo pipefail
source "$(dirname "$0")/common.sh"
subj=$1; T=$2; tag=$3
o=$RUNS/$subj; mkdir -p $o; base=$o/stage1_t${T}_${tag}
if [ -f $base.json ]; then echo "skip $base"; exit 0; fi
tracks=$(subj_tracks $subj); fod=$(subj_fod $subj); act=$(subj_act $subj)
[ "$COLD" = "1" ] && evict $tracks $fod $act
machine_state $base.state
t0=$(now); echo "$t0 START" > $base.ts
/usr/bin/time -v $TCKSIFT -act $act -term_number $TERM_N -nthreads $T -nofilter -output_mapping $base.mapping.bin -force $tracks $fod $base.dummy.tck -info > $base.log 2> >(python3 $REV/scripts/ts.py > $base.time)
t1=$(now); echo "$t1 END" >> $base.ts; sleep 0.5
rm -f $base.dummy.tck
rss=$(grep "Maximum resident" $base.time | awk '{print $NF}')
el=$(python3 -c "print($t1-$t0)")
sz=$(stat -c %s $base.mapping.bin)
echo "{\"subject\":\"$subj\",\"cmd\":\"tcksift -nofilter -output_mapping\",\"threads\":$T,\"tag\":\"$tag\",\"wall_s\":$el,\"max_rss_kB\":$rss,\"cold\":$COLD,\"mapping_bytes\":$sz,\"tracks\":\"$tracks\"}" > $base.json
echo "done $base wall=${el}s"

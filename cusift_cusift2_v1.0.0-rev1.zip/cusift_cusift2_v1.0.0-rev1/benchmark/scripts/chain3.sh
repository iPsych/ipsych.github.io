#!/bin/bash
while kill -0 997093 2>/dev/null; do sleep 120; done
cd /media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision && bash scripts/campaign3.sh >> logs/campaign3.log 2>&1

#!/bin/bash
# GPU SIFT2 on a precomputed mapping.  usage: run_gpu_sift2.sh <subj> <mapping.bin> <tag> [extra sift2_cuda args...]
set -euo pipefail
source "$(dirname "$0")/common.sh"
SIFT2_GPU=${SIFT2_BIN_OVERRIDE:-$SIFT2_GPU}   # common.sh is authoritative; override only via SIFT2_BIN_OVERRIDE
case $(basename $SIFT2_GPU) in *v3*) BINVER=v3;; *v2*) BINVER=v2;; *) BINVER=v1;; esac
subj=$1; map=$2; tag=$3; shift 3
o=$RUNS/$subj; mkdir -p $o; base=$o/gpu_sift2_${tag}
if [ -f $base.json ]; then echo "skip $base"; exit 0; fi
[ "$COLD" = "1" ] && evict $map
machine_state $base.state
nvidia-smi --query-gpu=index,memory.used --format=csv,noheader,nounits -lms 250 > $base.nvsmi &
nvpid=$!; nvidia-smi --query-compute-apps=gpu_uuid,pid,process_name,used_memory --format=csv,noheader,nounits -lms 250 > $base.nvapps &
nvapid=$!
t0=$(now)
CUDA_VISIBLE_DEVICES=0 /usr/bin/time -v $SIFT2_GPU $map $base.txt --csv $base.csv --timing_json $base.timing.json "$@" > $base.log 2> $base.time
t1=$(now)
kill $nvpid $nvapid 2>/dev/null || true
rss=$(grep "Maximum resident" $base.time | awk '{print $NF}')
pp=$(awk -F', ' '$3 ~ /sift/ {if($4>m[$1])m[$1]=$4} END{n=0; for(k in m){n++; printf "%s%d", (n>1?",":""), m[k]}}' $base.nvapps); [ -n "$pp" ] || pp=0
el=$(python3 -c "print($t1-$t0)")
peak0=$(awk -F', ' '$1==0{if($2>m)m=$2}END{print m+0}' $base.nvsmi)
echo "{\"subject\":\"$subj\",\"cmd\":\"sift2_cuda\",\"tag\":\"$tag\",\"wall_s\":$el,\"max_rss_kB\":$rss,\"cold\":$COLD,\"mapping\":\"$map\",\"proc_peak_MB\":\"$pp\",\"nvsmi_peak_MB_gpu0\":$peak0,\"extra\":\"$*\",\"binary\":\"$BINVER\"}" > $base.json
echo "done $base wall=${el}s"

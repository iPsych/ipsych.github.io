#!/bin/bash
# Tier-1 evaluation of the ADNI3 CN subjects (run after campaign.sh; needs best_threads.txt).
# For every ADNIk with a 10M tractogram: CPU tcksift at best threads (exports the mapping), CPU tcksift2 at best threads,
# GPU SIFT (warm-up + 1), GPU SIFT2 (warm-up + 1), DKT nodes from FreeSurfer 7.4, connectomes and comparisons.
set -uo pipefail
source "$(dirname "$0")/common.sh"
S=$REV/scripts; A=$REV/analysis
B=$(cat $RUNS/best_threads.txt 2>/dev/null || echo 48)
log() { echo "[$(date -Is)] $*"; }
FS=/media/ipsych/Storage_Z8_2/ADNI3_CN/fs74_subjects
for k in "${!ADNI_MAP[@]}"; do :; done
for i in $(seq 1 ${#ADNI_MAP[@]}); do
  s=ADNI$i; sub=${ADNI_MAP[$s]}; d=$(subj_dir $s)
  [ -f $d/tracks_10mio.tck ] && [ -f $d/wmfod_norm.mif ] && [ -f $d/5tt_nocoreg.mif ] || { log "skip $s ($sub): not preprocessed"; continue; }
  log "=== $s ($sub) ==="
  $S/run_cpu_sift.sh $s $B best_ref1 export
  $S/run_cpu_sift2.sh $s $B best_ref1
  map=$RUNS/$s/cpu_sift_t${B}_best_ref1.mapping.bin
  $S/run_gpu_sift.sh $s $map warmup; $S/run_gpu_sift.sh $s $map rep1
  $S/run_gpu_sift2.sh $s $map warmup; $S/run_gpu_sift2.sh $s $map rep1
  # parcellation: FreeSurfer 7.4 DKT atlas (same protocol as the FastSurfer segmentation of the main subjects)
  o=$RUNS/$s/conn; mkdir -p $o
  if [ ! -f $o/nodes_dwi.mif ]; then
    $MRTRIX_STOCK/labelconvert $FS/$sub/mri/aparc.DKTatlas+aseg.mgz $A/FreeSurferColorLUT_6col.txt $MRTRIX_STOCK/../share/mrtrix3/labelconvert/fs_default.txt $o/nodes_t1.mif -force -quiet
    # the ADNI pipeline registered the DWI INTO T1 space (dwi_*_coreg.mif), so the T1-space parcellation only needs regridding
    $MRTRIX_STOCK/mrgrid $o/nodes_t1.mif regrid -template $d/mask_den_unr_preproc_unb.mif -interp nearest $o/nodes_dwi.mif -force -quiet
  fi
  CONN_THREADS=8 python3 $A/connectome.py build $s sift_cpubest sift $RUNS/$s/cpu_sift_t${B}_best_ref1.tck
  CONN_THREADS=8 python3 $A/connectome.py build $s sift_gpu sift $RUNS/$s/gpu_sift_rep1.tck
  CONN_THREADS=8 python3 $A/connectome.py build $s sift2_cpubest sift2 $d/tracks_10mio.tck $RUNS/$s/cpu_sift2_t${B}_best_ref1.txt
  CONN_THREADS=8 python3 $A/connectome.py build $s sift2_gpu sift2 $d/tracks_10mio.tck $RUNS/$s/gpu_sift2_rep1.txt
  python3 $A/connectome.py compare $s sift_gpu sift_cpubest; python3 $A/connectome.py compare $s sift2_gpu sift2_cpubest
done
log "ADNI campaign finished"

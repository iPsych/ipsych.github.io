#!/bin/bash
# Preprocess the selected ADNI3 CN subjects with the user's pipeline (minus the CPU SIFT step), sequentially, reduced threads.
REV=/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision; W=/media/ipsych/Storage_Z8_2/ADNI3_CN/mrtrix_superager_work
for s in $(python3 -c "import json; print(' '.join(json.load(open('$REV/results/adni_selection.json'))['selected']))"); do
  if [ -f $W/$s/tracks_10mio.tck ]; then echo "[$(date -Is)] skip $s"; continue; fi
  echo "[$(date -Is)] start $s"; t0=$(date +%s)
  export MRTRIX_NTHREADS=12; NTHREADS=12 nice -n 10 bash $REV/scripts/adni_preproc_one.sh $s > $REV/logs/adni_$s.log 2>&1; rc=$?
  echo "[$(date -Is)] end $s rc=$rc elapsed=$(( $(date +%s) - t0 ))s"
done
echo "[$(date -Is)] ADNI preprocessing finished"

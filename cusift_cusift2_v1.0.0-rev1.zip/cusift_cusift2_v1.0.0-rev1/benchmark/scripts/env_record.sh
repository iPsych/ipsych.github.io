#!/bin/bash
# Record hardware/software configuration for the manuscript configuration table.
source "$(dirname "$0")/common.sh"
out=$REV/results/environment.txt
{
echo "### recorded $(date -Is) on $(hostname)"
echo "## CPU"; lscpu | grep -E "Model name|^CPU\(s\)|Thread|Core|Socket|MHz|L1d|L2|L3|NUMA"
echo "## memory"; free -g | head -2; grep MemTotal /proc/meminfo
echo "## OS"; uname -a; lsb_release -d 2>/dev/null
echo "## governor: $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor) ; SMT active: $(cat /sys/devices/system/cpu/smt/active)"
echo "## storage"; lsblk -o NAME,MODEL,SIZE,ROTA,FSTYPE,MOUNTPOINT | grep -v loop; df -hT /media/ipsych/Data_4TB_01 | tail -1
echo "## GPU"; nvidia-smi --query-gpu=name,driver_version,memory.total,pcie.link.gen.max,pcie.link.width.max,clocks.max.sm,clocks.max.memory,persistence_mode --format=csv; nvidia-smi topo -m | head -4
echo "## CUDA"; /usr/local/cuda/bin/nvcc --version | tail -2; readlink -f /usr/local/cuda; g++-11 --version | head -1
echo "## build flags"; grep NVCC_FLAGS $REV/code/sift/Makefile | head -1
echo "## binaries"; md5sum $SIFT_GPU $SIFT2_GPU $TCKSIFT $TCKSIFT2
echo "## MRtrix3 (patched tree)"; $TCKSIFT -version | head -2; (cd $(dirname $MRTRIX_PATCHED)/.. && git -C /media/ipsych/Data_4TB_01/mrtrix_sandbox/mrtrix3 rev-parse HEAD; git -C /media/ipsych/Data_4TB_01/mrtrix_sandbox/mrtrix3 diff --stat | tail -1)
echo "## patch md5"; md5sum $REV/code/mrtrix3_output_mapping.patch
echo "## source md5"; md5sum $REV/code/sift/*.cu $REV/code/sift/*.cuh $REV/code/sift2/*.cu $REV/code/sift2/*.cuh
echo "## Eigen"; $TCKSIFT -version | grep -o "Eigen [0-9.]*"
echo "## python"; python3 -c "import numpy,scipy,matplotlib,nibabel,networkx;print('numpy',numpy.__version__,'scipy',scipy.__version__,'matplotlib',matplotlib.__version__,'nibabel',nibabel.__version__,'networkx',networkx.__version__)"
echo "## other processes using CPU at start"; ps -eo pid,pcpu,etime,comm --sort=-pcpu | head -4
} > $out 2>&1
echo "wrote $out"

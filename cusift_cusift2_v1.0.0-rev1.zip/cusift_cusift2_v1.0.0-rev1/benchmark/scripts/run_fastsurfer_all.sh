#!/bin/bash
# FastSurfer 2.4.2 volumetric segmentation (seg_only) for the 4 subjects -> DKT parcellation for connectomes
source /home/ipsych/anaconda3/etc/profile.d/conda.sh; conda activate fastsurfer
export FASTSURFER_HOME=/media/ipsych/Storage_Z8_3/UKBioBank/FastSurfer
export FS_LICENSE=/usr/local/freesurfer/8.1.0/license.txt
cd $FASTSURFER_HOME
run() { sid=$1; t1=$2; [ -f /media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs/fastsurfer/$sid/mri/aparc.DKTatlas+aseg.deep.mgz ] && { echo "skip $sid"; return; }
  nice -n 19 bash run_fastsurfer.sh --t1 $t1 --sid $sid --sd /media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs/fastsurfer --seg_only --threads 4 --device cuda:1 --fs_license $FS_LICENSE > /media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs/fastsurfer/$sid.log 2>&1; echo "$sid exit $?"; }
run UKB  /media/ipsych/Data_4TB_01/mrtrix_sandbox/test_Data/UKB/20252_2_0/T1/T1.nii.gz
run HCP1 /media/ipsych/Data_4TB_01/mrtrix_sandbox/test_Data/HCP/105216/T1w_MPR1/105216_3T_T1w_MPR1.nii.gz
run HCP2 /media/ipsych/Data_4TB_01/mrtrix_sandbox/test_Data/HCP/124826/T1w_MPR1/124826_3T_T1w_MPR1.nii.gz
run HCP3 /media/ipsych/Data_4TB_01/mrtrix_sandbox/test_Data/HCP/137128/T1w_MPR1/137128_3T_T1w_MPR1.nii.gz

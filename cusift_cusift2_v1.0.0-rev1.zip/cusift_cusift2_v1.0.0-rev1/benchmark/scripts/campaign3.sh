#!/bin/bash
# Clean re-measurement with the v3 SIFT2 binary (length-sorted streamlines by default), run after campaign2 + ADNI on an idle machine.
set -uo pipefail
source "$(dirname "$0")/common.sh"
S=$REV/scripts; B=$(cat $RUNS/best_threads.txt 2>/dev/null || echo 48)
log() { echo "[$(date -Is)] $*"; }
for s in UKB HCP1 HCP3 HCP2; do
  map=$RUNS/$s/cpu_sift_t4_ref1.mapping.bin
  mkdir -p $RUNS/$s/v2; for t in warmup rep1 rep2 rep3 rep4 rep5 cold mem; do for f in $RUNS/$s/gpu_sift2_$t.*; do [ -f "$f" ] && grep -q '"binary":"v3"' $RUNS/$s/gpu_sift2_$t.json 2>/dev/null || { [ -f "$f" ] && mv "$f" $RUNS/$s/v2/; }; done; done
  $S/run_gpu_sift2.sh $s $map warmup; for r in 1 2 3 4 5; do $S/run_gpu_sift2.sh $s $map rep$r; done; COLD=1 $S/run_gpu_sift2.sh $s $map cold; $S/run_gpu_sift2.sh $s $map mem
done
# reordering comparison, clean: none / length / newton x3 (UKB, HCP2)
for s in UKB HCP2; do map=$RUNS/$s/cpu_sift_t4_ref1.mapping.bin; mkdir -p $RUNS/$s/v2
  for f in $RUNS/$s/gpu_sift2_reorder_*; do [ -f "$f" ] && mv "$f" $RUNS/$s/v2/; done
  for r in 1 2 3; do $S/run_gpu_sift2.sh $s $map reorder_none_r$r --reorder none; $S/run_gpu_sift2.sh $s $map reorder_length_r$r --reorder length; $S/run_gpu_sift2.sh $s $map reorder_newton_r$r --reorder key:$RUNS/$s/newton_key.f32; done
  for k in length newton; do ln -sf $RUNS/$s/gpu_sift2_reorder_${k}_r1.txt $RUNS/$s/gpu_sift2_reorder_${k}.txt; done
done
# size sweep SIFT2 GPU points with v3
for s in UKB HCP2; do for N in 1000000 2000000 5000000 20000000; do m=$(ls $RUNS/$s/cpu_sift_t*_size${N}.mapping.bin 2>/dev/null | head -1); [ -n "$m" ] || continue
  mkdir -p $RUNS/$s/v2; for f in $RUNS/$s/gpu_sift2_size${N}.*; do [ -f "$f" ] && mv "$f" $RUNS/$s/v2/; done
  TERM_N=$((N/10)) $S/run_gpu_sift2.sh $s $m size${N}; done; done
log "campaign3 finished"
# --- redo of the seed-B reference runs that read the tractogram while tckgen was still writing it (UKB: SIFT+SIFT2; HCP2: SIFT2) + connectomes
A=$REV/analysis
for s in UKB HCP2; do t=$RUNS/$s/tracks_10000000_seedB.tck
  if [ $s = UKB ]; then export TRACKS=$t; $S/run_cpu_sift.sh $s $B seedB; unset TRACKS
    CONN_THREADS=8 python3 $A/connectome.py build $s sift_seedB sift $RUNS/$s/cpu_sift_t${B}_seedB.tck
    python3 $A/connectome.py compare $s sift_seedB sift_cpu4; fi
  export TRACKS=$t; $S/run_cpu_sift2.sh $s $B seedB; unset TRACKS
  CONN_THREADS=8 python3 $A/connectome.py build $s sift2_seedB sift2 $t $RUNS/$s/cpu_sift2_t${B}_seedB.txt
  python3 $A/connectome.py compare $s sift2_seedB sift2_cpu4
done
python3 $A/connectome.py summary
log "campaign3 seedB redo finished"

#!/bin/bash
# Every 20 s: epoch, 1-min load, total %CPU of processes NOT belonging to the benchmark (tcksift/tcksift2/sift_gpu/sift2_cuda), and the top foreign process.
out=/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision/logs/foreign_load.tsv
echo -e "epoch\tload1\tforeign_pcpu\ttop_foreign" >> $out
while true; do
  l=$(cut -d' ' -f1 /proc/loadavg)
  f=$(ps -eo pcpu,comm --no-headers | awk '$2!~/^(tcksift|tcksift2|sift_gpu|sift2_cuda|time)$/ && $1>5 {s+=$1; if($1>m){m=$1;n=$2}} END{printf "%.0f\t%s(%.0f)", s, n, m}')
  echo -e "$(date +%s)\t$l\t$f" >> $out; sleep 20
done

#!/usr/bin/env python3
"""Field-by-field comparison of two serialised mapping files. usage: mapping_diff.py A.bin B.bin [out.json]"""
import sys, json, numpy as np
def load(p):
    with open(p,'rb') as f:
        hdr=np.frombuffer(f.read(4+4+4+8+8+8),dtype=np.uint8)
    magic=int(np.frombuffer(hdr[0:4].tobytes(),'<u4')[0]); nt=int(np.frombuffer(hdr[4:8].tobytes(),'<u4')[0]); nf=int(np.frombuffer(hdr[8:12].tobytes(),'<u4')[0])
    ne=int(np.frombuffer(hdr[12:20].tobytes(),'<u8')[0]); fods=float(np.frombuffer(hdr[20:28].tobytes(),'<f8')[0]); tds=float(np.frombuffer(hdr[28:36].tobytes(),'<f8')[0])
    off=36; m=np.memmap(p,dtype=np.uint8,mode='r')
    def take(dt,n):
        nonlocal off; a=np.frombuffer(m[off:off+n*np.dtype(dt).itemsize].tobytes(),dtype=dt); off+=n*np.dtype(dt).itemsize; return a
    d=dict(magic=magic,nt=nt,nf=nf,ne=ne,FOD_sum=fods,TD_sum=tds)
    d['offsets']=take('<u8',nt+1); d['idx']=take('<u4',ne); d['len']=take('<f4',ne); d['tc']=take('<f4',nt); d['tl']=take('<f4',nt)
    d['FOD']=take('<f8',nf); d['TD']=take('<f8',nf); d['w']=take('<f8',nf); return d
a=load(sys.argv[1]); b=load(sys.argv[2]); res={}
for k in ['nt','nf','ne']: res[k+'_A']=a[k]; res[k+'_equal']=(a[k]==b[k])
for k in ['FOD_sum','TD_sum']: res[k+'_A']=a[k]; res[k+'_B']=b[k]; res[k+'_reldiff']=abs(a[k]-b[k])/abs(a[k])
for k in ['offsets','idx','len','tc','tl','FOD','TD','w']:
    if a[k].shape!=b[k].shape: res[k]='shape differs'; continue
    eq=np.array_equal(a[k],b[k]); res[k+'_identical']=bool(eq)
    if not eq:
        if a[k].dtype.kind=='f':
            d=np.abs(a[k].astype(np.float64)-b[k].astype(np.float64)); nz=np.abs(a[k].astype(np.float64))>0
            res[k+'_n_diff']=int((d>0).sum()); res[k+'_max_abs']=float(d.max()); res[k+'_max_rel']=float((d[nz]/np.abs(a[k].astype(np.float64))[nz]).max())
        else: res[k+'_n_diff']=int((a[k]!=b[k]).sum())
print(json.dumps(res,indent=1,default=str))
if len(sys.argv)>3: json.dump(res,open(sys.argv[3],'w'),indent=1,default=str)

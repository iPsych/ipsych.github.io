#!/usr/bin/env python3
"""Compare two mapping files allowing for a permutation of fixel labels (multi-threaded FOD segmentation
numbers fixels in a thread-dependent order). usage: mapping_diff_relabel.py A.bin B.bin [out.json]"""
import sys, json, numpy as np
sys.path.insert(0, __file__.rsplit('/',1)[0])
from mapping_diff import load
a=load(sys.argv[1]); b=load(sys.argv[2]); res={}
nf=a['nf']; ne=a['ne']
# empirical label map from CSR entries: A label -> B label (must be a bijection on the labels that occur)
ia=a['idx']; ib=b['idx']
m=np.full(nf,-1,dtype=np.int64)
# use first occurrence; then check consistency on all entries
first=np.full(nf,-1,dtype=np.int64)
seen=np.zeros(nf,dtype=bool)
# vectorised: sort by A label, take first position
order=np.argsort(ia,kind='stable'); ia_s=ia[order]; firstpos=np.searchsorted(ia_s,np.arange(nf),side='left')
valid=firstpos<ne
lab_ok=valid & (ia_s[np.minimum(firstpos,ne-1)]==np.arange(nf))
m[lab_ok]=ib[order[firstpos[lab_ok]]]
consistent=bool(np.all(m[ia]==ib))
res['label_map_consistent_on_all_entries']=consistent
used=m[m>=0]; res['n_labels_used']=int(len(used)); res['bijective']=bool(len(np.unique(used))==len(used))
# per-fixel arrays after relabelling
for k in ['FOD','w','TD']:
    A=a[k][m>=0]; B=b[k][m[m>=0]]
    d=np.abs(A-B); nz=np.abs(A)>0
    res[k+'_identical_after_relabel']=bool(np.array_equal(A,B)); res[k+'_n_diff']=int((d>0).sum()); res[k+'_max_abs']=float(d.max()) if len(d) else 0.0
    res[k+'_max_rel']=float((d[nz]/np.abs(A)[nz]).max()) if nz.any() else 0.0
res['len_identical']=bool(np.array_equal(a['len'],b['len'])); res['offsets_identical']=bool(np.array_equal(a['offsets'],b['offsets']))
res['tc_identical']=bool(np.array_equal(a['tc'],b['tc'])); res['tl_identical']=bool(np.array_equal(a['tl'],b['tl']))
res['FOD_sum_reldiff']=abs(a['FOD_sum']-b['FOD_sum'])/abs(a['FOD_sum']); res['TD_sum_reldiff']=abs(a['TD_sum']-b['TD_sum'])/abs(a['TD_sum'])
print(json.dumps(res,indent=1))
if len(sys.argv)>3: json.dump(res,open(sys.argv[3],'w'),indent=1)

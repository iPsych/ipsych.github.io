#!/usr/bin/env python3
"""Supplementary figures: S3 cost trajectories, S4 gradient gap, S5 CPU floors, S6 Newton histogram (+ extra.json entries for Newton/roofline).
usage: fig_si.py --figdir <dir>"""
import argparse, json, os, re, glob, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
REV = '/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision'; RUNS = '/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs'
SUBJ = ['UKB', 'HCP1', 'HCP2', 'HCP3']; LAB = {'UKB': 'UKB', 'HCP1': 'HCP-1', 'HCP2': 'HCP-2', 'HCP3': 'HCP-3'}
ap = argparse.ArgumentParser(); ap.add_argument('--figdir', required=True); a = ap.parse_args()
runs = json.load(open(f'{REV}/results/runs.json')); cmpj = json.load(open(f'{REV}/results/comparisons.json'))
extra_p = f'{REV}/results/extra.json'; extra = json.load(open(extra_p)) if os.path.exists(extra_p) else {}
def R(s, name): return [r for r in runs if r['subject'] == s and r['name'] == name]
def csv_rows(p, ncol=7):
    return np.array([[float(x) for x in l.split(',')[:ncol]] for l in open(p) if l.strip() and l[0].isdigit()])

# ---------------- S3 cost trajectories
fig, axes = plt.subplots(2, 4, figsize=(15, 7))
for j, s in enumerate(SUBJ):
    ax = axes[0, j]; cp = f'{RUNS}/{s}/cpu_sift_t4_ref1.csv'; gp = f'{RUNS}/{s}/gpu_sift_rep1.csv'
    if os.path.exists(cp) and os.path.exists(gp):
        c = csv_rows(cp); g = csv_rows(gp)
        ax.plot(c[:, 2], c[:, 4], 'k-', lw=1.5, label='CPU'); ax.plot(g[:, 2], g[:, 4], 'r--', lw=1, label='GPU'); ax.set_yscale('log')
        ci = np.interp(g[:, 2], c[:, 2], c[:, 4]); ins = ax.inset_axes([0.45, 0.45, 0.5, 0.45]); ins.plot(g[:, 2], np.abs(g[:, 4] - ci) / ci, 'b-', lw=0.6); ins.set_yscale('log'); ins.set_title('rel. diff.', fontsize=7); ins.tick_params(labelsize=6)
    ax.set_title(f'SIFT, {LAB[s]}', fontsize=10); ax.set_xlabel('removed streamlines'); ax.set_ylabel('cost'); ax.legend(fontsize=7, loc='lower left')
    ax = axes[1, j]; cp = f'{RUNS}/{s}/cpu_sift2_t4_ref1.csv'; gp = f'{RUNS}/{s}/gpu_sift2_rep1.csv'
    if os.path.exists(cp) and os.path.exists(gp):
        c = csv_rows(cp, 6)[1:]; g = csv_rows(gp, 5)
        ax.plot(c[:, 0], c[:, 5], 'k-', lw=1.5, label=f'CPU ({len(c)} it.)'); ax.plot(g[:, 0], g[:, 4], 'r--', lw=1, label=f'GPU corrected ({len(g)} it.)')
        v1p = f'{RUNS}/{s}/gpu_sift2_v1.csv'
        if os.path.exists(v1p):
            v = csv_rows(v1p, 5); ax.plot(v[:, 0], v[:, 4], 'b:', lw=1, label=f'GPU submitted version ({len(v)} it.)')
        n = min(len(c), len(g)); ins = ax.inset_axes([0.45, 0.45, 0.5, 0.45]); ins.plot(np.arange(1, n + 1), np.abs(g[:n, 4] - c[:n, 5]) / c[:n, 5], 'b-', lw=0.8); ins.set_yscale('log'); ins.set_title('rel. diff.', fontsize=7); ins.tick_params(labelsize=6)
    ax.set_title(f'SIFT2, {LAB[s]}', fontsize=10); ax.set_xlabel('outer iteration'); ax.set_ylabel('total cost'); ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig(f'{a.figdir}/figS3_cost_trajectories.pdf', dpi=200); plt.close(fig)

# ---------------- S4 gradient gap
fig, axes = plt.subplots(1, 2, figsize=(11, 4)); gaps_all = {}
for s in SUBJ:
    p = f'{RUNS}/{s}/gpu_sift_rep1.grad.csv'
    if not os.path.exists(p): continue
    g = np.loadtxt(p, delimiter=',', skiprows=1); gn = g[:2000, 2]; ok = np.isfinite(gn) & (gn < 0); gn = gn[ok]
    axes[0].plot(np.arange(len(gn)), -gn, lw=1, label=LAB[s]); rel = np.abs(np.diff(gn)) / np.abs(gn[:-1]); gaps_all[s] = rel
    axes[1].hist(np.clip(rel, 1e-17, None), bins=np.logspace(-17, 0, 70), histtype='step', lw=1.3, label=LAB[s])
axes[0].set_yscale('log'); axes[0].set_xlabel('rank in sorted candidate list (final state)'); axes[0].set_ylabel(r'$-\Delta f_s$ / contribution'); axes[0].legend(fontsize=8); axes[0].set_title('(a) normalised cost reduction of the best candidates', fontsize=9, loc='left')
axes[1].set_xscale('log'); axes[1].set_xlabel('relative gap between neighbouring candidates'); axes[1].set_ylabel('count'); axes[1].legend(fontsize=8); axes[1].set_title('(b) gaps between neighbours (first 2000 candidates)', fontsize=9, loc='left')
fig.tight_layout(); fig.savefig(f'{a.figdir}/figS4_gradient_gap.pdf', dpi=200); plt.close(fig)

# ---------------- S5 floors (SIFT2 |dw| distributions per subject)
def load_w(p):
    npy = p + '.npy'
    if os.path.exists(npy): return np.load(npy)
    with open(p) as f: w = np.concatenate([np.fromstring(l, sep=' ') for l in f if l.strip() and not l.startswith('#')])
    np.save(npy, w); return w
fig, axes = plt.subplots(1, 4, figsize=(16, 3.8)); bins = np.logspace(-12, 0, 120)
for j, s in enumerate(SUBJ):
    ax = axes[j]; ref = f'{RUNS}/{s}/cpu_sift2_t4_ref1.txt'
    if not os.path.exists(ref): continue
    wr = load_w(ref)
    for name, pat, col in [('GPU vs CPU 4 thr.', 'gpu_sift2_rep1.txt', '#d62728'), ('CPU 4 thr. repeat', 'cpu_sift2_t4_ref2.txt', '#1f77b4'), ('CPU best vs 4 thr.', None, '#2ca02c'), ('CPU 96 vs 4 thr.', 'cpu_sift2_t96_scal.txt', '#9467bd')]:
        if pat is None:
            c = glob.glob(f'{RUNS}/{s}/cpu_sift2_t*_best_ref1.txt'); p = c[0] if c else None
        else: p = f'{RUNS}/{s}/{pat}'
        if p and os.path.exists(p):
            d = np.abs(load_w(p) - wr); ax.hist(np.clip(d, 1e-12, None), bins=bins, histtype='step', lw=1.4, color=col, label=f'{name} (max {d.max():.1e})')
    ax.set_xscale('log'); ax.set_yscale('log'); ax.set_title(LAB[s], fontsize=10); ax.set_xlabel(r'$|\Delta w|$'); ax.legend(fontsize=6.5)
axes[0].set_ylabel('streamlines'); fig.tight_layout(); fig.savefig(f'{a.figdir}/figS5_cpu_floors.pdf', dpi=200); plt.close(fig)

# ---------------- S6 Newton histogram + divergence loss + roofline numbers
fig, axes = plt.subplots(1, 2, figsize=(11, 4)); rows = []
NW = []
for s in ['UKB', 'HCP2']:
    files = sorted(glob.glob(f'{RUNS}/{s}/newton_iter*.u8'), key=lambda p: int(re.search(r'iter(\d+)', p).group(1)))
    if not files: continue
    losses = []; allcounts = []
    for p in files:
        it = int(re.search(r'iter(\d+)', p).group(1)); n = np.fromfile(p, dtype=np.uint8).astype(float); allcounts.append(n)
        nw = (len(n) // 32) * 32; w = n[:nw].reshape(-1, 32); loss = 1 - w.mean(1).sum() / w.max(1).sum(); losses.append((it, loss, n.mean(), np.median(n), n.max()))
        if it in (1, 5, len(files)): axes[0].hist(n, bins=np.arange(0.5, n.max() + 1.5), histtype='step', lw=1.3, label=f'{LAB[s]}, outer iteration {it}')
    L = np.array(losses); axes[1].plot(L[:, 0], 100 * L[:, 1], marker='.', label=LAB[s])
    allc = np.concatenate(allcounts)
    # roofline estimate: bytes and flops per Newton step per CSR entry (see manuscript): 52 B gathered + 8 B CSR; ~110 FP64 ops incl. 2 exp (~25 each)
    g2 = R(s, 'gpu_sift2_rep1'); entries = g2[0]['total_entries'] if g2 else None; k1 = g2[0]['kernel1_ms'] / 1000 if g2 else None
    if entries and k1:
        steps = sum(c.sum() for c in allcounts) / len(allcounts)  # mean Newton steps per outer iteration (sum over streamlines)
        mean_newton = allc.mean(); n_outer = len(files)
        bytes_total = n_outer * mean_newton * entries * 60; flops = n_outer * mean_newton * entries * 110
        rows.append([LAB[s], f'{np.median(allc):.0f} / {mean_newton:.2f} / {allc.max():.0f}', f'{100*np.mean(L[:,1]):.1f}\\%', f'{k1:.1f}', f'{bytes_total/1e9:.0f}', f'{bytes_total/1e9/k1:.0f} ({100*bytes_total/1e9/k1/936:.0f}\\%)', f'{flops/1e9:.0f}', f'{flops/1e9/k1:.0f} ({100*flops/1e9/k1/560:.0f}\\%)'])
        NW.append(dict(med=np.median(allc), mx=allc.max(), meanovermax=100*(1-np.mean(L[:,1])), loss=100*np.mean(L[:,1]), first=100*L[0,1], fp=100*flops/1e9/k1/560, bw=100*bytes_total/1e9/k1/936))
def _r(k, nd=0, pct=False):
    v=[d[k] for d in NW]; lo,hi=min(v),max(v); f=lambda x: f'{x:.{nd}f}'; t=(f(lo) if abs(hi-lo)<10**-nd else f'{f(lo)}--{f(hi)}'); return t+('\\%' if pct else '')
if NW: extra.update(NewtonMedian=_r('med'), NewtonMax=_r('mx'), NewtonWarpMeanOverMax=_r('meanovermax',pct=True), NewtonDivergenceLoss=_r('loss',pct=True), NewtonFirstIterLoss=_r('first',pct=True), NewtonFPutil=_r('fp',pct=True), NewtonBWutil=_r('bw',pct=True))
axes[0].set_xlabel('Newton iterations per streamline'); axes[0].set_ylabel('streamlines'); axes[0].set_yscale('log'); axes[0].legend(fontsize=7); axes[0].set_title('(a) Newton iteration counts', fontsize=9, loc='left')
axes[1].set_xlabel('outer iteration'); axes[1].set_ylabel('warp divergence loss, 1 $-$ mean/max (%)'); axes[1].legend(fontsize=8); axes[1].set_title('(b) per-warp divergence loss', fontsize=9, loc='left')
fig.tight_layout(); fig.savefig(f'{a.figdir}/figS6_newton_histogram.pdf', dpi=200); plt.close(fig)
if rows: extra['roofline_rows'] = rows
# reorder effect
for s in ['UKB', 'HCP2']:
    base = [r['kernel1_ms'] for r in runs if r['subject'] == s and re.fullmatch(r'gpu_sift2_reorder_none_r\d', r['name'])]
    tot0 = [r['t_optimise'] for r in runs if r['subject'] == s and re.fullmatch(r'gpu_sift2_reorder_none_r\d', r['name'])]
    eff = {}; efft = {}
    for k in ['length', 'newton']:
        v = [r['kernel1_ms'] for r in runs if r['subject'] == s and re.fullmatch(rf'gpu_sift2_reorder_{k}_r\d', r['name'])]
        t = [r['t_optimise'] for r in runs if r['subject'] == s and re.fullmatch(rf'gpu_sift2_reorder_{k}_r\d', r['name'])]
        if base and v: eff[k] = 100 * (np.median(v) / np.median(base) - 1); efft[k] = 100 * (np.median(t) / np.median(tot0) - 1)
    if eff: extra.setdefault('reorder', {})[s] = dict(kernel1_pct=eff, total_pct=efft)
if extra.get('reorder'):
    ks = [v for s in extra['reorder'].values() for v in s['kernel1_pct'].values()]; ts = [v for s in extra['reorder'].values() for v in s['total_pct'].values()]
    extra['ReorderEffectRange'] = f'{min(ks):+.0f}\\% to {max(ks):+.0f}\\%'; extra['ReorderEffectTotalRange'] = f'{min(ts):+.0f}\\% to {max(ts):+.0f}\\%'
json.dump(extra, open(extra_p, 'w'), indent=1); print('SI figures written; extra.json updated')

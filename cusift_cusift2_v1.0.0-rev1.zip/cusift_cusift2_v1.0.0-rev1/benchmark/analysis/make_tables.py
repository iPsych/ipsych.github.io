#!/usr/bin/env python3
"""Generate every table and every number macro of the revised manuscript from results/*.json.
Missing data -> macro value '[TBD]' so the documents always compile."""
import os, json, glob, re, math
import numpy as np

REV = '/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision'
RES = f'{REV}/results'
RUNS_DIR = '/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs'
OUT = '/media/ipsych/Storage_Z8_3/M2561_CUDA_SIFT_SIFT2/M2561_CUDA_SIFT_SIFT2/Submission_MEP_IOP/1st_Revision/revised/tables'
SUBJECTS = ['UKB', 'HCP1', 'HCP2', 'HCP3']; LAB = {'UKB': 'UKB', 'HCP1': 'HCP-1', 'HCP2': 'HCP-2', 'HCP3': 'HCP-3'}
runs = json.load(open(f'{RES}/runs.json')) if os.path.exists(f'{RES}/runs.json') else []
cmp = json.load(open(f'{RES}/comparisons.json')) if os.path.exists(f'{RES}/comparisons.json') else {'sift': {}, 'sift2': {}}
conn = json.load(open(f'{RES}/connectome.json')) if os.path.exists(f'{RES}/connectome.json') else {}
extra = json.load(open(f'{RES}/extra.json')) if os.path.exists(f'{RES}/extra.json') else {}
conn_pairs = json.load(open(f'{RES}/connectome_pairs.json')) if os.path.exists(f'{RES}/connectome_pairs.json') else {}
M = {}  # macros
TBD = r'\textbf{[TBD]}'

def R(subj, name): return [r for r in runs if r['subject'] == subj and r['name'] == name]
def Rg(subj, pattern): return [r for r in runs if r['subject'] == subj and re.fullmatch(pattern, r['name'])]
CLEAN_ONLY = os.environ.get('CLEAN_ONLY', '1') == '1'
def vals(rs, key):
    """values of key; timing keys use only runs not contaminated by foreign CPU load when at least one clean run exists"""
    timing = key in ('wall_s', 't_opt_s', 't_pre_s', 't_write_s', 't_optimise', 't_total', 't_read_mapping', 't_alloc_h2d', 't_prep_alloc_h2d', 't_write_tck', 't_write', 'kernel1_ms', 'rest_ms', 'gpu_part_s', 'host_part_s')
    if CLEAN_ONLY and timing:
        clean = [r for r in rs if r.get(key) is not None and not r.get('contaminated')]
        if clean: rs = clean
    return [r[key] for r in rs if r.get(key) is not None]
def med(x): return float(np.median(x)) if len(x) else None
def fmt(x, nd=0):
    if x is None or (isinstance(x, float) and math.isnan(x)): return TBD
    if nd == 0: return f'{x:,.0f}'.replace(',', '\\,')
    return f'{x:.{nd}f}'
def rng(xs, nd=0, unit=''):
    xs = [x for x in xs if x is not None]
    if not xs: return TBD
    lo, hi = min(xs), max(xs)
    if lo == hi: return fmt(lo, nd) + unit
    return f'{fmt(lo, nd)}--{fmt(hi, nd)}{unit}'
def sci(x, nd=1):
    if x is None: return TBD
    if x == 0: return '0'
    e = int(math.floor(math.log10(abs(x)))); m = x / 10 ** e
    return f'${m:.{nd}f}\\times10^{{{e}}}$'
def times(x, nd=0):
    return TBD if x is None else f'{x:.{nd}f}$\\times$'
def timesrng(xs, nd=0):
    xs = [x for x in xs if x is not None]
    if not xs: return TBD
    lo, hi = min(xs), max(xs)
    return f'{lo:.{nd}f}$\\times$' if abs(lo - hi) < 0.05 else f'{lo:.{nd}f}--{hi:.{nd}f}$\\times$'
def medrange(xs, nd=0):
    xs = [x for x in xs if x is not None]
    if not xs: return TBD
    if len(xs) == 1: return fmt(xs[0], nd)
    return f'{fmt(med(xs), nd)} [{fmt(min(xs), nd)}--{fmt(max(xs), nd)}]'
def cv(xs):
    xs = [x for x in xs if x is not None]
    return 100 * np.std(xs, ddof=1) / np.mean(xs) if len(xs) > 1 else None

best = None
if os.path.exists('/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs/best_threads.txt'):
    best = int(open('/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs/best_threads.txt').read().strip())
M['BestThreads'] = str(best) if best else TBD

# ------------------------------------------------------------------ per-subject summaries
S = {}
for s in SUBJECTS:
    d = {}
    d['cpu4_sift'] = R(s, 'cpu_sift_t4_ref1') + R(s, 'cpu_sift_t4_ref2') + R(s, 'cpu_sift_t4_ref3')
    d['cpu4_sift2'] = R(s, 'cpu_sift2_t4_ref1') + R(s, 'cpu_sift2_t4_ref2') + R(s, 'cpu_sift2_t4_ref3')
    d['cpub_sift'] = Rg(s, r'cpu_sift_t\d+_best_ref\d') if best else []
    d['cpub_sift2'] = Rg(s, r'cpu_sift2_t\d+_best_ref\d') if best else []
    d['gpu_sift'] = [r for r in Rg(s, r'gpu_sift_rep\d')]
    d['gpu_sift2'] = [r for r in Rg(s, r'gpu_sift2_rep\d')]
    d['gpu_sift_single'] = R(s, 'gpu_sift_single'); d['gpu_sift_cold'] = R(s, 'gpu_sift_cold'); d['gpu_sift2_cold'] = R(s, 'gpu_sift2_cold')
    d['stage1_4'] = R(s, 'stage1_t4_warm'); d['stage1_4cold'] = R(s, 'stage1_t4_cold'); d['stage1_best'] = Rg(s, r'stage1_t\d+_best')
    # medians
    d['cpu4_sift_e2e'] = med(vals(d['cpu4_sift'], 'wall_s')); d['cpu4_sift_opt'] = med(vals(d['cpu4_sift'], 't_opt_s'))
    d['cpu4_sift2_e2e'] = med(vals(d['cpu4_sift2'], 'wall_s')); d['cpu4_sift2_opt'] = med(vals(d['cpu4_sift2'], 't_opt_s'))
    d['cpub_sift_e2e'] = med(vals(d['cpub_sift'], 'wall_s')); d['cpub_sift_opt'] = med(vals(d['cpub_sift'], 't_opt_s'))
    d['cpub_sift2_e2e'] = med(vals(d['cpub_sift2'], 'wall_s')); d['cpub_sift2_opt'] = med(vals(d['cpub_sift2'], 't_opt_s'))
    d['gpu_sift_opt'] = med(vals(d['gpu_sift'], 't_optimise')); d['gpu_sift_total'] = med(vals(d['gpu_sift'], 't_total'))
    d['gpu_sift2_opt'] = med(vals(d['gpu_sift2'], 't_optimise')); d['gpu_sift2_total'] = med(vals(d['gpu_sift2'], 't_total'))
    d['gpu_sift_single_opt'] = med(vals(d['gpu_sift_single'], 't_optimise'))
    d['st1_4'] = med(vals(d['stage1_4'], 'wall_s')); d['st1_4cold'] = med(vals(d['stage1_4cold'], 'wall_s')); d['st1_best'] = med(vals(d['stage1_best'], 'wall_s'))
    d['gpu_sift_e2e_4'] = (d['st1_4'] + d['gpu_sift_total']) if d['st1_4'] and d['gpu_sift_total'] else None
    d['gpu_sift_e2e_best'] = (d['st1_best'] + d['gpu_sift_total']) if d['st1_best'] and d['gpu_sift_total'] else None
    d['gpu_sift2_e2e_4'] = (d['st1_4'] + d['gpu_sift2_total']) if d['st1_4'] and d['gpu_sift2_total'] else None
    d['gpu_sift2_e2e_best'] = (d['st1_best'] + d['gpu_sift2_total']) if d['st1_best'] and d['gpu_sift2_total'] else None
    gc = d['gpu_sift_cold']; g2c = d['gpu_sift2_cold']
    d['gpu_sift_e2e_cold'] = (d['st1_4cold'] + gc[0]['t_total']) if d['st1_4cold'] and gc and gc[0].get('t_total') else None
    d['gpu_sift2_e2e_cold'] = (d['st1_4cold'] + g2c[0]['t_total']) if d['st1_4cold'] and g2c and g2c[0].get('t_total') else None
    def ratio(a, b): return (a / b) if (a and b) else None
    d['su_sift_4'] = ratio(d['cpu4_sift_opt'], d['gpu_sift_opt']); d['su_sift_b'] = ratio(d['cpub_sift_opt'], d['gpu_sift_opt'])
    d['su_sift2_4'] = ratio(d['cpu4_sift2_opt'], d['gpu_sift2_opt']); d['su_sift2_b'] = ratio(d['cpub_sift2_opt'], d['gpu_sift2_opt'])
    d['su_sift_e2e_4'] = ratio(d['cpu4_sift_e2e'], d['gpu_sift_e2e_4']); d['su_sift_e2e_b'] = ratio(d['cpub_sift_e2e'], d['gpu_sift_e2e_best'])
    d['su_sift2_e2e_4'] = ratio(d['cpu4_sift2_e2e'], d['gpu_sift2_e2e_4']); d['su_sift2_e2e_b'] = ratio(d['cpub_sift2_e2e'], d['gpu_sift2_e2e_best'])
    # iterations
    d['gpu_iters'] = med(vals(d['gpu_sift'], 'iterations')); d['cpu_iters'] = med(vals(d['cpu4_sift'], 'iterations'))
    d['gpu_rem_mean'] = med(vals(d['gpu_sift'], 'removals_per_iter_mean')); d['gpu_rem_first'] = med(vals(d['gpu_sift'], 'removals_first')); d['gpu_rem_last'] = med(vals(d['gpu_sift'], 'removals_last'))
    d['gpu_part'] = med(vals(d['gpu_sift'], 'gpu_part_s')); d['host_part'] = med(vals(d['gpu_sift'], 'host_part_s'))
    d['gpu2_iters'] = med(vals(d['gpu_sift2'], 'iterations')); d['cpu2_iters'] = med(vals(d['cpu4_sift2'], 'iterations'))
    d['entries'] = (d['gpu_sift'] or d['gpu_sift2'] or [{}])[0].get('total_entries'); d['fixels'] = (d['gpu_sift'] or d['gpu_sift2'] or [{}])[0].get('num_fixels')
    d['mem0'] = med(vals(d['gpu_sift'], 'gpu0_mem_MB')); d['mem1'] = med(vals(d['gpu_sift'], 'gpu1_mem_MB')); d['mem2'] = med(vals(d['gpu_sift2'], 'device_mem_used_MB'))
    d['map_bytes'] = (d['stage1_4'] or d['stage1_4cold'] or [{}])[0].get('mapping_bytes')
    d['t_read_warm'] = med(vals(d['gpu_sift'], 't_read_mapping')); d['t_read_cold'] = gc[0].get('t_read_mapping') if gc else None
    d['t_h2d'] = med(vals(d['gpu_sift'], 't_alloc_h2d')); d['t_h2d_sift2'] = med(vals(d['gpu_sift2'], 't_prep_alloc_h2d')); d['t_write_sift'] = med(vals(d['gpu_sift'], 't_write_tck')); d['t_write_sift2'] = med(vals(d['gpu_sift2'], 't_write'))
    d['k1_share'] = None
    if d['gpu_sift2']:
        k1 = med(vals(d['gpu_sift2'], 'kernel1_ms')); rest = med(vals(d['gpu_sift2'], 'rest_ms'))
        if k1 and rest: d['k1_share'] = k1 / (k1 + rest)
    # agreement
    cs = cmp['sift'].get(s, {}); c2 = cmp['sift2'].get(s, {})
    g = cs.get('gpu_vs_cpu4'); d['unique'] = (g['onlyA'] + g['onlyB']) // 2 if g else None; d['uniqueA'] = g['onlyA'] if g else None; d['uniqueB'] = g['onlyB'] if g else None
    d['overlap'] = g['overlap_pct'] if g else None
    d['gpu_gpu_sift'] = [cs[k]['onlyA'] + cs[k]['onlyB'] for k in cs if k.startswith('gpu_vs_gpu')]
    d['cpu_cpu_same_sift'] = [(cs[k]['onlyA'] + cs[k]['onlyB']) // 2 for k in cs if k.startswith('cpu4_vs_cpu4') or k.startswith('cpubest_vs_cpubest')]
    d['cpu_cpu_diff_sift'] = [(cs[k]['onlyA'] + cs[k]['onlyB']) // 2 for k in cs if re.match(r'cpu\d+_vs_cpu4', k) or k == 'cpubest_vs_cpu4']
    d['cpu1b_sift'] = cs.get('cpu1b_vs_cpu1')
    w = c2.get('gpu_vs_cpu4'); d['w'] = w
    d['gpu_gpu_sift2'] = [c2[k]['max_abs'] for k in c2 if k.startswith('gpu_vs_gpu')]
    d['cpu_cpu_same_sift2'] = [c2[k]['max_abs'] for k in c2 if k.startswith('cpu4_vs_cpu4') or k.startswith('cpubest_vs_cpubest')]
    d['cpu_cpu_diff_sift2'] = [c2[k]['max_abs'] for k in c2 if re.match(r'cpu\d+_vs_cpu4', k) or k == 'cpubest_vs_cpu4']
    d['cpu1b_sift2'] = c2.get('cpu1b_vs_cpu1')
    # objective values
    gi = d['gpu_sift2'][0] if d['gpu_sift2'] else {}; ci = d['cpu4_sift2'][0] if d['cpu4_sift2'] else {}
    if gi.get('cf_data_final') and ci.get('cf_data_final'):
        d['cf_rel'] = abs((gi['cf_data_final'] + gi['cf_reg_final']) - ci['cf_total_final']) / ci['cf_total_final']
    else: d['cf_rel'] = None
    gs = d['gpu_sift'][0] if d['gpu_sift'] else {}; cs1 = d['cpu4_sift'][0] if d['cpu4_sift'] else {}
    d['cf_rel_sift'] = abs(gs['final_cost'] - cs1['final_cost']) / cs1['final_cost'] if gs.get('final_cost') and cs1.get('final_cost') else None
    d['init_rel'] = abs(gs['initial_cost'] - cs1['initial_cost']) / cs1['initial_cost'] if gs.get('initial_cost') and cs1.get('initial_cost') else None
    S[s] = d

def all_(key): return [S[s][key] for s in SUBJECTS if S[s].get(key) is not None]

# ------------------------------------------------------------------ macros
M['SIFTspeedupFourRange'] = timesrng(all_('su_sift_4')); M['SIFTspeedupBestRange'] = timesrng(all_('su_sift_b'))
M['SIFTtwoSpeedupFourRange'] = timesrng(all_('su_sift2_4'), 1); M['SIFTtwoSpeedupBestRange'] = timesrng(all_('su_sift2_b'), 1)
M['SIFTeeSpeedupFourRange'] = timesrng(all_('su_sift_e2e_4'), 1); M['SIFTeeSpeedupBestRange'] = timesrng(all_('su_sift_e2e_b'), 1)
M['SIFTtwoEeSpeedupFourRange'] = timesrng(all_('su_sift2_e2e_4'), 1); M['SIFTtwoEeSpeedupBestRange'] = timesrng(all_('su_sift2_e2e_b'), 1)
M['SIFTuniqueRange'] = rng(all_('unique')); M['SIFToverlapRange'] = rng([x for x in all_('overlap')], 4, r'\%')
ws = [S[s]['w'] for s in SUBJECTS if S[s]['w']]
M['SIFTtwoRtwoMin'] = fmt(min(w['R2'] for w in ws), 7) if ws else TBD
M['SIFTtwoMaxAbsMax'] = sci(max(w['max_abs'] for w in ws)) if ws else TBD
M['SIFTtwoMeanAbsMax'] = sci(max(w['mean_abs'] for w in ws)) if ws else TBD
M['SIFTtwoMedianAbsRange'] = (sci(min(w['median_abs'] for w in ws)) + '--' + sci(max(w['median_abs'] for w in ws))) if ws else TBD
M['SIFTtwoPnnnAbsMax'] = sci(max(w['p999_abs'] for w in ws)) if ws else TBD
M['SIFTtwoMedRelMax'] = sci(max(w['median_rel'] for w in ws)) if ws else TBD
M['SIFTtwoPnnnRelMax'] = sci(max(w['p999_rel'] for w in ws)) if ws else TBD
M['SIFTtwoMaxRelMax'] = sci(max(w['max_rel'] for w in ws)) if ws else TBD
M['SIFTtwoMeanW'] = fmt(np.mean([w['mean_w'] for w in ws]), 2) if ws else TBD
M['CPUsiftFourEeMinMinutes'] = fmt(min(all_('cpu4_sift_e2e')) / 60) if all_('cpu4_sift_e2e') else TBD
M['CPUsiftFourEeMaxMinutes'] = fmt(max(all_('cpu4_sift_e2e')) / 60) if all_('cpu4_sift_e2e') else TBD
M['CPUsiftBestEeMinMinutes'] = fmt(min(all_('cpub_sift_e2e')) / 60) if all_('cpub_sift_e2e') else TBD
M['CPUsiftBestEeMaxMinutes'] = fmt(max(all_('cpub_sift_e2e')) / 60) if all_('cpub_sift_e2e') else TBD
M['CPUsifttwoFourEeMinMinutes'] = fmt(min(all_('cpu4_sift2_e2e')) / 60, 1) if all_('cpu4_sift2_e2e') else TBD
M['CPUsifttwoFourEeMaxMinutes'] = fmt(max(all_('cpu4_sift2_e2e')) / 60, 1) if all_('cpu4_sift2_e2e') else TBD
M['CPUsiftFourOptRange'] = rng(all_('cpu4_sift_opt')); M['CPUsiftBestOptRange'] = rng(all_('cpub_sift_opt'))
M['GPUsiftOptRange'] = rng(all_('gpu_sift_opt')); M['GPUsiftSingleOptRange'] = rng(all_('gpu_sift_single_opt'))
M['CPUsifttwoFourOptRange'] = rng(all_('cpu4_sift2_opt')); M['CPUsifttwoBestOptRange'] = rng(all_('cpub_sift2_opt')); M['GPUsifttwoOptRange'] = rng(all_('gpu_sift2_opt'))
M['CPUsiftFourEeRange'] = rng(all_('cpu4_sift_e2e')); M['CPUsiftBestEeRange'] = rng(all_('cpub_sift_e2e'))
M['CPUsifttwoFourEeRange'] = rng(all_('cpu4_sift2_e2e')); M['CPUsifttwoBestEeRange'] = rng(all_('cpub_sift2_e2e'))
M['GPUsiftEeBestRange'] = rng(all_('gpu_sift_e2e_best')); M['GPUsifttwoEeBestRange'] = rng(all_('gpu_sift2_e2e_best'))
M['StageOneFourRange'] = rng(all_('st1_4')); M['StageOneBestRange'] = rng(all_('st1_best'))
M['MapReadWarmRange'] = rng(all_('t_read_warm'), 1); M['MapReadColdRange'] = rng(all_('t_read_cold'), 1); M['HtoDRange'] = rng(all_('t_h2d'), 1); M['HtoDSifttwoRange'] = rng(all_('t_h2d_sift2'), 1)
M['OutWriteSiftRange'] = rng(all_('t_write_sift'), 1); M['OutWriteSifttwoRange'] = rng(all_('t_write_sift2'), 1)
M['GPUoverheadSiftRange'] = rng([S[s]['gpu_sift_total'] - S[s]['gpu_sift_opt'] for s in SUBJECTS if S[s]['gpu_sift_total']])
M['GPUoverheadSifttwoRange'] = rng([S[s]['gpu_sift2_total'] - S[s]['gpu_sift2_opt'] for s in SUBJECTS if S[s]['gpu_sift2_total']])
M['SharedMappingEeRange'] = rng([S[s]['st1_best'] + S[s]['gpu_sift_total'] + S[s]['gpu_sift2_total'] for s in SUBJECTS if S[s]['st1_best'] and S[s]['gpu_sift_total'] and S[s]['gpu_sift2_total']])
M['MappingSizeRange'] = rng([b / 1e9 for b in all_('map_bytes')], 1)
M['SIFTitersRange'] = rng(all_('gpu_iters')); M['SIFTitersCPURange'] = rng(all_('cpu_iters'))
M['SIFTiterDiffMax'] = fmt(max(abs(S[s]['gpu_iters'] - S[s]['cpu_iters']) for s in SUBJECTS if S[s]['gpu_iters'] and S[s]['cpu_iters'])) if any(S[s]['gpu_iters'] and S[s]['cpu_iters'] for s in SUBJECTS) else TBD
M['SIFTremovalsPerIterMean'] = fmt(np.mean(all_('gpu_rem_mean'))) if all_('gpu_rem_mean') else TBD
gp = [S[s]['gpu_part'] / (S[s]['gpu_part'] + S[s]['host_part']) for s in SUBJECTS if S[s]['gpu_part'] and S[s]['host_part']]
M['SIFTgpuShare'] = (fmt(100 * min(gp)) + '--' + fmt(100 * max(gp)) + r'\%') if gp else TBD
M['SIFThostShare'] = (fmt(100 * (1 - max(gp))) + '--' + fmt(100 * (1 - min(gp))) + r'\%') if gp else TBD
M['SIFTtwoItersRange'] = rng(all_('gpu2_iters'))
same = [s for s in SUBJECTS if S[s]['gpu2_iters'] and S[s]['cpu2_iters'] and S[s]['gpu2_iters'] == S[s]['cpu2_iters']]
M['SIFTtwoSameIterCount'] = {0: 'none', 1: 'one', 2: 'two', 3: 'three', 4: 'all four'}.get(len(same), str(len(same))) if all_('gpu2_iters') and all_('cpu2_iters') else TBD
M['SIFTtwoIterAgreement'] = ('in all four subjects' if len(same) == 4 else f'in {M["SIFTtwoSameIterCount"]} of the four subjects') if all_('cpu2_iters') else TBD
M['SIFTtwoCostRelDiffMax'] = sci(max(all_('cf_rel'))) if all_('cf_rel') else TBD
M['InitCostAgreement'] = sci(max(all_('init_rel'))) if all_('init_rel') else TBD
M['EntriesPerStreamline'] = fmt(np.mean([S[s]['entries'] / 1e7 for s in SUBJECTS if S[s]['entries']]), 1) if all_('entries') else TBD
M['TotalEntriesRange'] = (sci(min(all_('entries')), 2) + '--' + sci(max(all_('entries')), 2)) if all_('entries') else TBD
M['CSRArraysGB'] = rng([e * 8 / 1e9 for e in all_('entries')], 2)
M['NumFixelsRange'] = (sci(min(all_('fixels')), 2) + '--' + sci(max(all_('fixels')), 2)) if all_('fixels') else TBD
M['FixelArraysMB'] = fmt(max(all_('fixels')) * 8 * 5 / 1e6) if all_('fixels') else TBD
M['FixelArrayMB'] = fmt(np.mean(all_('fixels')) * 8 / 1e6, 1) if all_('fixels') else TBD
M['PerStreamlineMB'] = '400'
def ppeak(name, idx):
    out = []
    for s in SUBJECTS:
        rs = R(s, name)
        if rs and rs[0].get('proc_peak_MB'):
            v = [float(x) for x in str(rs[0]['proc_peak_MB']).split(',') if x]
            if len(v) > idx: out.append(sorted(v, reverse=True)[idx] / 1024)
    return out
M['GPUmemRange'] = rng(ppeak('gpu_sift_mem', 0), 1); M['GPUmemHelperRange'] = rng(ppeak('gpu_sift_mem', 1), 1); M['GPUmemSifttwoRange'] = rng(ppeak('gpu_sift2_mem', 0), 1)
M['GPUmemHundredM'] = extra.get('GPUmemHundredM', TBD); M['GPUmemTwentyM'] = extra.get('GPUmemTwentyM', TBD)
M['NewtonKernelShare'] = (fmt(100 * np.mean(all_('k1_share'))) + r'\%') if all_('k1_share') else TBD
for s, key in zip(SUBJECTS, ['FixelsUKB', 'FixelsHCPone', 'FixelsHCPtwo', 'FixelsHCPthree']): M[key] = fmt(S[s]['fixels']) if S[s]['fixels'] else TBD
# floors
gg = sum((S[s]['gpu_gpu_sift'] for s in SUBJECTS), []); M['SIFTgpugpu'] = rng(gg)
M['SIFTcpucpuSameRange'] = rng(sum((S[s]['cpu_cpu_same_sift'] for s in SUBJECTS), []))
M['SIFTcpucpuDiffRange'] = rng(sum((S[s]['cpu_cpu_diff_sift'] for s in SUBJECTS), []))
# run-to-run reproducibility of the reference SIFT: every reference run (any thread count, any repeat) against the 4-thread ref1 run
agree, diverge, agreeT, divT, nruns = [], [], [], [], 0
for s in SUBJECTS:
    cs = cmp['sift'].get(s, {})
    for k, v in cs.items():
        m = re.match(r'(cpu\d+b?|cpubest\d?|cpu4)_vs_cpu4(_ref\d)?$', k)
        if not m or k == 'gpu_vs_cpu4': continue
        u = (v['onlyA'] + v['onlyB']) // 2; nruns += 1
        (agree if u < 100 else diverge).append(u)
M['SIFTcpuRunsTotal'] = str(nruns) if nruns else TBD; M['SIFTcpuAgreeCount'] = str(len(agree)) if nruns else TBD; M['SIFTcpuDivergeCount'] = str(len(diverge)) if nruns else TBD
M['SIFTcpuAgreeMax'] = fmt(max(agree)) if agree else TBD
M['SIFTcpuDivergeRange'] = rng(diverge) if diverge else TBD
# spread of the final cost among the distinct reference solutions of each subject
spreads = []
for s in SUBJECTS:
    costs = [r['final_cost'] for r in runs if r['subject'] == s and r['cmd'] == 'tcksift' and r.get('final_cost') and re.search(r'_(ref\d|best_ref\d|scal2?)$', r['name'])]   # same 10M instance only (no size sweep / re-seed)
    if len(costs) > 1: spreads.append((max(costs) - min(costs)) / min(costs))
M['SIFTcpuCostSpread'] = sci(max(spreads)) if spreads else TBD
ch = cmp['sift'].get('HCP2', {}); M['SIFTcpuDivergeHCPtwoOne'] = fmt(ch['cpu1_vs_cpu4']['onlyA']) if 'cpu1_vs_cpu4' in ch else TBD
cu = cmp['sift'].get('UKB', {})
M['GPUmapTone'] = fmt(cu['gpu_map_t1_vs_gpu']['onlyA']) if 'gpu_map_t1_vs_gpu' in cu else TBD
M['GPUmapTfortyeight'] = fmt(cu['gpu_map_t48_vs_gpu']['onlyA']) if 'gpu_map_t48_vs_gpu' in cu else TBD
M['GPUmapToneVsCpuOne'] = fmt(cu['gpu_map_t1_vs_cpu1']['onlyA']) if 'gpu_map_t1_vs_cpu1' in cu else TBD
M['SIFTcpuDivergePct'] = (fmt(100 - 100 * max(diverge) / 1e6, 0) + '--' + fmt(100 - 100 * min(diverge) / 1e6, 0) + r'\%') if diverge else TBD
cc_same = sum((S[s]['cpu_cpu_same_sift2'] for s in SUBJECTS), []); cc_diff = sum((S[s]['cpu_cpu_diff_sift2'] for s in SUBJECTS), [])
M['SIFTtwoCpuCpuSameMaxAbs'] = sci(max(cc_same)) if cc_same else TBD; M['SIFTtwoCpuCpuDiffMaxAbs'] = sci(max(cc_diff)) if cc_diff else TBD
if ws and cc_diff:
    g_max = max(w['max_abs'] for w in ws)
    M['SIFTtwoFloorComparison'] = ('lies at or below that floor' if g_max <= max(cc_diff) else 'lies above that floor by a factor of up to %s for the maximum difference (%s), whereas the mean difference (%s) lies at the floor' % (sci(g_max / max(cc_diff)), M['SIFTtwoMaxAbsMax'], M['SIFTtwoMeanAbsMax']))
    M['SIFTtwoFloorFactor'] = sci(g_max / max(cc_diff))
else: M['SIFTtwoFloorComparison'] = TBD
gg2 = sum((S[s]['gpu_gpu_sift2'] for s in SUBJECTS), []); M['SIFTtwoGpuGpuMax'] = sci(max(gg2)) if gg2 else TBD
ro = extra.get('reorder', {})
def rr(kind, key):
    v = [ro[s][kind][key] for s in ro if key in ro[s].get(kind, {})]
    return (f'{-max(v):.0f}--{-min(v):.0f}' + r'\%') if v else TBD
M['ReorderLengthKernelRange'] = rr('kernel1_pct', 'length'); M['ReorderLengthTotalRange'] = rr('total_pct', 'length'); M['ReorderNewtonTotalRange'] = rr('total_pct', 'newton')
ex = [cmp['sift2'][s]['fixiter_plus1_vs_cpu4'] for s in SUBJECTS if 'fixiter_plus1_vs_cpu4' in cmp['sift2'].get(s, {})]
M['SIFTtwoExtraIterMeanAbs'] = (sci(min(w['mean_abs'] for w in ex)) + '--' + sci(max(w['mean_abs'] for w in ex))) if ex else TBD
M['SIFTtwoExtraIterMaxAbs'] = (sci(min(w['max_abs'] for w in ex)) + '--' + sci(max(w['max_abs'] for w in ex))) if ex else TBD
M['SIFTfigSubject'] = LAB[max(SUBJECTS, key=lambda s: S[s]['unique'] or -1)] if all_('unique') else TBD
M['SIFTfigUnique'] = fmt(max(all_('unique'))) if all_('unique') else TBD
M['SIFTtwoFigSubject'] = LAB[max([s for s in SUBJECTS if S[s]['w']], key=lambda s: S[s]['w']['max_abs'])] if ws else TBD
M['EtoEfigSubject'] = 'UKB'
M['CPUsiftVarRange'] = times(max(all_('cpu4_sift_opt')) / min(all_('cpu4_sift_opt')), 1) if len(all_('cpu4_sift_opt')) > 1 else TBD
M['GPUsiftVarRange'] = times(max(all_('gpu_sift_opt')) / min(all_('gpu_sift_opt')), 1) if len(all_('gpu_sift_opt')) > 1 else TBD
def minutes_rng(xs, nd=1): return rng([x / 60 for x in xs], nd)
M['CPUsiftBestOptMinutesRange'] = minutes_rng(all_('cpub_sift_opt'), 0); M['CPUsiftFourOptMinutesRange'] = minutes_rng(all_('cpu4_sift_opt'), 0)
M['GPUsiftOptMinutesRange'] = minutes_rng(all_('gpu_sift_opt'), 1); M['CPUsiftBestEeMinutesRange'] = minutes_rng(all_('cpub_sift_e2e'), 0)
M['GPUsiftEeBestMinutesRange'] = minutes_rng(all_('gpu_sift_e2e_best'), 1)
M['CPUsifttwoBestOptMinutesRange'] = minutes_rng(all_('cpub_sift2_opt'), 1); M['GPUsifttwoOptMinutesRange'] = minutes_rng(all_('gpu_sift2_opt'), 1)
if all_('cpub_sift_e2e') and all_('gpu_sift_e2e_best'):
    M['CohortCPUdays'] = fmt(1000 * np.mean(all_('cpub_sift_e2e')) / 86400); M['CohortGPUdays'] = fmt(1000 * np.mean(all_('gpu_sift_e2e_best')) / 86400, 1)
    M['CohortCPUFourDays'] = fmt(1000 * np.mean(all_('cpu4_sift_e2e')) / 86400) if all_('cpu4_sift_e2e') else TBD
else: M['CohortCPUdays'] = M['CohortGPUdays'] = M['CohortCPUFourDays'] = TBD
# CV
gcv = [cv(vals(S[s]['gpu_sift'], 't_optimise')) for s in SUBJECTS] + [cv(vals(S[s]['gpu_sift2'], 't_optimise')) for s in SUBJECTS]
ccv = [cv(vals(S[s]['cpu4_sift'], 'wall_s')) for s in SUBJECTS] + [cv(vals(S[s]['cpu4_sift2'], 'wall_s')) for s in SUBJECTS] + [cv(vals(S[s]['cpub_sift'], 'wall_s')) for s in SUBJECTS] + [cv(vals(S[s]['cpub_sift2'], 'wall_s')) for s in SUBJECTS]
M['GPUcvRange'] = rng([x for x in gcv if x is not None], 1, r'\%'); M['CPUcvRange'] = rng([x for x in ccv if x is not None], 1, r'\%')
# thread scaling
def scal(s, cmd):
    out = {}
    for r in runs:
        if r['subject'] == s and r['cmd'] == cmd and not r.get('contaminated') and re.search(r'_(scal2?|ref\d|best_ref\d)$', r['name']):   # uncontaminated runs only; 4 and best threads use the same runs as the main tables
            out.setdefault(r['threads'], []).append(r)
    return {T: (med(vals(rs, 't_opt_s')), med(vals(rs, 'wall_s'))) for T, rs in out.items()}
sc_ukb = scal('UKB', 'tcksift'); sc2_ukb = scal('UKB', 'tcksift2'); sc_h2 = scal('HCP2', 'tcksift'); sc2_h2 = scal('HCP2', 'tcksift2')
if 4 in sc_ukb and best in sc_ukb and sc_ukb[4][0] and sc_ukb[best][0]:
    M['SIFTscalingGainFourToBest'] = times(sc_ukb[4][0] / sc_ukb[best][0], 1)
    knee = min([T for T in sorted(sc_ukb) if sc_ukb[T][0] and sc_ukb[T][0] <= 1.1 * sc_ukb[best][0]] or [best]); M['SIFTscalingKnee'] = str(knee)
else: M['SIFTscalingGainFourToBest'] = M['SIFTscalingKnee'] = TBD
if 4 in sc2_ukb and best in sc2_ukb and sc2_ukb[4][0] and sc2_ukb[best][0]: M['SIFTtwoScalingGainFourToBest'] = times(sc2_ukb[4][0] / sc2_ukb[best][0], 1)
else: M['SIFTtwoScalingGainFourToBest'] = TBD
# gradient gap: relative gaps between neighbouring candidates in the sorted list at the final state (20000 best candidates)
gaps = []; small = []; mins = []
for s in SUBJECTS:
    f = f'/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs/{s}/gpu_sift_rep1.grad.csv'
    if os.path.exists(f):
        try:
            g = np.loadtxt(f, delimiter=',', skiprows=1)[:, 2]; g = g[np.isfinite(g) & (g < 0)]
            d = np.abs(np.diff(g)) / np.abs(g[:-1]); gaps.append(np.median(d)); small.append(100 * (d < 1e-8).mean()); mins.append(d[d > 0].min() if (d > 0).any() else 0.0)
        except Exception: pass
M['SIFTgradGapRel'] = (sci(min(gaps)) + '--' + sci(max(gaps))) if gaps else TBD
M['SIFTgradGapSmallPct'] = (fmt(min(small), 1) + '--' + fmt(max(small), 1) + r'\%') if small else TBD
M['SIFTgradGapMin'] = sci(min(mins)) if mins else TBD
# remaining macros from extra.json (Newton, reorder, size sweep, verification md5, code)
for k in ['NewtonMedian', 'NewtonMax', 'NewtonWarpMeanOverMax', 'NewtonDivergenceLoss', 'NewtonFirstIterLoss', 'ReorderEffectRange', 'ReorderEffectTotalRange', 'NewtonFPutil', 'NewtonBWutil',
          'SizeScalingLaw', 'SizeSpeedupRange', 'SizeSpeedupSifttwoRange', 'SizeUniqueRange', 'SizeRtwoMin', 'MemPerEntry', 'MemPerStreamline', 'MappingMDFive',
          'ConnNodes', 'ConnReseedSubjects', 'ConnSiftEdgeCorr', 'ConnSiftOnlyOneRange', 'ConnSiftOnlyOneMaxW', 'ConnSiftFrobRange', 'ConnSiftNetMaxRel', 'ConnSifttwoEdgeCorr', 'ConnSifttwoFrobRange', 'ConnSifttwoNetMaxRel',
          'ConnCpuCpuFrobRange', 'ConnReseedFrobRange', 'ConnReseedNetMaxRel', 'ConnMaxNetRel', 'ConnAssortAbsMax', 'ConnCpuCpuAssortAbsMax', 'ADNIallCount', 'ADNIallUniqueRange', 'ADNIallUniqueMedian', 'ADNIallOverlapRange', 'ADNIallOverlapMedian', 'ADNIallAgreeCount', 'ADNIallStaleCount', 'ADNIallEarlyCount', 'ADNIallEarlyCountDiffMax', 'ADNIallEarlyRange', 'CodeRepositoryURL', 'CodeReleaseTag', 'CodeDOI']:
    M[k] = extra.get(k, M.get(k, TBD))
M['MappingMDFive'] = extra.get('MappingMDFive', 'identical MD5 checksums')

# ------------------------------------------------------------------ write macros
os.makedirs(OUT, exist_ok=True)
with open(f'{OUT}/numbers.tex', 'w') as f:
    f.write('% AUTO-GENERATED by analysis/make_tables.py -- do not edit\n')
    for k, v in sorted(M.items()): f.write('\\newcommand{\\%s}{%s}\n' % (k, v))
print(f'{len(M)} macros, {sum(1 for v in M.values() if v == TBD)} TBD')

# ------------------------------------------------------------------ tables
def table(name, caption, label, header, rows, colspec, small=True, extra_pre=''):
    with open(f'{OUT}/{name}.tex', 'w') as f:
        f.write('\\begin{table}\n\\caption{%s}\n\\label{%s}\n\\centering\n%s%s\\begin{tabular}{%s}\n\\hline\n%s \\\\\n\\hline\n' % (caption, label, '\\small\n' if small else '', extra_pre, colspec, header))
        for r in rows: f.write(' & '.join(r) + ' \\\\\n')
        f.write('\\hline\n\\end{tabular}\n\\end{table}\n')

rows = []
for s in SUBJECTS:
    d = S[s]
    rows.append([LAB[s], sci(d['entries'], 2) if d['entries'] else TBD, fmt(d['fixels']) if d['fixels'] else TBD, fmt(d['gpu_iters']) if d['gpu_iters'] else TBD, fmt(d['cpu_iters']) if d['cpu_iters'] else TBD,
                 fmt(d['gpu_rem_first']) if d['gpu_rem_first'] else TBD, fmt(d['gpu_rem_mean']) if d['gpu_rem_mean'] else TBD, fmt(d['gpu_rem_last']) if d['gpu_rem_last'] else TBD,
                 (fmt(100 * d['gpu_part'] / (d['gpu_part'] + d['host_part'])) + r'\%') if d['gpu_part'] and d['host_part'] else TBD])
table('sift_iters', r'SIFT iteration statistics for the $10^7 \rightarrow 10^6$ filtering (GPU values are medians over the five repeated runs; CPU iterations from the reference \texttt{-csv} log of the 4-thread run). nnz: number of CSR entries of the mapping; removals per outer iteration are given for the first and the last iteration and as the mean; the last column is the share of the GPU optimisation time spent in the device part (gradient pass, sort, transfers) as opposed to the host candidate walk.',
      'tab:sift_iters', r'Subject & nnz & Fixels & Iterations (GPU) & Iterations (CPU) & Removals: first & mean & last & Device share', rows, 'l r r r r r r r r')

rows = []
for s in SUBJECTS:
    d = S[s]
    rows.append([LAB[s], medrange(vals(d['cpu4_sift'], 't_opt_s')), medrange(vals(d['cpub_sift'], 't_opt_s')), medrange(vals(d['gpu_sift'], 't_optimise')), fmt(d['gpu_sift_single_opt']),
                 times(d['su_sift_4']), times(d['su_sift_b']), (fmt(d['overlap'], 4) + r'\%') if d['overlap'] else TBD, (f"{d['uniqueA']} / {d['uniqueB']}" if d['uniqueA'] is not None else TBD)])
table('sift1', r'SIFT: optimisation-phase runtime and agreement, filtering from $10^7$ to $10^6$ streamlines per subject. Runtimes in seconds, median [min--max] of three CPU runs and five GPU runs; CPU: MRtrix3 \texttt{tcksift} with 4 threads and with \BestThreads\ threads (best); GPU: two RTX 3090 (dual) and one RTX 3090 (single, one run). Speed-ups are ratios of medians (dual GPU). Overlap: fraction of the $10^6$ retained streamlines common to the GPU and the 4-thread CPU output; unique: number of streamlines retained only by the GPU / only by the CPU.',
      'tab:sift1', r'Subject & CPU 4 thr. & CPU best & GPU dual & GPU single & Speed-up vs 4 thr. & vs best & Overlap & Unique GPU / CPU', rows, 'l r r r r r r r r')

rows = []
for s in SUBJECTS:
    d = S[s]; w = d['w'] or {}
    rows.append([LAB[s], medrange(vals(d['cpu4_sift2'], 't_opt_s')), medrange(vals(d['cpub_sift2'], 't_opt_s')), medrange(vals(d['gpu_sift2'], 't_optimise'), 1),
                 times(d['su_sift2_4'], 1), times(d['su_sift2_b'], 1), fmt(d['cpu2_iters']) + ' / ' + fmt(d['gpu2_iters']) if d['cpu2_iters'] and d['gpu2_iters'] else TBD,
                 fmt(w.get('R2'), 7) if w else TBD, sci(w.get('mean_abs')) if w else TBD, sci(w.get('p999_abs')) if w else TBD, sci(w.get('max_abs')) if w else TBD, sci(w.get('max_rel')) if w else TBD])
table('sift2', r'SIFT2: optimisation-phase runtime and agreement, weight estimation for $10^7$ streamlines per subject. Runtimes in seconds, median [min--max]; CPU: MRtrix3 \texttt{tcksift2} with 4 threads and with \BestThreads\ threads; GPU: one RTX 3090. Iterations: outer iterations of the CPU / GPU run. $R^2$: coefficient of determination between the GPU and CPU weight vectors; $|\Delta w|$: absolute weight difference (mean, 99.9th percentile, maximum); max $|\Delta w|/w$: maximum relative difference.',
      'tab:sift2', r'Subject & CPU 4 thr. & CPU best & GPU & Speed-up vs 4 thr. & vs best & Iter. & $R^2$ & mean $|\Delta w|$ & P99.9 & max & max rel.', rows, 'l r r r r r r r r r r r')

rows = []
for s in SUBJECTS:
    d = S[s]
    rows.append([LAB[s], 'SIFT', fmt(d['cpu4_sift_e2e']), fmt(d['cpub_sift_e2e']), fmt(d['st1_4']), fmt(d['st1_best']), fmt(d['t_read_warm'], 1), fmt(d['t_h2d'], 1), fmt(d['gpu_sift_opt']), fmt(d['t_write_sift'], 1),
                 fmt(d['gpu_sift_e2e_4']), fmt(d['gpu_sift_e2e_best']), fmt(d['gpu_sift_e2e_cold']), times(d['su_sift_e2e_4'], 1), times(d['su_sift_e2e_b'], 1)])
    rows.append(['', 'SIFT2', fmt(d['cpu4_sift2_e2e']), fmt(d['cpub_sift2_e2e']), fmt(d['st1_4']), fmt(d['st1_best']), fmt(d['t_read_warm'], 1), fmt(d['t_h2d_sift2'], 1), fmt(d['gpu_sift2_opt'], 1), fmt(d['t_write_sift2'], 1),
                 fmt(d['gpu_sift2_e2e_4']), fmt(d['gpu_sift2_e2e_best']), fmt(d['gpu_sift2_e2e_cold']), times(d['su_sift2_e2e_4'], 1), times(d['su_sift2_e2e_b'], 1)])
table('e2e', r'End-to-end wall-clock runtimes (seconds, medians). CPU: complete reference command (reads inputs, builds the mapping, optimises, writes the output) with 4 threads and with \BestThreads\ threads. GPU pathway: Stage 1 (reference mapping code with serialisation; 4 or \BestThreads\ threads), mapping read (warm cache), host-to-device transfer, optimisation, output writing (for SIFT including re-reading the tractogram); the end-to-end GPU times are Stage 1 plus the complete GPU program, with Stage 1 at 4 threads (``4'') or \BestThreads\ threads (``best''); ``cold'': Stage 1 and GPU program with the inputs evicted from the page cache beforehand (4 threads, one run). Speed-ups are end-to-end ratios at equal thread count for Stage 1.',
      'tab:e2e', r'Subject & & CPU 4 & CPU best & St.\,1 (4) & St.\,1 (best) & Read & H2D & Opt. & Write & GPU e2e (4) & GPU e2e (best) & GPU e2e cold & Speed-up (4) & (best)', rows, 'l l r r r r r r r r r r r r r')

rows = []
for s in SUBJECTS:
    d = S[s]; c2 = cmp['sift2'].get(s, {}); cs = cmp['sift'].get(s, {})
    def mx(keys, field):
        v = [c2[k][field] for k in keys if k in c2]
        return sci(max(v)) if v else TBD
    def mxs(keys):
        v = [(cs[k]['onlyA'] + cs[k]['onlyB']) // 2 for k in keys if k in cs]
        return rng(v) if v else TBD
    gg_keys = [k for k in c2 if k.startswith('gpu_vs_gpu')]; same_keys = [k for k in c2 if k.startswith('cpu4_vs_cpu4') or k.startswith('cpubest_vs_cpubest')]
    diff_keys = [k for k in c2 if re.match(r'cpu\d+_vs_cpu4', k) or k == 'cpubest_vs_cpu4']
    ggs = [k for k in cs if k.startswith('gpu_vs_gpu')]; sames = [k for k in cs if k.startswith('cpu4_vs_cpu4') or k.startswith('cpubest_vs_cpubest')]; diffs = [k for k in cs if re.match(r'cpu\d+_vs_cpu4', k) or k == 'cpubest_vs_cpu4']
    rows.append([LAB[s], mxs(ggs), mxs(sames), 'identical' if (d['cpu1b_sift'] and d['cpu1b_sift']['onlyA'] == 0) else (fmt(d['cpu1b_sift']['onlyA']) if d['cpu1b_sift'] else '--'), mxs(diffs), fmt(d['unique']) if d['unique'] is not None else TBD,
                 'identical' if (c2.get('gpu_vs_gpu') and c2['gpu_vs_gpu']['identical']) else mx(gg_keys, 'max_abs'), mx(same_keys, 'max_abs'), 'identical' if (d['cpu1b_sift2'] and d['cpu1b_sift2']['identical']) else (sci(d['cpu1b_sift2']['max_abs']) if d['cpu1b_sift2'] else '--'), mx(diff_keys, 'max_abs'), sci(d['w']['max_abs']) if d['w'] else TBD,
                 sci(d['cf_rel_sift']) if d['cf_rel_sift'] is not None else TBD, sci(d['cf_rel']) if d['cf_rel'] is not None else TBD])
table('repro', r'Sources of numerical difference. SIFT: number of streamlines (of $10^6$) retained by only one of the two compared runs; SIFT2: maximum $|\Delta w|$ between the two compared weight vectors. GPU--GPU: repeated GPU runs on the same mapping; CPU--CPU (same): repeated reference runs with the same thread count (4 and \BestThreads); CPU 1 thr.: two single-threaded reference runs (UKB and HCP-2); CPU--CPU (diff.): reference runs with different thread counts against the 4-thread run; GPU--CPU: GPU against the 4-thread reference. The last two columns give the relative difference of the final objective-function value between the GPU and the 4-thread CPU run.',
      'tab:repro', r'Subject & \multicolumn{5}{c}{SIFT: streamlines unique to one run} & \multicolumn{5}{c}{SIFT2: max $|\Delta w|$} & \multicolumn{2}{c}{$|f_{\mathrm{GPU}}-f_{\mathrm{CPU}}|/f$} \\ & GPU--GPU & CPU--CPU same & CPU 1 thr. & CPU--CPU diff. & GPU--CPU & GPU--GPU & CPU--CPU same & CPU 1 thr. & CPU--CPU diff. & GPU--CPU & SIFT & SIFT2',
      rows, 'l r r r r r r r r r r r r')

# connectome table from connectome.json (filled by connectome.py)
rows = []
if conn:
    for s in SUBJECTS:
        for alg in ['sift', 'sift2']:
            c = conn.get(s, {}).get(alg)
            if not c: continue
            rows.append([LAB[s], alg.upper(), fmt(c['gpu_cpu']['r_log'], 6), sci(c['gpu_cpu']['frob_rel']), sci(c['gpu_cpu']['p99_rel_edge']), sci(c['gpu_cpu']['max_rel_edge']), fmt(c['gpu_cpu']['n_only_one']),
                         sci(c['gpu_cpu']['max_net_rel']), sci(c['cpu_cpu']['frob_rel']) if c.get('cpu_cpu') else '--', sci(c['cpu_cpu']['max_net_rel']) if c.get('cpu_cpu') else '--',
                         sci(c['reseed']['frob_rel']) if c.get('reseed') else '--', sci(c['reseed']['max_net_rel']) if c.get('reseed') else '--'])
if not rows: rows = [[TBD] * 12]
table('connectome', r'Connectome-level agreement on the \ConnNodes-node parcellation. GPU--CPU: connectomes from the GPU and the 4-thread CPU outputs; $r$: Pearson correlation of $\log(1+w)$ over all edges; Frob.: relative Frobenius norm of the difference matrix; P99 and max: 99th percentile and maximum of the relative edge difference over edges with reference weight $>10$; only-one: edges present in only one matrix; net.: maximum relative difference over six network measures (strength, density, global efficiency, characteristic path length, clustering, modularity; assortativity, which is close to zero in these matrices, is given as an absolute difference in the text). CPU--CPU: reference runs at 4 and \BestThreads\ threads. Re-seed: two independently seeded tractograms of the same subject processed by the reference.',
      'tab:connectome', r'Subject & & $r$ & Frob. & P99 edge & max edge & only-one & max net. & CPU--CPU Frob. & CPU--CPU net. & re-seed Frob. & re-seed net.', rows, 'l l r r r r r r r r r r')

# ---- SI tables
# SIFT2 GPU optimisation time without (v2, <subj>/v2/) and with (v3, default) the length sort of the streamlines
rows = []
for s in SUBJECTS[:4]:
    def tj(pattern):
        v = []
        for f in sorted(glob.glob(pattern)):
            try: v.append(json.load(open(f))['t_optimise'])
            except Exception: pass
        return v
    v2 = tj(f'{RUNS_DIR}/{s}/v2/gpu_sift2_rep*.timing.json'); v3 = tj(f'{RUNS_DIR}/{s}/gpu_sift2_rep*.timing.json')
    if v2 and v3: rows.append([LAB[s], str(len(v2)), fmt(med(v2), 1), str(len(v3)), fmt(med(v3), 1), fmt(100 * (1 - med(v3) / med(v2)), 0) + r'\%'])
if not rows: rows = [[TBD] * 6]
table('si_sift2_unsorted', r'GPU SIFT2 optimisation-phase time (seconds, medians of repeated runs) without and with the sort of the streamlines by their number of fixels before upload (section~5.8 of the main text). The sorted configuration is the default of the released program and the one reported in tables~5 and~6 of the main text; the weights of the two configurations agree to within $10^{-9}$.',
      'tab:si_sift2_unsorted', r'Subject & $n$ & unsorted (s) & $n$ & sorted (s) & reduction', rows, 'l r r r r r')
rows = []
for s in SUBJECTS:
    d = S[s]
    for lab, rs, key in [('tcksift, 4 threads', d['cpu4_sift'], 'wall_s'), ('tcksift, best', d['cpub_sift'], 'wall_s'), ('tcksift2, 4 threads', d['cpu4_sift2'], 'wall_s'), ('tcksift2, best', d['cpub_sift2'], 'wall_s'),
                         ('GPU SIFT (optimisation)', d['gpu_sift'], 't_optimise'), ('GPU SIFT (program)', d['gpu_sift'], 't_total'), ('GPU SIFT2 (optimisation)', d['gpu_sift2'], 't_optimise'), ('GPU SIFT2 (program)', d['gpu_sift2'], 't_total')]:
        allv = [(r[key], r.get('contaminated')) for r in rs if r.get(key) is not None]; v = vals(rs, key)
        if allv: rows.append([LAB[s], lab, str(len(v)), ', '.join(f'{x:.1f}' + ('$^\\dagger$' if c else '') for x, c in allv), fmt(med(v), 1), fmt(cv(v), 1) if cv(v) is not None else '--'])
if not rows: rows = [[TBD] * 6]
table('si_variability', 'Run-to-run variability of every timed configuration (seconds). $\\dagger$: run overlapped with other users\' jobs on the machine (mean foreign CPU load above four cores); such runs are listed but excluded from the medians whenever an uncontaminated run exists.', 'tab:si_variability', r'Subject & Configuration & $n$ & Individual runs & Median & CV (\%)', rows, 'l l r p{5.5cm} r r', extra_pre='')
rows = []
for s, sc, sc2 in [('UKB', sc_ukb, sc2_ukb), ('HCP2', sc_h2, sc2_h2)]:
    for T in sorted(set(sc) | set(sc2)):
        a = sc.get(T, (None, None)); b = sc2.get(T, (None, None))
        rows.append([LAB[s], str(T), fmt(a[0]), fmt(a[1]), fmt(b[0]), fmt(b[1])])
if not rows: rows = [[TBD] * 6]
table('si_scaling', r'Reference runtimes (seconds) as a function of thread count (one run per point except 4 and \BestThreads\ threads, medians of three).', 'tab:si_scaling', r'Subject & Threads & tcksift opt. & tcksift e2e & tcksift2 opt. & tcksift2 e2e', rows, 'l r r r r r')
rows = []
for s in SUBJECTS:
    d = S[s]; gs = d['gpu_sift'][0] if d['gpu_sift'] else {}; cs1 = d['cpu4_sift'][0] if d['cpu4_sift'] else {}
    rows.append([LAB[s], f"{cs1.get('initial_cost', float('nan')):.10g}" if cs1.get('initial_cost') else TBD, f"{gs.get('initial_cost', float('nan')):.10g}" if gs.get('initial_cost') else TBD,
                 sci(d['init_rel']) if d['init_rel'] is not None else TBD, f"{cs1.get('initial_mu', float('nan')):.10g}" if cs1.get('initial_mu') else TBD, f"{gs.get('final_mu', float('nan')):.10g}" if gs.get('final_mu') else TBD, f"{cs1.get('final_mu', float('nan')):.10g}" if cs1.get('final_mu') else TBD])
table('si_verification', r'Consistency of the serialised mapping with the reference run that produced it: initial cost function value and $\mu$ logged by the reference (\texttt{-csv}) and recomputed by the GPU program from the loaded file; final $\mu$ of both runs. The mapping-determinism check (byte-identical files for 1 and 48 threads up to a bijective relabelling of fixel indices; identical per-fixel arrays; global sums differing by $2\times10^{-15}$ and $2\times10^{-13}$ relative) is described in the main text.',
      'tab:si_verification', r'Subject & $f_0$ CPU & $f_0$ GPU & rel. diff. & $\mu_0$ & $\mu_{\mathrm{final}}$ GPU & $\mu_{\mathrm{final}}$ CPU', rows, 'l r r r r r r')
roof = extra.get('roofline_rows')
table('si_roofline', r'Newton kernel (SIFT2 Kernel 1) characteristics derived from the recorded per-streamline Newton iteration counts and the kernel time (RTX 3090: 936\,GB/s, 0.56\,TFLOP/s FP64).', 'tab:si_roofline',
      r'Subject & Newton iter. (median / mean / max) & Warp loss & Kernel 1 time (s) & Bytes moved (GB) & GB/s (\% peak) & FP64 GFLOP & GFLOP/s (\% peak)', roof or [[TBD] * 8], 'l r r r r r r r')

# ------------------------------------------------------------------ ADNI agreement tier
import subprocess
adni_sel = json.load(open(f'{RES}/adni_selection.json')) if os.path.exists(f'{RES}/adni_selection.json') else {'rows': []}
proto = {r[0]: r[1] for r in adni_sel.get('rows', [])}; proto.update({'sub-941S1195': 'advanced', 'sub-941S4365': 'basic'})
amap = {}
try:
    out = subprocess.run(['bash', '-c', f'source {REV}/scripts/common.sh; for k in "${{!ADNI_MAP[@]}}"; do echo $k ${{ADNI_MAP[$k]}}; done'], capture_output=True, text=True).stdout
    amap = dict(l.split() for l in out.strip().splitlines() if l.strip())
except Exception: pass
adni_rows = []; a_unique = []; a_r2 = []; a_max = []; a_conn = []; fix_b = []; fix_a = []
for k, sub in sorted(amap.items(), key=lambda kv: int(kv[0][4:])):
    rs = [r for r in runs if r['subject'] == k]
    if not rs: continue
    cs = [r for r in rs if r['cmd'] == 'tcksift']; c2 = [r for r in rs if r['cmd'] == 'tcksift2']; g = [r for r in rs if r['name'] == 'gpu_sift_rep1']; g2 = [r for r in rs if r['name'] == 'gpu_sift2_rep1']
    cp = f'{RES}/cmp_cache.json'; store = json.load(open(cp)) if os.path.exists(cp) else {}
    def find_cmp(kind, a, b):
        for key, v in store.items():
            if key.startswith(kind + '|') and a in key and b in key: return v
        return None
    cs_cmp = find_cmp('sift', f'{k}/gpu_sift_rep1.tck', f'{k}/cpu_sift_t'); c2_cmp = find_cmp('sift2', f'{k}/gpu_sift2_rep1.txt', f'{k}/cpu_sift2_t')
    cpair = conn_pairs.get(f'{k}|sift2_gpu|sift2_cpubest') if 'conn_pairs' in globals() else None
    cpair1 = conn_pairs.get(f'{k}|sift_gpu|sift_cpubest') if 'conn_pairs' in globals() else None
    u = ((cs_cmp['onlyA'] + cs_cmp['onlyB']) // 2) if cs_cmp else None
    if u is not None: a_unique.append(u)
    if c2_cmp: a_r2.append(c2_cmp['R2']); a_max.append(c2_cmp['max_abs'])
    cm = max([x['max_net_rel'] for x in (cpair, cpair1) if x] + [x['frob_rel'] for x in (cpair, cpair1) if x], default=None)
    if cm is not None: a_conn.append(cm)
    nf = (g or g2 or [{}])[0].get('num_fixels')
    if nf: (fix_a if proto.get(sub) == 'advanced' else fix_b).append(nf)
    adni_rows.append([sub.replace('sub-', ''), proto.get(sub, '?'), fmt(nf) if nf else TBD, fmt(cs[0]['wall_s']) if cs else TBD, fmt(g[0]['t_optimise']) if g else TBD, fmt(c2[0]['wall_s']) if c2 else TBD, fmt(g2[0]['t_optimise'], 1) if g2 else TBD,
                      fmt(u) if u is not None else TBD, fmt(c2_cmp['R2'], 7) if c2_cmp else TBD, sci(c2_cmp['max_abs']) if c2_cmp else TBD, sci(cpair['frob_rel']) if cpair else TBD, sci(cm) if cm is not None else TBD])
nb = sum(1 for r in adni_rows if r[1] == 'basic'); na = sum(1 for r in adni_rows if r[1] == 'advanced')
M['ADNIcount'] = str(len(adni_rows)) if adni_rows else TBD; M['ADNIbasicCount'] = str(nb) if adni_rows else TBD; M['ADNIadvancedCount'] = str(na) if adni_rows else TBD
M['TotalSubjects'] = str(4 + len(adni_rows)) if adni_rows else TBD
M['ADNIuniqueRange'] = rng(a_unique); M['ADNIRtwoMin'] = fmt(min(a_r2), 7) if a_r2 else TBD; M['ADNImaxAbsMax'] = sci(max(a_max)) if a_max else TBD; M['ADNIconnMax'] = sci(max(a_conn)) if a_conn else TBD
M['FixelsADNIbasic'] = rng(fix_b) if fix_b else TBD; M['FixelsADNIadvanced'] = rng(fix_a) if fix_a else TBD
with open(f'{OUT}/numbers.tex', 'a') as f:
    for k in ['ADNIcount', 'ADNIbasicCount', 'ADNIadvancedCount', 'TotalSubjects', 'ADNIuniqueRange', 'ADNIRtwoMin', 'ADNImaxAbsMax', 'ADNIconnMax', 'FixelsADNIbasic', 'FixelsADNIadvanced']:
        f.write('\\newcommand{\\%s}{%s}\n' % (k, M[k]))
table('si_adni', r'Agreement tier: ADNI3 cognitively normal subjects (one reference run at \BestThreads\ threads and one GPU run each; timings are single runs taken while other jobs were running on the machine and are descriptive only). Protocol: basic = single-shell $b=1000$; advanced = $b=500/1000/2000$. Unique: SIFT streamlines (of $10^6$) retained by only one implementation; $R^2$ and max $|\Delta w|$: SIFT2 weights; Frob.: relative Frobenius norm of the SIFT2 connectome difference; net.: maximum relative difference of the network measures (SIFT and SIFT2).',
      'tab:si_adni', r'Subject & Protocol & Fixels & tcksift e2e (s) & GPU SIFT opt. (s) & tcksift2 e2e (s) & GPU SIFT2 opt. (s) & Unique & $R^2$ & max $|\Delta w|$ & Frob. & max net.', adni_rows or [[TBD] * 12], 'l l r r r r r r r r r r')

print('tables written to', OUT)

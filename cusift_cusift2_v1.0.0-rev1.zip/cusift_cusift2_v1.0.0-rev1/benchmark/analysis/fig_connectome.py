#!/usr/bin/env python3
"""Figure: connectome agreement. (a) SIFT2 edge weights GPU vs CPU (all subjects pooled, 2D hist log-log), (b) Bland-Altman,
(c) relative edge difference distributions for GPU-CPU, CPU-CPU, re-seed, (d) network-measure relative differences per subject.
usage: fig_connectome.py --out fig.pdf"""
import argparse, json, os, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
REV = '/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision'; RUNS = '/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs'
SUBJ = ['UKB', 'HCP1', 'HCP2', 'HCP3']; LAB = {'UKB': 'UKB', 'HCP1': 'HCP-1', 'HCP2': 'HCP-2', 'HCP3': 'HCP-3'}
def load(s, lab):
    p = f'{RUNS}/{s}/conn/conn_{lab}.csv'
    if not os.path.exists(p): return None
    A = np.loadtxt(p, delimiter=','); A = np.triu(A) + np.triu(A, 1).T; iu = np.triu_indices_from(A, 1); return A[iu]
ap = argparse.ArgumentParser(); ap.add_argument('--out', required=True); a = ap.parse_args()
pairs = json.load(open(f'{REV}/results/connectome_pairs.json'))
fig, axes = plt.subplots(2, 2, figsize=(11, 9))
# (a),(b)
ga, ca = [], []
for s in SUBJ:
    g, c = load(s, 'sift2_gpu'), load(s, 'sift2_cpu4')
    if g is not None and c is not None: ga.append(g); ca.append(c)
if ga:
    g = np.concatenate(ga); c = np.concatenate(ca); m = (g > 0) & (c > 0)
    ax = axes[0, 0]; lo, hi = max(c[m].min(), 1e-2), c[m].max()
    hb = ax.hist2d(c[m], g[m], bins=[np.logspace(np.log10(lo), np.log10(hi), 150)] * 2, norm=LogNorm(), cmap='magma'); ax.plot([lo, hi], [lo, hi], 'c-', lw=0.8)
    ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('CPU edge weight (SIFT2, sum of weights)'); ax.set_ylabel('GPU edge weight'); plt.colorbar(hb[3], ax=ax, label='edges')
    ax.set_title(f'(a) SIFT2 connectome edges, GPU vs CPU, all subjects (r = {np.corrcoef(np.log1p(c), np.log1p(g))[0,1]:.6f})', fontsize=9, loc='left')
    ax = axes[0, 1]; mean = 0.5 * (g + c); d = (g - c)[m] / c[m]
    hb = ax.hist2d(mean[m], d, bins=[np.logspace(np.log10(lo), np.log10(hi), 150), 150], norm=LogNorm(), cmap='magma'); ax.set_xscale('log'); ax.axhline(0, color='c', lw=0.8)
    ax.set_xlabel('mean edge weight'); ax.set_ylabel('(GPU $-$ CPU) / CPU'); ax.set_title('(b) Bland--Altman of SIFT2 edge weights (relative)', fontsize=9, loc='left'); plt.colorbar(hb[3], ax=ax, label='edges')
# (c) relative edge difference distributions
ax = axes[1, 0]; bins = np.logspace(-8, 1, 90)
for la, lb, col, lab in [('sift2_gpu', 'sift2_cpu4', '#d62728', 'GPU vs CPU (SIFT2)'), ('sift_gpu', 'sift_cpu4', '#ff9896', 'GPU vs CPU (SIFT)'), ('sift2_cpubest', 'sift2_cpu4', '#1f77b4', 'CPU best vs CPU 4 thr. (SIFT2)'), ('sift_cpubest', 'sift_cpu4', '#aec7e8', 'CPU best vs CPU 4 thr. (SIFT)'), ('sift2_seedB', 'sift2_cpu4', '#2ca02c', 're-seeded tractogram (SIFT2)'), ('sift_seedB', 'sift_cpu4', '#98df8a', 're-seeded tractogram (SIFT)')]:
    rel = []
    for s in SUBJ:
        x, y = load(s, la), load(s, lb)
        if x is None or y is None: continue
        mm = y > 10; rel.append(np.abs(x[mm] - y[mm]) / y[mm])
    if rel:
        rel = np.concatenate(rel); ax.hist(np.clip(rel, 1e-8, None), bins=bins, histtype='step', color=col, lw=1.6, label=f'{lab} (median {np.median(rel):.1e})', density=True)
ax.set_xscale('log'); ax.set_yscale('log'); ax.axvline(1e-8, color='0.5', lw=0.8, ls='--'); ax.text(0.14, 0.50, '$\leftarrow$ zero (clamped)', transform=ax.transAxes, fontsize=7, color='0.4'); ax.set_xlabel('relative edge difference (edges with reference weight > 10)'); ax.set_ylabel('density'); ax.legend(fontsize=7); ax.set_title('(c) edge-wise differences against the reference floors', fontsize=9, loc='left')
# (d) network measures
ax = axes[1, 1]; meas = ['strength', 'density', 'global_efficiency', 'char_path_length', 'clustering', 'modularity', 'assortativity']
x = np.arange(len(meas)); w = 0.13
for i, (keyA, keyB, col, lab) in enumerate([('sift2_gpu', 'sift2_cpu4', '#d62728', 'GPU vs CPU (SIFT2)'), ('sift_gpu', 'sift_cpu4', '#ff9896', 'GPU vs CPU (SIFT)'), ('sift2_cpubest', 'sift2_cpu4', '#1f77b4', 'CPU best vs 4 thr. (SIFT2)'), ('sift_cpubest', 'sift_cpu4', '#aec7e8', 'CPU best vs 4 thr. (SIFT)'), ('sift2_seedB', 'sift2_cpu4', '#2ca02c', 're-seed (SIFT2)'), ('sift_seedB', 'sift_cpu4', '#98df8a', 're-seed (SIFT)')]):
    for s in SUBJ:
        p = pairs.get(f'{s}|{keyA}|{keyB}')
        if not p: continue
        v = [max(abs(p['net_A'][k] - p['net_B'][k]) if k == 'assortativity' else p['net_rel'][k], 1e-9) for k in meas]
        ax.scatter(x + (i - 2.5) * w, v, color=col, s=22, label=lab if s == SUBJ[0] or (s == 'HCP2' and 'seed' in keyA) else None, zorder=3, edgecolor='k', linewidth=0.3)
ax.axhline(1e-9, color='0.5', lw=0.8, ls='--'); ax.text(len(meas) - 0.6, 1.6e-9, 'zero (clamped)', fontsize=7, color='0.4', ha='right')
ax.set_yscale('log'); ax.set_xticks(x); ax.set_xticklabels(['strength', 'density', 'global eff.', 'char. path', 'clustering', 'modularity', 'assortativity\n(absolute)'], rotation=25, fontsize=8)
ax.set_ylabel('relative difference (assortativity: absolute)'); ax.grid(alpha=0.3, axis='y'); ax.legend(fontsize=7, loc='upper right', ncol=2); ax.set_title('(d) network measures: differences per subject', fontsize=9, loc='left')
fig.tight_layout(); fig.savefig(a.out, dpi=200); print('wrote', a.out)

#!/usr/bin/env python3
"""Figure: SIFT2 weight agreement.
(a) |dw| distributions for all subjects (+ optional CPU-CPU floor), (b) GPU-vs-CPU 2D histogram for one subject,
(c) Bland-Altman, (d) relative difference mapped onto streamlines (axial max-projection, log colour, clipped) with inset.
usage: fig_sift2_weights.py --subjects UKB HCP-1 ... --cpu c1 c2 .. --gpu g1 g2 .. --map_subject UKB --tracks tracks.tck
       [--floor_a f1 --floor_b f2] --out fig.pdf
Per-subject (SI): --panel_subjects  -> rows of (scatter, axial map) per subject."""
import argparse, os, sys, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tckhash import read_header

def load_w(p):
    npy = p + '.npy'
    if os.path.exists(npy): return np.load(npy)
    with open(p) as f: w = np.concatenate([np.fromstring(l, sep=' ') for l in f if l.strip() and not l.startswith('#')])
    np.save(npy, w); return w

def streamline_vertex_values(tck, per_streamline_value):
    """Return finite vertex coordinates (M,3) and the per-vertex value of its streamline."""
    with open(tck, 'rb') as f:
        hdr, off = read_header(f); f.seek(off); data = np.fromfile(f, dtype='<f4').reshape(-1, 3)
    nan = np.isnan(data[:, 0]); inf = np.isinf(data[:, 0])
    if inf.any(): data = data[:np.where(inf)[0][0]]; nan = nan[:len(data)]
    sid = np.cumsum(nan) - nan  # streamline id per vertex (separators get the id of the finished streamline)
    sid = np.concatenate([[0], np.cumsum(nan)[:-1]])
    keep = ~nan
    vals = per_streamline_value[sid[keep]]
    return data[keep], vals

def max_projection(pts, vals, pair, lim, bins=500):
    """density-weighted MEAN of the per-streamline value per pixel (a max-projection saturates)"""
    xi = np.clip(((pts[:, pair[0]] - lim[pair[0]][0]) / (lim[pair[0]][1] - lim[pair[0]][0]) * bins).astype(int), 0, bins - 1)
    yi = np.clip(((pts[:, pair[1]] - lim[pair[1]][0]) / (lim[pair[1]][1] - lim[pair[1]][0]) * bins).astype(int), 0, bins - 1)
    flat = xi * bins + yi
    cnt = np.bincount(flat, minlength=bins * bins).astype(float)
    sm = np.bincount(flat, weights=vals, minlength=bins * bins)
    g = np.where(cnt > 0, sm / np.maximum(cnt, 1), np.nan)
    return g.reshape(bins, bins), cnt.reshape(bins, bins)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--subjects', nargs='+', required=True); ap.add_argument('--cpu', nargs='+', required=True); ap.add_argument('--gpu', nargs='+', required=True)
    ap.add_argument('--map_subject', required=True); ap.add_argument('--tracks', required=True)
    ap.add_argument('--floor_a', nargs='*', default=[]); ap.add_argument('--floor_b', nargs='*', default=[]); ap.add_argument('--floor_label', default='CPU 4 vs CPU best threads')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    fig, axes = plt.subplots(2, 2, figsize=(11, 9.5))
    # (a) distributions
    ax = axes[0, 0]; bins = np.logspace(-12, 0, 150)
    cols = plt.cm.viridis(np.linspace(0, 0.85, len(a.subjects)))
    W = {}
    for s, c, g, col in zip(a.subjects, a.cpu, a.gpu, cols):
        wc, wg = load_w(c), load_w(g); d = np.abs(wg - wc); W[s] = (wc, wg)
        ax.hist(np.clip(d, 1e-12, None), bins=bins, histtype='step', color=col, lw=1.6, label=f'GPU vs CPU, {s} (max {d.max():.2e})')
    for fa, fb in zip(a.floor_a, a.floor_b):
        d = np.abs(load_w(fa) - load_w(fb))
        ax.hist(np.clip(d, 1e-12, None), bins=bins, histtype='step', color='k', ls='--', lw=1.4, label=f'{a.floor_label} (max {d.max():.2e})')
    ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel(r'$|\Delta w|$'); ax.set_ylabel('streamlines'); ax.legend(fontsize=7.5); ax.set_title('(a) distribution of absolute weight differences', fontsize=10, loc='left')
    # (b) scatter density
    wc, wg = W[a.map_subject]; m = (wc > 0) & (wg > 0)
    ax = axes[0, 1]; lo, hi = np.percentile(wc[m], 0.01), wc[m].max()
    hb = ax.hist2d(wc[m], wg[m], bins=[np.logspace(np.log10(lo), np.log10(hi), 250)] * 2, norm=LogNorm(), cmap='magma')
    ax.plot([lo, hi], [lo, hi], 'c-', lw=0.8); ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('CPU weight'); ax.set_ylabel('GPU weight')
    r2 = np.corrcoef(wc, wg)[0, 1] ** 2; ax.set_title(f'(b) {a.map_subject}: GPU vs CPU weights ($R^2$ = {r2:.7f})', fontsize=10, loc='left'); plt.colorbar(hb[3], ax=ax, label='streamlines')
    # (c) Bland-Altman
    ax = axes[1, 0]; mean = 0.5 * (wc + wg); diff = wg - wc
    hb = ax.hist2d(mean[m], diff[m], bins=[np.logspace(np.log10(lo), np.log10(hi), 250), np.linspace(np.percentile(diff, 0.001), np.percentile(diff, 99.999), 250)], norm=LogNorm(), cmap='magma')
    ax.axhline(diff.mean(), color='c', lw=0.8); ax.axhline(diff.mean() + 1.96 * diff.std(), color='c', ls='--', lw=0.8); ax.axhline(diff.mean() - 1.96 * diff.std(), color='c', ls='--', lw=0.8)
    ax.set_xscale('log'); ax.set_xlabel('mean weight (CPU, GPU)'); ax.set_ylabel('GPU $-$ CPU'); ax.set_title(f'(c) {a.map_subject}: Bland--Altman (mean {diff.mean():.1e}, 1.96 SD {1.96*diff.std():.1e})', fontsize=10, loc='left'); plt.colorbar(hb[3], ax=ax, label='streamlines')
    # (d) axial max-projection of relative difference
    ax = axes[1, 1]; rel = np.zeros_like(wc); rel[m] = np.abs(wg[m] - wc[m]) / wc[m]
    pts, vals = streamline_vertex_values(a.tracks, rel)
    lim = [(pts[:, k].min() - 2, pts[:, k].max() + 2) for k in range(3)]
    g, cnt = max_projection(pts, vals, (0, 1), lim, bins=500)
    gv = g[np.isfinite(g)]; vmin, vmax = np.percentile(gv, 1), np.percentile(gv, 99.9); vmin = max(vmin, 1e-13)
    if vmin >= vmax: vmin = vmax / 100
    im = ax.imshow(np.clip(g.T, vmin, vmax), origin='lower', extent=[lim[0][0], lim[0][1], lim[1][0], lim[1][1]], norm=LogNorm(vmin=vmin, vmax=vmax), cmap='viridis', aspect='equal')
    ax.set_xticks([]); ax.set_yticks([]); plt.colorbar(im, ax=ax, label=r'mean $|\Delta w|/w$ along the line of sight (log, clipped P1--P99.9)')
    ax.set_title(f'(d) {a.map_subject}: relative weight difference, axial projection', fontsize=10, loc='left')
    # inset centred on the vertices of the streamlines with the largest relative differences (top 0.05%)
    thr = np.percentile(rel[m], 99.95); big = vals >= thr
    cx, cy = (np.median(pts[big, 0]), np.median(pts[big, 1])) if big.any() else (0.5 * sum(lim[0]), 0.5 * sum(lim[1]))
    axins = ax.inset_axes([0.62, 0.62, 0.36, 0.36]); half = 15
    axins.imshow(np.clip(g.T, vmin, vmax), origin='lower', extent=[lim[0][0], lim[0][1], lim[1][0], lim[1][1]], norm=LogNorm(vmin=vmin, vmax=vmax), cmap='viridis', aspect='equal')
    axins.set_xlim(cx - half, cx + half); axins.set_ylim(cy - half, cy + half); axins.set_xticks([]); axins.set_yticks([])
    for sp in axins.spines.values(): sp.set_color('w')
    ax.indicate_inset_zoom(axins, edgecolor='w')
    fig.tight_layout(); fig.savefig(a.out, dpi=200); print('wrote', a.out)

if __name__ == '__main__': main()

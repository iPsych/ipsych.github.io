#!/usr/bin/env python3
"""Aggregate the all-88 ADNI comparison (GPU vs the user's independent stock-tcksift runs) into results/adni88.json and ADNIall* macros in extra.json."""
import json, glob, os, numpy as np
REV = '/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision'; RUNS = '/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs'
rows = []
for f in sorted(glob.glob(f'{RUNS}/adni88/sub-*/cmp_vs_user.json')):
    r = json.load(open(f)); sub = f.split('/')[-2]; src = open(f'{RUNS}/adni88/{sub}/source.txt').read().strip() if os.path.exists(f'{RUNS}/adni88/{sub}/source.txt') else ''
    W = f'/media/ipsych/Storage_Z8_2/ADNI3_CN/mrtrix_superager_work/{sub}'
    stale = os.path.getmtime(f'{W}/sift_1mio.tck') < os.path.getmtime(f'{W}/tracks_10mio.tck')   # tractogram regenerated after the user's SIFT run: not the same input
    rows.append(dict(subject=sub, source=src, onlyA=r['onlyA'], onlyB=r['onlyB'], overlap_pct=r['overlap_pct'], nA=r['nA'], nB=r['nB'], stale_tractogram=stale))
json.dump(rows, open(f'{REV}/results/adni88.json', 'w'), indent=1)
ep = f'{REV}/results/extra.json'; extra = json.load(open(ep)) if os.path.exists(ep) else {}
extra['ADNIallStaleCount'] = str(sum(r['stale_tractogram'] for r in rows)); rows_ok = [r for r in rows if not r['stale_tractogram']]
if rows_ok:
    rows = rows_ok; u = np.array([(r['onlyA'] + r['onlyB']) / 2 for r in rows]); ov = np.array([r['overlap_pct'] for r in rows])
    extra['ADNIallCount'] = str(len(rows))
    full = np.array([r['nA'] == 1000000 and r['nB'] == 1000000 for r in rows]); dv = u[(u >= 1000) & full]   # the other family, subjects that reached the target count
    extra['ADNIallUniqueRange'] = (f'{dv.min():,.0f}--{dv.max():,.0f}' if dv.size else '--').replace(',', '\\,'); extra['ADNIallUniqueMedian'] = f'{np.median(u):,.0f}'.replace(',', '\\,')
    extra['ADNIallOverlapRange'] = f'{ov.min():.1f}--{ov.max():.1f}\\%'; extra['ADNIallOverlapMedian'] = f'{np.median(ov):.1f}\\%'
    extra['ADNIallAgreeCount'] = str(int((u < 1000).sum()))  # runs that landed in the same fixel-numbering family as the user's run
    early = [r for r in rows if r['nA'] != 1000000 or r['nB'] != 1000000]   # both implementations stopped before the target count (no further removal reduced the cost)
    extra['ADNIallEarlyCount'] = str(len(early)); extra['ADNIallEarlyCountDiffMax'] = (f"{100 * max(abs(r['nA'] - r['nB']) / r['nB'] for r in early):.1f}\\%" if early else '0\\%')
    extra['ADNIallEarlyRange'] = (f"{min(min(r['nA'], r['nB']) for r in early) / 1e6:.2f}--{max(max(r['nA'], r['nB']) for r in early) / 1e6:.2f}" if early else '--')
json.dump(extra, open(ep, 'w'), indent=1); print(len(rows), 'subjects', {k: v for k, v in extra.items() if k.startswith('ADNIall')})

#!/usr/bin/env python3
"""Figure: SIFT discrepant streamlines over a density map of the common streamlines.
usage: fig_sift_discrepant.py --cpu A.tck --gpu B.tck --out fig.pdf [--title "HCP-3"] [--rows ...]
Multi-subject: --cpu a1 a2 --gpu b1 b2 --title t1 t2  (one row per subject)."""
import argparse, os, sys, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tckhash import tck_hashes, read_header

def read_all(path):
    with open(path, 'rb') as f:
        hdr, off = read_header(f); f.seek(off); data = np.fromfile(f, dtype='<f4').reshape(-1, 3)
    return data

def split_streamlines(data):
    nan = np.isnan(data[:, 0]); inf = np.isinf(data[:, 0])
    ends = np.where(nan | inf)[0]
    if inf.any(): ends = ends[ends <= np.where(inf)[0][0]]
    starts = np.concatenate([[0], ends[:-1] + 1])
    return starts, ends

def discrepant(cpu, gpu):
    hc = tck_hashes(cpu) if not os.path.exists(cpu + '.hashes.npy') else np.load(cpu + '.hashes.npy')
    hg = tck_hashes(gpu) if not os.path.exists(gpu + '.hashes.npy') else np.load(gpu + '.hashes.npy')
    sc, sg = set(hc.tolist()), set(hg.tolist())
    only_c = np.array([i for i, h in enumerate(hc.tolist()) if h not in sg])
    only_g = np.array([i for i, h in enumerate(hg.tolist()) if h not in sc])
    return only_c, only_g

def extract(path, idx):
    data = read_all(path); starts, ends = split_streamlines(data)
    sl = [data[starts[i]:ends[i]] for i in idx]
    return data, starts, ends, sl

PROJ = {'coronal': (0, 2), 'sagittal': (1, 2), 'axial': (0, 1)}

def density(data, ax_pair, lim, bins=400):
    pts = data[np.isfinite(data[:, 0])]
    H, xe, ye = np.histogram2d(pts[:, ax_pair[0]], pts[:, ax_pair[1]], bins=bins, range=[lim[ax_pair[0]], lim[ax_pair[1]]])
    return H, xe, ye

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--cpu', nargs='+', required=True); ap.add_argument('--gpu', nargs='+', required=True)
    ap.add_argument('--title', nargs='+', default=None); ap.add_argument('--out', required=True); ap.add_argument('--lw', type=float, default=2.2)
    a = ap.parse_args()
    n = len(a.cpu); titles = a.title or [os.path.basename(c) for c in a.cpu]
    fig, axes = plt.subplots(n, 3, figsize=(11, 3.9 * n), squeeze=False)
    for r, (cpu, gpu, title) in enumerate(zip(a.cpu, a.gpu, titles)):
        oc, og = discrepant(cpu, gpu)
        data_c, sc, ec, sl_c = extract(cpu, oc)
        data_g, sg, eg, sl_g = extract(gpu, og)
        finite = data_c[np.isfinite(data_c[:, 0])]
        lim = [(finite[:, k].min() - 5, finite[:, k].max() + 5) for k in range(3)]
        for c, (pname, pair) in enumerate(PROJ.items()):
            ax = axes[r, c]
            H, xe, ye = density(data_c, pair, lim)
            ax.imshow(np.log1p(H.T), origin='lower', extent=[xe[0], xe[-1], ye[0], ye[-1]], cmap='Greys', vmax=np.log1p(H.max()) * 1.6, aspect='equal')
            for sl, col in ((sl_c, '#1f5fbf'), (sl_g, '#d62728')):
                if len(sl):
                    ax.add_collection(LineCollection([s[:, list(pair)] for s in sl], colors=col, linewidths=a.lw, alpha=0.95, zorder=3))
            ax.set_xlim(lim[pair[0]]); ax.set_ylim(lim[pair[1]]); ax.set_xticks([]); ax.set_yticks([])
            if r == 0: ax.set_title(pname, fontsize=11)
            if c == 0: ax.set_ylabel(f'{title}\nCPU only: {len(oc)}, GPU only: {len(og)}', fontsize=10)
        print(f'{title}: CPU-only {len(oc)}, GPU-only {len(og)}')
    from matplotlib.lines import Line2D
    axes[0, 2].legend(handles=[Line2D([], [], color='#1f5fbf', lw=3, label='retained only by CPU reference'), Line2D([], [], color='#d62728', lw=3, label='retained only by GPU')],
                      loc='upper right', fontsize=8, frameon=True)
    fig.tight_layout(); fig.savefig(a.out, dpi=200); print('wrote', a.out)

if __name__ == '__main__': main()

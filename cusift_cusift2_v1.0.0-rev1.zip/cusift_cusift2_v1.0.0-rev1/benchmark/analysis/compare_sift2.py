#!/usr/bin/env python3
"""Weight-vector comparison with percentiles. usage: compare_sift2.py A.txt B.txt [out.json]  (B = reference)"""
import sys, json, numpy as np
def load(p):
    with open(p) as f:
        return np.concatenate([np.fromstring(l,sep=' ') for l in f if l.strip() and not l.startswith('#')])
a=load(sys.argv[1]); b=load(sys.argv[2]); assert a.shape==b.shape, (a.shape,b.shape)
d=a-b; ad=np.abs(d); m=b>0; rel=ad[m]/b[m]
def pct(x,q): return float(np.percentile(x,q))
r=np.corrcoef(a,b)[0,1]; 
res=dict(A=sys.argv[1],B=sys.argv[2],n=int(len(a)),n_zero_A=int((a==0).sum()),n_zero_B=int((b==0).sum()),
   mean_abs=float(ad.mean()),median_abs=float(np.median(ad)),max_abs=float(ad.max()),rms=float(np.sqrt((d**2).mean())),
   p99_abs=pct(ad,99),p999_abs=pct(ad,99.9),p9999_abs=pct(ad,99.99),
   mean_rel=float(rel.mean()),median_rel=float(np.median(rel)),max_rel=float(rel.max()),p99_rel=pct(rel,99),p999_rel=pct(rel,99.9),p9999_rel=pct(rel,99.99),
   frac_rel_gt_1e3=float((rel>1e-3).mean()),frac_rel_gt_1e2=float((rel>1e-2).mean()),frac_identical=float((d==0).mean()),
   R2=float(r*r),R2_log=float(np.corrcoef(np.log1p(a[m]),np.log1p(b[m]))[0,1]**2),
   mean_w_B=float(b.mean()),sum_w_A=float(a.sum()),sum_w_B=float(b.sum()))
print(json.dumps(res,indent=1))
if len(sys.argv)>3: json.dump(res,open(sys.argv[3],'w'),indent=1)

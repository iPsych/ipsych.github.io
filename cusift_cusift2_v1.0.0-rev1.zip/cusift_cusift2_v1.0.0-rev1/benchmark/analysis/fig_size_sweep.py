#!/usr/bin/env python3
"""Figure: runtime, agreement and device memory versus tractogram size (UKB circles, HCP2 squares).
usage: fig_size_sweep.py --out fig.pdf   (also writes results/size_sweep.json used by make_tables via extra.json)"""
import argparse, json, os, re, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
REV = '/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision'; RUNS = '/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs'
runs = json.load(open(f'{REV}/results/runs.json')); cmp = json.load(open(f'{REV}/results/comparisons.json'))
ap = argparse.ArgumentParser(); ap.add_argument('--out', required=True); a = ap.parse_args()
SIZES = [1000000, 2000000, 5000000, 10000000, 20000000]
def find(s, pat):
    return [r for r in runs if r['subject'] == s and re.fullmatch(pat, r['name'])]
data = {}
for s in ['UKB', 'HCP2']:
    d = {}
    for N in SIZES:
        tag = 'rep1' if N == 10000000 else f'size{N}'
        if N == 10000000:
            cs = find(s, r'cpu_sift_t\d+_best_ref1'); c2 = find(s, r'cpu_sift2_t\d+_best_ref1'); key = 'gpu_vs_cpu4'
        else:
            cs = find(s, r'cpu_sift_t\d+_size%d' % N); c2 = find(s, r'cpu_sift2_t\d+_size%d' % N); key = f'size{N}_gpu_vs_cpu'
        g = find(s, f'gpu_sift_{tag}'); g2 = find(s, f'gpu_sift2_{tag}')
        def ppeak(r):  # per-process peak (MB) on the primary GPU if recorded, else None
            try: return max(float(x) for x in str(r['proc_peak_MB']).split(',') if x)
            except Exception: return None
        gm = find(s, 'gpu_sift_mem'); memrun = (gm[0] if (N == 10000000 and gm) else (g[0] if g else None))
        e = dict(cpu_opt=cs[0].get('t_opt_s') if cs else None, cpu2_opt=c2[0].get('t_opt_s') if c2 else None, gpu_opt=g[0].get('t_optimise') if g else None, gpu2_opt=g2[0].get('t_optimise') if g2 else None,
                 mem=ppeak(memrun) if memrun else None, entries=g[0].get('total_entries') if g else None,
                 unique=((cmp['sift'][s][key]['onlyA'] + cmp['sift'][s][key]['onlyB']) / 2) if key in cmp['sift'].get(s, {}) else None,
                 maxabs=cmp['sift2'][s][key]['max_abs'] if key in cmp['sift2'].get(s, {}) else None, R2=cmp['sift2'][s][key]['R2'] if key in cmp['sift2'].get(s, {}) else None)
        if any(v is not None for v in e.values()): d[N] = e
    data[s] = d
json.dump(data, open(f'{REV}/results/size_sweep.json', 'w'), indent=1)
extra_p = f'{REV}/results/extra.json'; extra = json.load(open(extra_p)) if os.path.exists(extra_p) else {}
sp, sp2, uniq, r2s, slopes = [], [], [], [], []
mem_pts = []
for s, d in data.items():
    Ns = sorted(n for n in d if d[n]['gpu_opt'] and d[n]['cpu_opt'])
    for n in Ns:
        e = d[n]
        if e['gpu_opt'] > 1: sp.append(e['cpu_opt'] / e['gpu_opt'])
        if e['gpu2_opt'] and e['cpu2_opt']: sp2.append(e['cpu2_opt'] / e['gpu2_opt'])
        if e['unique'] is not None: uniq.append(e['unique'] / (n / 10) * 1e6)
        if e['R2'] is not None: r2s.append(e['R2'])
        if e['mem'] and e['entries']: mem_pts.append((n, e['entries'], e['mem']))
    gg = [(n, d[n]['gpu_opt']) for n in Ns if d[n]['gpu_opt'] and d[n]['gpu_opt'] > 1]
    if len(gg) > 2: slopes.append(np.polyfit(np.log([x for x, _ in gg]), np.log([y for _, y in gg]), 1)[0])
    cc = [(n, d[n]['cpu_opt']) for n in Ns]
    if len(cc) > 2: slopes.append(np.polyfit(np.log([x for x, _ in cc]), np.log([y for _, y in cc]), 1)[0])
def rng(v, nd=0): return (f'{min(v):.{nd}f}--{max(v):.{nd}f}') if v else '[TBD]'
extra['SizeSpeedupRange'] = rng(sp, 1) + '$\\times$'; extra['SizeSpeedupSifttwoRange'] = rng(sp2, 1) + '$\\times$'
extra['SizeUniqueRange'] = rng(uniq, 0); extra['SizeRtwoMin'] = f'{min(r2s):.7f}' if r2s else '[TBD]'
extra['SizeScalingLaw'] = ('approximately as $N^{%.1f}$--$N^{%.1f}$' % (min(slopes), max(slopes))) if slopes else '[TBD]'
if len(mem_pts) > 2:
    A = np.array([[e, n, 1.0] for n, e, m in mem_pts]); b = np.array([m for n, e, m in mem_pts]) * 1048576.0
    coef = np.linalg.lstsq(A, b, rcond=None)[0]; extra['MemPerEntry'] = f'{coef[0]:.1f}'; extra['MemPerStreamline'] = f'{coef[1]:.0f}'
m20 = data.get('UKB', {}).get(20000000, {}).get('mem')
if m20: extra['GPUmemHundredM'] = f'{5 * m20 / 1024:.0f}'; extra['GPUmemTwentyM'] = f'{m20 / 1024:.1f}'
json.dump(extra, open(extra_p, 'w'), indent=1)
fig, axes = plt.subplots(1, 3, figsize=(13, 4))
for s, mk in [('UKB', 'o'), ('HCP2', 's')]:
    d = data[s]; N = sorted(d)
    def ser(k): return [d[n][k] if d[n][k] is not None else np.nan for n in N]
    ax = axes[0]
    ax.plot(N, ser('cpu_opt'), marker=mk, color='#1f77b4', label=f'SIFT CPU best, {s}'); ax.plot(N, ser('gpu_opt'), marker=mk, color='#1f77b4', ls='--', label=f'SIFT GPU, {s}')
    ax.plot(N, ser('cpu2_opt'), marker=mk, color='#2ca02c', label=f'SIFT2 CPU best, {s}'); ax.plot(N, ser('gpu2_opt'), marker=mk, color='#2ca02c', ls='--', label=f'SIFT2 GPU, {s}')
    ax = axes[1]
    ax.plot(N, [max(u, 0.5) if np.isfinite(u) else np.nan for u in [x / (n / 10) * 1e6 if x is not None else np.nan for x, n in zip(ser('unique'), N)]], marker=mk, color='#1f77b4', label=f'SIFT unique per $10^6$ retained, {s}')
    ax2 = ax.twinx() if s == 'UKB' else ax2
    ax2.plot(N, ser('maxabs'), marker=mk, color='#2ca02c', ls='--', label=f'SIFT2 max $|\\Delta w|$, {s}')
    ax = axes[2]; ax.plot(N, [m / 1024 if m else np.nan for m in ser('mem')], marker=mk, color='k', label=s)
axes[0].set_xscale('log'); axes[0].set_yscale('log'); axes[0].set_xlabel('streamlines'); axes[0].set_ylabel('optimisation-phase time (s)'); axes[0].legend(fontsize=7); axes[0].set_title('(a) runtime', loc='left', fontsize=10); axes[0].grid(alpha=0.3, which='both')
axes[1].set_xscale('log'); axes[1].set_yscale('log'); axes[1].set_xlabel('streamlines'); axes[1].set_ylabel('SIFT: unique streamlines per $10^6$ retained'); axes[1].legend(fontsize=7, loc='upper left'); axes[1].set_title('(b) agreement', loc='left', fontsize=10)
ax2.set_yscale('log'); ax2.set_ylabel('SIFT2: max $|\\Delta w|$'); ax2.legend(fontsize=7, loc='lower right')
axes[2].set_xscale('log'); axes[2].set_yscale('log'); axes[2].set_xlabel('streamlines'); axes[2].set_ylabel('device memory in use, primary GPU (GB)'); axes[2].legend(fontsize=7); axes[2].set_title('(c) memory', loc='left', fontsize=10); axes[2].grid(alpha=0.3, which='both')
fig.tight_layout(); fig.savefig(a.out, dpi=200); print('wrote', a.out)

#!/usr/bin/env python3
"""Collect every run of the revision benchmark campaign into results/*.json.

Run incrementally (comparisons are cached as .npy/.json next to the outputs).
    python3 analyze.py            # parse timings + run all pairwise comparisons that are possible
    python3 analyze.py --no-cmp   # timings only
"""
import os, sys, json, glob, re, subprocess
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tckhash import tck_hashes

REV  = '/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision'
RUNS = '/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs'
RES  = f'{REV}/results'
SUBJECTS = ['UKB', 'HCP1', 'HCP2', 'HCP3'] + sorted([os.path.basename(d) for d in glob.glob(f'{RUNS}/ADNI*') if os.path.isdir(d)], key=lambda x: int(x[4:]))
SUBJ_LABEL = {'UKB': 'UKB', 'HCP1': 'HCP-1', 'HCP2': 'HCP-2', 'HCP3': 'HCP-3'}

# ----------------------------------------------------------------------------- CPU runs
def read_ts(path):
    """timestamped stderr -> list of (t, text)"""
    out = []
    with open(path, 'rb') as f:
        for line in f:
            try:
                t, txt = line.decode('utf-8', 'replace').rstrip('\n').split(' ', 1)
                out.append((float(t), txt))
            except ValueError:
                pass
    return out

def first_match(ts, pat):
    r = re.compile(pat)
    for t, s in ts:
        if r.search(s): return t
    return None

def last_match(ts, pat):
    r = re.compile(pat); last = None
    for t, s in ts:
        if r.search(s): last = t
    return last

def parse_cpu_run(base):
    """base = path without extension of a cpu_sift*/cpu_sift2*/stage1* run. Returns dict or None."""
    if not os.path.exists(base + '.json'): return None
    j = json.load(open(base + '.json'))
    rec = dict(j); rec['base'] = base
    try:
        t0 = float(open(base + '.ts').readline().split()[0])
        t1 = float(open(base + '.ts').readlines()[1].split()[0])
    except Exception:
        t0 = t1 = None
    ts = read_ts(base + '.time') if os.path.exists(base + '.time') else []
    rec['has_ts'] = bool(ts) and t0 is not None
    if rec['has_ts']:
        kind = j['cmd']
        rec['t_export_start'] = first_match(ts, r'Exporting mapping')
        rec['t_export_end']   = first_match(ts, r'Mapping exported')
        if kind == 'tcksift':
            hdr = first_match(ts, r'Iteration\s+Removed\s+Remaining')
            wr  = first_match(ts, r'Writing filtered tracks')
            rec['t_pre_s']  = (hdr - t0) if hdr else None               # read + segment + map (+ export)
            rec['t_opt_s']  = (wr - hdr) if (hdr and wr) else None     # filtering loop
            rec['t_write_s'] = (t1 - wr) if wr else None
        elif kind == 'tcksift2':
            hdr = first_match(ts, r'Iteration\s+CF \(data\)')
            lastit = last_match(ts, r'^\s*tcksift2:\s+\d+\s+[\d.]+%')
            if lastit is None: lastit = last_match(ts, r'\d+\s+[\d.]+%\s+[\d.]+%')
            rec['t_pre_s']  = (hdr - t0) if hdr else None
            rec['t_opt_s']  = (lastit - hdr) if (hdr and lastit) else None
            rec['t_write_s'] = (t1 - lastit) if lastit else None
        else:  # stage1
            rec['t_pre_s'] = (rec['t_export_start'] - t0) if rec.get('t_export_start') else None
            rec['t_export_s'] = (rec['t_export_end'] - rec['t_export_start']) if rec.get('t_export_end') and rec.get('t_export_start') else None
        if rec.get('t_export_start') and rec.get('t_export_end') and 't_export_s' not in rec:
            rec['t_export_s'] = rec['t_export_end'] - rec['t_export_start']
    # per-iteration csv (SIFT: iterations, removals; SIFT2: iterations, costs)
    if os.path.exists(base + '.csv'):
        try:
            rows = [l for l in open(base + '.csv') if not l.startswith('#')]
            if j['cmd'] == 'tcksift':
                arr = np.array([[float(x) for x in l.split(',')[:7]] for l in rows if l.strip()])
                arr = arr[arr[:, 0] > 0]
                rec['iterations'] = int(arr[-1, 0]); rec['removed_total'] = int(arr[-1, 2])
                rec['removals_per_iter_mean'] = float(arr[:, 1].mean()); rec['removals_first'] = int(arr[0, 1]); rec['removals_last'] = int(arr[-1, 1])
                rec['removals_median'] = float(np.median(arr[:, 1]))
                rec['final_cost'] = float(arr[-1, 4]); rec['final_mu'] = float(arr[-1, 6])
                hdrline = [l for l in open(base + '.csv') if l.startswith('0,')]
                if hdrline:
                    r0 = hdrline[0].split(','); rec['initial_cost'] = float(r0[4]); rec['initial_mu'] = float(r0[6])
            else:
                hdr = rows[0].strip().split(',')
                arr = np.array([[float(x) for x in l.split(',')[:7]] for l in rows[1:] if l.strip() and l[0].isdigit()])
                rec['iterations'] = int(arr[-1, 0]); rec['cf_data_final'] = float(arr[-1, 1]); rec['cf_reg_final'] = float(arr[-1, 4]); rec['cf_total_final'] = float(arr[-1, 5])
                rec['cf_total_trajectory'] = arr[:, 5].tolist()
                # initial cost from the log
        except Exception as e:
            rec['csv_error'] = str(e)
    if os.path.exists(base + '.mu'):
        try: rec['mu_file'] = float(open(base + '.mu').read().split()[0])
        except Exception: pass
    # SIFT2 initial cost from the console log
    if j['cmd'] == 'tcksift2' and rec['has_ts']:
        for t, s in ts:
            m = re.search(r'Cost function before linear optimisation is ([\d.eE+-]+)', s)
            if m: rec['cf_init_console'] = float(m.group(1))
    return rec

def parse_gpu_run(base):
    if not os.path.exists(base + '.json'): return None
    j = json.load(open(base + '.json')); rec = dict(j); rec['base'] = base
    if os.path.exists(base + '.timing.json'):
        rec.update(json.load(open(base + '.timing.json')))
    if os.path.exists(base + '.csv') and j['cmd'] == 'sift_gpu':
        try:
            arr = np.array([[float(x) for x in l.split(',')[:7]] + [float(l.split(',')[9]), float(l.split(',')[10])] for l in open(base + '.csv') if not l.startswith('#') and l.strip()])
            rec['removals_per_iter_mean'] = float(arr[:, 1].mean()); rec['removals_first'] = int(arr[0, 1]); rec['removals_last'] = int(arr[-1, 1]); rec['removals_median'] = float(np.median(arr[:, 1]))
            rec['gpu_part_s'] = float(arr[:, 7].sum()); rec['host_part_s'] = float(arr[:, 8].sum())
            rec['cost_trajectory_removed'] = arr[::50, 2].tolist(); rec['cost_trajectory_cost'] = arr[::50, 4].tolist()
        except Exception as e: rec['csv_error'] = str(e)
    if os.path.exists(base + '.csv') and j['cmd'] == 'sift2_cuda':
        try:
            arr = np.array([[float(x) for x in l.split(',')] for l in open(base + '.csv') if l.strip() and l[0].isdigit()])
            rec['cf_total_trajectory'] = arr[:, 4].tolist(); rec['cf_data_final'] = float(arr[-1, 1]); rec['cf_reg_final'] = float(arr[-1, 2] + arr[-1, 3])
        except Exception as e: rec['csv_error'] = str(e)
    return rec

FOREIGN = None
def foreign_load(t0, t1):
    """mean foreign %CPU (processes other than the benchmark commands) over [t0,t1] from logs/foreign_load.tsv"""
    global FOREIGN
    if FOREIGN is None:
        rows = []
        for l in open(f'{REV}/logs/foreign_load.tsv'):
            p = l.rstrip('\n').split('\t')
            if len(p) >= 3 and p[0].isdigit(): rows.append((int(p[0]), float(p[1]), float(p[2])))
        FOREIGN = np.array(rows) if rows else np.zeros((0, 3))
    if t0 is None or t1 is None or len(FOREIGN) == 0: return None
    m = (FOREIGN[:, 0] >= t0) & (FOREIGN[:, 0] <= t1)
    return float(FOREIGN[m, 2].mean()) if m.any() else None

def run_window(base):
    try:
        ls = open(base + '.ts').read().split('\n'); return float(ls[0].split()[0]), float(ls[1].split()[0])
    except Exception:
        try:
            j = json.load(open(base + '.json')); st = os.path.getmtime(base + '.json'); return st - j['wall_s'], st
        except Exception: return None, None

OVERRIDES = json.load(open(f'{REV}/results/contaminated_overrides.json')) if os.path.exists(f'{REV}/results/contaminated_overrides.json') else {}

def collect_runs():
    runs = []
    for s in SUBJECTS:
        for f in sorted(glob.glob(f'{RUNS}/{s}/*.json')):
            b = f[:-5]
            if b.endswith('.timing') or 'mapping_diff' in b or b.endswith('.cmp') or '/cmp_' in b: continue
            name = os.path.basename(b)
            if name.startswith(('cpu_sift', 'stage1')): r = parse_cpu_run(b)
            elif name.startswith('gpu_sift'): r = parse_gpu_run(b)
            else: continue
            if r:
                r['name'] = name; r['subject'] = s
                t0, t1 = run_window(b); r['foreign_cpu_mean'] = foreign_load(t0, t1)
                thr = 2000 if name.startswith('gpu_') else 400   # GPU programs use ~1 host core; CPU runs are bandwidth-sensitive
                r['contaminated'] = bool(r['foreign_cpu_mean'] is not None and r['foreign_cpu_mean'] > thr)
                ov = OVERRIDES.get(f'{s}/{name}')   # manual flags (results/contaminated_overrides.json) for overlaps the foreign-load logger cannot see
                if ov: r['contaminated'] = True; r['contamination_note'] = ov
                runs.append(r)
    return runs

# ----------------------------------------------------------------------------- comparisons
def hashes_cached(tck):
    npy = tck + '.hashes.npy'
    if os.path.exists(npy) and os.path.getmtime(npy) >= os.path.getmtime(tck): return np.load(npy)
    h = tck_hashes(tck); np.save(npy, h); return h

def cmp_sift(a, b):
    ha, hb = hashes_cached(a), hashes_cached(b)
    sa, sb = set(ha.tolist()), set(hb.tolist())
    inter = len(sa & sb)
    return dict(A=a, B=b, nA=len(ha), nB=len(hb), common=inter, onlyA=len(sa - sb), onlyB=len(sb - sa),
                overlap_pct=100.0 * inter / max(len(sa), 1))

def load_weights(p):
    npy = p + '.npy'
    if os.path.exists(npy) and os.path.getmtime(npy) >= os.path.getmtime(p): return np.load(npy)
    with open(p) as f:
        w = np.concatenate([np.fromstring(l, sep=' ') for l in f if l.strip() and not l.startswith('#')])
    np.save(npy, w); return w

def cmp_sift2(a, b):
    wa, wb = load_weights(a), load_weights(b)
    if wa.shape != wb.shape: return dict(A=a, B=b, error='shape')
    d = wa - wb; ad = np.abs(d); m = wb > 0; rel = ad[m] / wb[m]
    pct = lambda x, q: float(np.percentile(x, q))
    r = np.corrcoef(wa, wb)[0, 1]
    return dict(A=a, B=b, n=int(len(wa)), identical=bool(np.array_equal(wa, wb)),
                mean_abs=float(ad.mean()), median_abs=float(np.median(ad)), max_abs=float(ad.max()), rms=float(np.sqrt((d ** 2).mean())),
                p99_abs=pct(ad, 99), p999_abs=pct(ad, 99.9), p9999_abs=pct(ad, 99.99),
                mean_rel=float(rel.mean()), median_rel=float(np.median(rel)), max_rel=float(rel.max()), p99_rel=pct(rel, 99), p999_rel=pct(rel, 99.9), p9999_rel=pct(rel, 99.99),
                frac_identical=float((d == 0).mean()), R2=float(r * r), mean_w=float(wb.mean()))

def cached_cmp(kind, a, b, store):
    key = f'{kind}|{os.path.relpath(a, RUNS)}|{os.path.relpath(b, RUNS)}'
    if not (os.path.exists(a) and os.path.exists(b)): return None
    stamp = f'{os.path.getmtime(a):.0f}|{os.path.getmtime(b):.0f}'
    if key in store and store[key].get('_stamp') == stamp: return store[key]
    print('  compare', kind, os.path.basename(a), os.path.basename(b), flush=True)
    store[key] = cmp_sift(a, b) if kind == 'sift' else cmp_sift2(a, b); store[key]['_stamp'] = stamp
    return store[key]

def run_comparisons(runs, store):
    """Every comparison the manuscript needs, when both files exist."""
    by = {(r['subject'], r['name']): r for r in runs}
    def P(s, name, ext): return f'{RUNS}/{s}/{name}{ext}'
    out = {'sift': {}, 'sift2': {}}
    for s in SUBJECTS:
        ref = P(s, 'cpu_sift_t4_ref1', '.tck'); ref2 = P(s, 'cpu_sift2_t4_ref1', '.txt')
        pairs_sift = {
            'gpu_vs_cpu4': (P(s, 'gpu_sift_rep1', '.tck'), ref),
            'gpu_vs_gpu': (P(s, 'gpu_sift_rep2', '.tck'), P(s, 'gpu_sift_rep1', '.tck')),
            'gpu_vs_gpu_r3': (P(s, 'gpu_sift_rep3', '.tck'), P(s, 'gpu_sift_rep1', '.tck')),
            'gpu_vs_gpu_r4': (P(s, 'gpu_sift_rep4', '.tck'), P(s, 'gpu_sift_rep1', '.tck')),
            'gpu_vs_gpu_r5': (P(s, 'gpu_sift_rep5', '.tck'), P(s, 'gpu_sift_rep1', '.tck')),
            'gpu_single_vs_dual': (P(s, 'gpu_sift_single', '.tck'), P(s, 'gpu_sift_rep1', '.tck')),
            'gpu_map_t1_vs_gpu': (P(s, 'gpu_sift_map_t1', '.tck'), P(s, 'gpu_sift_rep1', '.tck')),
            'gpu_map_t48_vs_gpu': (P(s, 'gpu_sift_map_t48', '.tck'), P(s, 'gpu_sift_rep1', '.tck')),
            'gpu_map_t1_vs_cpu1': (P(s, 'gpu_sift_map_t1', '.tck'), P(s, 'cpu_sift_t1_scal', '.tck')),
            'gpu_map_t48_vs_cpu48': (P(s, 'gpu_sift_map_t48', '.tck'), P(s, 'cpu_sift_t48_scal', '.tck')),
            'gpu_cold_vs_warm': (P(s, 'gpu_sift_cold', '.tck'), P(s, 'gpu_sift_rep1', '.tck')),
            'cpu4_vs_cpu4_ref2': (P(s, 'cpu_sift_t4_ref2', '.tck'), ref),
            'cpu4_vs_cpu4_ref3': (P(s, 'cpu_sift_t4_ref3', '.tck'), ref),
        }
        for T in [1, 2, 8, 16, 24, 48, 96]:
            pairs_sift[f'cpu{T}_vs_cpu4'] = (P(s, f'cpu_sift_t{T}_scal', '.tck'), ref)
        pairs_sift['cpu1b_vs_cpu1'] = (P(s, 'cpu_sift_t1_scal2', '.tck'), P(s, 'cpu_sift_t1_scal', '.tck'))
        pairs_sift['cpu16b_vs_cpu16'] = (P(s, 'cpu_sift_t16_scal2', '.tck'), P(s, 'cpu_sift_t16_scal', '.tck'))
        pairs_sift['cpu2b_vs_cpu2'] = (P(s, 'cpu_sift_t2_scal2', '.tck'), P(s, 'cpu_sift_t2_scal', '.tck'))
        pairs_sift['cpu16_vs_cpu24'] = (P(s, 'cpu_sift_t16_scal', '.tck'), P(s, 'cpu_sift_t24_scal', '.tck'))
        pairs_sift['cpu16b_vs_cpu4'] = (P(s, 'cpu_sift_t16_scal2', '.tck'), ref)
        pairs_sift['cpu2b_vs_cpu4'] = (P(s, 'cpu_sift_t2_scal2', '.tck'), ref)
        for n in glob.glob(f'{RUNS}/{s}/cpu_sift_t*_best_ref1.json'):
            T = re.search(r'_t(\d+)_', n).group(1)
            pairs_sift['cpubest_vs_cpu4'] = (P(s, f'cpu_sift_t{T}_best_ref1', '.tck'), ref)
            pairs_sift['cpubest_vs_cpubest_ref2'] = (P(s, f'cpu_sift_t{T}_best_ref2', '.tck'), P(s, f'cpu_sift_t{T}_best_ref1', '.tck'))
            pairs_sift['cpubest_vs_cpubest_ref3'] = (P(s, f'cpu_sift_t{T}_best_ref3', '.tck'), P(s, f'cpu_sift_t{T}_best_ref1', '.tck'))
            pairs_sift['gpu_vs_cpubest'] = (P(s, 'gpu_sift_rep1', '.tck'), P(s, f'cpu_sift_t{T}_best_ref1', '.tck'))
            pairs_sift['cpubest2_vs_cpu4'] = (P(s, f'cpu_sift_t{T}_best_ref2', '.tck'), ref)
            pairs_sift['cpubest3_vs_cpu4'] = (P(s, f'cpu_sift_t{T}_best_ref3', '.tck'), ref)
            pairs_sift['cpubest3_vs_cpubest2'] = (P(s, f'cpu_sift_t{T}_best_ref3', '.tck'), P(s, f'cpu_sift_t{T}_best_ref2', '.tck'))
        for n in glob.glob(f'{RUNS}/{s}/cpu_sift_t*_best_ref1.json'):  # ADNI tier: best-thread reference is the only reference
            T = re.search(r'_t(\d+)_', n).group(1)
            if not os.path.exists(ref): pairs_sift['gpu_vs_cpubest'] = (P(s, 'gpu_sift_rep1', '.tck'), P(s, f'cpu_sift_t{T}_best_ref1', '.tck'))
        for N in [1000000, 2000000, 5000000, 20000000]:
            for n in glob.glob(f'{RUNS}/{s}/cpu_sift_t*_size{N}.json'):
                T = re.search(r'_t(\d+)_', n).group(1)
                pairs_sift[f'size{N}_gpu_vs_cpu'] = (P(s, f'gpu_sift_size{N}', '.tck'), P(s, f'cpu_sift_t{T}_size{N}', '.tck'))
        pairs_sift2 = {k.replace('gpu_sift_', 'gpu_sift2_').replace('cpu_sift_', 'cpu_sift2_'): None for k in []}
        pairs_sift2 = {
            'gpu_vs_cpu4': (P(s, 'gpu_sift2_rep1', '.txt'), ref2),
            'gpu_vs_gpu': (P(s, 'gpu_sift2_rep2', '.txt'), P(s, 'gpu_sift2_rep1', '.txt')),
            'gpu_vs_gpu_r3': (P(s, 'gpu_sift2_rep3', '.txt'), P(s, 'gpu_sift2_rep1', '.txt')),
            'gpu_vs_gpu_r4': (P(s, 'gpu_sift2_rep4', '.txt'), P(s, 'gpu_sift2_rep1', '.txt')),
            'gpu_vs_gpu_r5': (P(s, 'gpu_sift2_rep5', '.txt'), P(s, 'gpu_sift2_rep1', '.txt')),
            'gpu_cold_vs_warm': (P(s, 'gpu_sift2_cold', '.txt'), P(s, 'gpu_sift2_rep1', '.txt')),
            'cpu4_vs_cpu4_ref2': (P(s, 'cpu_sift2_t4_ref2', '.txt'), ref2),
            'cpu4_vs_cpu4_ref3': (P(s, 'cpu_sift2_t4_ref3', '.txt'), ref2),
            'fixiter_plus1_vs_cpu4': (P(s, 'gpu_sift2_fixiter_plus1', '.txt'), ref2),
            'fixiter_same_vs_cpu4': (P(s, 'gpu_sift2_fixiter_same', '.txt'), ref2),
            'v1_vs_cpu4': (P(s, 'gpu_sift2_v1', '.txt'), ref2),
            'reorder_length_vs_gpu': (P(s, 'gpu_sift2_reorder_length', '.txt'), P(s, 'gpu_sift2_rep1', '.txt')),
            'reorder_newton_vs_gpu': (P(s, 'gpu_sift2_reorder_newton', '.txt'), P(s, 'gpu_sift2_rep1', '.txt')),
        }
        for T in [1, 2, 8, 16, 24, 48, 96]:
            pairs_sift2[f'cpu{T}_vs_cpu4'] = (P(s, f'cpu_sift2_t{T}_scal', '.txt'), ref2)
        pairs_sift2['cpu1b_vs_cpu1'] = (P(s, 'cpu_sift2_t1_scal2', '.txt'), P(s, 'cpu_sift2_t1_scal', '.txt'))
        for n in glob.glob(f'{RUNS}/{s}/cpu_sift2_t*_best_ref1.json'):
            T = re.search(r'_t(\d+)_', n).group(1)
            pairs_sift2['cpubest_vs_cpu4'] = (P(s, f'cpu_sift2_t{T}_best_ref1', '.txt'), ref2)
            pairs_sift2['cpubest_vs_cpubest_ref2'] = (P(s, f'cpu_sift2_t{T}_best_ref2', '.txt'), P(s, f'cpu_sift2_t{T}_best_ref1', '.txt'))
            pairs_sift2['cpubest_vs_cpubest_ref3'] = (P(s, f'cpu_sift2_t{T}_best_ref3', '.txt'), P(s, f'cpu_sift2_t{T}_best_ref1', '.txt'))
            pairs_sift2['gpu_vs_cpubest'] = (P(s, 'gpu_sift2_rep1', '.txt'), P(s, f'cpu_sift2_t{T}_best_ref1', '.txt'))
        for n in glob.glob(f'{RUNS}/{s}/cpu_sift2_t*_best_ref1.json'):
            T = re.search(r'_t(\d+)_', n).group(1)
            if not os.path.exists(ref2): pairs_sift2['gpu_vs_cpubest'] = (P(s, 'gpu_sift2_rep1', '.txt'), P(s, f'cpu_sift2_t{T}_best_ref1', '.txt'))
        for N in [1000000, 2000000, 5000000, 20000000]:
            for n in glob.glob(f'{RUNS}/{s}/cpu_sift2_t*_size{N}.json'):
                T = re.search(r'_t(\d+)_', n).group(1)
                pairs_sift2[f'size{N}_gpu_vs_cpu'] = (P(s, f'gpu_sift2_size{N}', '.txt'), P(s, f'cpu_sift2_t{T}_size{N}', '.txt'))
        out['sift'][s] = {k: cached_cmp('sift', a, b, store) for k, (a, b) in pairs_sift.items()}
        out['sift2'][s] = {k: cached_cmp('sift2', a, b, store) for k, (a, b) in pairs_sift2.items()}
        out['sift'][s] = {k: v for k, v in out['sift'][s].items() if v}
        out['sift2'][s] = {k: v for k, v in out['sift2'][s].items() if v}
    return out

def main():
    os.makedirs(RES, exist_ok=True)
    runs = collect_runs()
    json.dump(runs, open(f'{RES}/runs.json', 'w'), indent=1)
    print(f'{len(runs)} runs parsed')
    if '--no-cmp' not in sys.argv:
        store_path = f'{RES}/cmp_cache.json'
        store = json.load(open(store_path)) if os.path.exists(store_path) else {}
        cmp = run_comparisons(runs, store)
        json.dump(store, open(store_path, 'w'), indent=1)
        json.dump(cmp, open(f'{RES}/comparisons.json', 'w'), indent=1)
        print('comparisons:', {k: {s: len(v) for s, v in d.items()} for k, d in cmp.items()})

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Hash every streamline of a .tck file (all vertices, raw float32 bytes) -> set of 64-bit hashes.
Used for exact set comparison of SIFT outputs. Streams the file; ~1-2 min per 1e6 streamlines."""
import numpy as np, hashlib, sys, struct
def read_header(f):
    hdr=b''
    while True:
        line=f.readline(); hdr+=line
        if line.strip()==b'END': break
    off=None
    for l in hdr.split(b'\n'):
        if l.startswith(b'file:'): off=int(l.split()[-1])
    return hdr, off
def tck_hashes(path):
    """Return (hashes: np.uint64 array in file order, n)."""
    with open(path,'rb') as f:
        hdr,off=read_header(f); f.seek(off)
        data=np.fromfile(f,dtype='<f4')
    data=data.reshape(-1,3)
    nan=np.isnan(data[:,0]); inf=np.isinf(data[:,0])
    end=np.where(nan|inf)[0]
    hashes=[]; start=0
    for e in end:
        if inf[e]: break
        seg=data[start:e]
        if len(seg)>0:
            hashes.append(int.from_bytes(hashlib.blake2b(seg.tobytes(),digest_size=8).digest(),'little'))
        start=e+1
    return np.array(hashes,dtype=np.uint64)
if __name__=='__main__':
    for p in sys.argv[1:]:
        h=tck_hashes(p); print(p,len(h),len(np.unique(h)))

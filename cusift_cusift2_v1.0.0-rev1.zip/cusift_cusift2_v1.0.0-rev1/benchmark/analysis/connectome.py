#!/usr/bin/env python3
"""Connectome-level comparison (D07).
  python3 connectome.py nodes <subj>                       -> DKT parcellation in DWI space (nodes_dwi.mif)
  python3 connectome.py build <subj> <label> sift <file.tck>            -> conn_<label>.csv
  python3 connectome.py build <subj> <label> sift2 <tracks.tck> <weights.txt>
  python3 connectome.py compare <subj> <labelA> <labelB> [--out key]    -> metrics json (printed / stored in results/connectome_pairs.json)
Connectomes: tck2connectome -assignment_radial_search 2 -symmetric -zero_diagonal (streamline count, or -scale... weights for SIFT2)."""
import os, sys, json, subprocess, numpy as np
import networkx as nx
REV = '/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision'; RUNS = '/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs'
DATA = '/media/ipsych/Data_4TB_01/mrtrix_sandbox/test_Data'; MRT = '/home/ipsych/anaconda3/envs/mrtrix3/bin'
FSLUT = f'{REV}/analysis/FreeSurferColorLUT_6col.txt'; MRTLUT = f'{MRT}/../share/mrtrix3/labelconvert/fs_default.txt'
SUBJ_DIR = {'UKB': f'{DATA}/UKB/results', 'HCP1': f'{DATA}/HCP/105216/results', 'HCP2': f'{DATA}/HCP/124826/results', 'HCP3': f'{DATA}/HCP/137128/results'}
NTHREADS = os.environ.get('CONN_THREADS', '4')

def sh(cmd):
    print('+', cmd, flush=True); subprocess.run(cmd, shell=True, check=True)

def nodes(s):
    d = SUBJ_DIR.get(s); o = f'{RUNS}/{s}/conn'; os.makedirs(o, exist_ok=True)
    seg = f'{RUNS}/fastsurfer/{s}/mri/aparc.DKTatlas+aseg.deep.mgz'
    if not os.path.exists(f'{o}/nodes_dwi.mif'):
        sh(f'nice -n 19 {MRT}/labelconvert {seg} {FSLUT} {MRTLUT} {o}/nodes_t1.mif -force -quiet')
        sh(f'nice -n 19 {MRT}/mrtransform {o}/nodes_t1.mif -linear {d}/dwi2t1_mrtrix.txt -inverse -interp nearest {o}/nodes_dwi_t1grid.mif -force -quiet')
        sh(f'nice -n 19 {MRT}/mrgrid {o}/nodes_dwi_t1grid.mif regrid -template {d}/dwi_mask.mif -interp nearest {o}/nodes_dwi.mif -force -quiet')
    return f'{o}/nodes_dwi.mif'

def build(s, label, kind, tck, weights=None):
    o = f'{RUNS}/{s}/conn'; nd = nodes(s); out = f'{o}/conn_{label}.csv'
    if os.path.exists(out): print('exists', out); return out
    w = f'-tck_weights_in {weights}' if kind == 'sift2' else ''
    sh(f'nice -n 19 {MRT}/tck2connectome {tck} {nd} {out} {w} -assignment_radial_search 2 -symmetric -zero_diagonal -nthreads {NTHREADS} -force -quiet')
    return out

def load_conn(p):
    A = np.loadtxt(p, delimiter=','); A = np.triu(A) + np.triu(A, 1).T; np.fill_diagonal(A, 0); return A

def net_measures(A, seed=0):
    G = nx.from_numpy_array(A);
    for u, v, dd in G.edges(data=True): dd['length'] = 1.0 / dd['weight']
    n = A.shape[0]; strength = A.sum(); density = (A > 0).sum() / (n * (n - 1))
    ge = nx.global_efficiency(G) if False else None
    # weighted global efficiency and characteristic path length on the largest component
    H = G.subgraph(max(nx.connected_components(G), key=len)).copy()
    sp = dict(nx.all_pairs_dijkstra_path_length(H, weight='length'))
    dists = np.array([d for u in sp for v, d in sp[u].items() if u != v])
    cpl = float(dists.mean()); geff = float((1.0 / dists).mean())
    clust = float(np.mean(list(nx.clustering(G, weight='weight').values())))
    best_q = -1
    for k in range(20):
        comm = nx.community.louvain_communities(G, weight='weight', seed=seed + k)
        q = nx.community.modularity(G, comm, weight='weight'); best_q = max(best_q, q)
    assort = float(nx.degree_assortativity_coefficient(G, weight='weight'))
    return dict(strength=float(strength), density=float(density), global_efficiency=geff, char_path_length=cpl, clustering=clust, modularity=float(best_q), assortativity=assort)

def compare(s, la, lb):
    o = f'{RUNS}/{s}/conn'; A = load_conn(f'{o}/conn_{la}.csv'); B = load_conn(f'{o}/conn_{lb}.csv')
    iu = np.triu_indices_from(A, 1); a, b = A[iu], B[iu]
    r_log = float(np.corrcoef(np.log1p(a), np.log1p(b))[0, 1])
    m = b > 10; rel = np.abs(a[m] - b[m]) / b[m]
    res = dict(subject=s, A=la, B=lb, n_nodes=int(A.shape[0]), n_edges_B=int((b > 0).sum()), r_log=r_log,
               frob_rel=float(np.linalg.norm(A - B) / np.linalg.norm(B)), max_abs_edge=float(np.abs(a - b).max()),
               p99_rel_edge=float(np.percentile(rel, 99)) if m.any() else None, max_rel_edge=float(rel.max()) if m.any() else None,
               n_only_one=int(((a > 0) != (b > 0)).sum()), max_w_only_one=float(np.maximum(a, b)[(a > 0) != (b > 0)].max()) if ((a > 0) != (b > 0)).any() else 0.0,
               strength_rel_node_max=float((np.abs(A.sum(1) - B.sum(1)) / B.sum(1)).max()))
    na, nb = net_measures(A), net_measures(B)
    res['net_A'] = na; res['net_B'] = nb
    res['net_rel'] = {k: abs(na[k] - nb[k]) / abs(nb[k]) for k in na}
    res['max_net_rel'] = max(res['net_rel'].values())
    print(json.dumps(res, indent=1))
    p = f'{REV}/results/connectome_pairs.json'; store = json.load(open(p)) if os.path.exists(p) else {}
    store[f'{s}|{la}|{lb}'] = res; json.dump(store, open(p, 'w'), indent=1)
    return res

def summary():
    """Collect connectome_pairs.json into results/connectome.json (per subject/algorithm: gpu_cpu, cpu_cpu, reseed) and the Conn* macros in extra.json."""
    import math
    p = f'{REV}/results/connectome_pairs.json'; store = json.load(open(p)) if os.path.exists(p) else {}
    fin = lambda v: v if (v is not None and math.isfinite(v)) else None
    def clean(r):
        # relative differences over the scale-type measures; assortativity is a correlation coefficient close to zero here, so its absolute difference is reported instead
        r = dict(r); r['max_net_rel'] = max((v for k, v in r['net_rel'].items() if k != 'assortativity' and math.isfinite(v)), default=None)
        r['assort_abs'] = abs(r['net_A']['assortativity'] - r['net_B']['assortativity']); return r
    conn = {}
    for k, r in store.items():
        s, la, lb = k.split('|')
        if la.startswith('test_'): continue
        alg = 'sift2' if la.startswith('sift2') else 'sift'
        role = 'gpu_cpu' if la == f'{alg}_gpu' and lb == f'{alg}_cpu4' else 'cpu_cpu' if la == f'{alg}_cpubest' and lb == f'{alg}_cpu4' else 'reseed' if la == f'{alg}_seedB' else None
        if role: conn.setdefault(s, {}).setdefault(alg, {})[role] = clean(r)
    json.dump(conn, open(f'{REV}/results/connectome.json', 'w'), indent=1)
    def col(alg, role, key):
        return [fin(conn[s][alg][role][key]) for s in conn if conn[s].get(alg, {}).get(role) and fin(conn[s][alg][role].get(key)) is not None]
    def sci(v): 
        if v == 0: return '0'
        e = int(math.floor(math.log10(abs(v)))); m = v / 10 ** e; return f'${m:.1f}\\times10^{{{e}}}$'
    def rng(v, f=sci): return (f(min(v)) + '--' + f(max(v))) if v else '[TBD]'
    def pct(v): return f'{100 * v:.1f}\\%'
    E = {}
    E['ConnNodes'] = str(next(iter(next(iter(conn.values())).values()))['gpu_cpu']['n_nodes']) if conn else '[TBD]'
    E['ConnReseedSubjects'] = str(len([s for s in conn if conn[s].get('sift', {}).get('reseed')]))
    for alg, tag in [('sift', 'ConnSift'), ('sift2', 'ConnSifttwo')]:
        r = col(alg, 'gpu_cpu', 'r_log'); E[tag + 'EdgeCorr'] = (f'{min(r):.6f}' if min(r) < 0.9999995 else '$>0.9999995$') if r else '[TBD]'
        E[tag + 'FrobRange'] = rng(col(alg, 'gpu_cpu', 'frob_rel')); E[tag + 'NetMaxRel'] = rng(col(alg, 'gpu_cpu', 'max_net_rel'))
    E['ConnSiftOnlyOneRange'] = rng(col('sift', 'gpu_cpu', 'n_only_one'), lambda v: f'{v:.0f}'); E['ConnSiftOnlyOneMaxW'] = rng(col('sift', 'gpu_cpu', 'max_w_only_one'), lambda v: f'{v:.0f}')
    E['ConnCpuCpuFrobRange'] = rng(col('sift', 'cpu_cpu', 'frob_rel') + col('sift2', 'cpu_cpu', 'frob_rel'))
    E['ConnReseedFrobRange'] = rng(col('sift', 'reseed', 'frob_rel') + col('sift2', 'reseed', 'frob_rel')); E['ConnReseedNetMaxRel'] = rng(col('sift', 'reseed', 'max_net_rel') + col('sift2', 'reseed', 'max_net_rel'))
    E['ConnMaxNetRel'] = rng(col('sift', 'gpu_cpu', 'max_net_rel') + col('sift2', 'gpu_cpu', 'max_net_rel'))
    E['ConnAssortAbsMax'] = sci(max(col('sift', 'gpu_cpu', 'assort_abs') + col('sift2', 'gpu_cpu', 'assort_abs'))) if col('sift', 'gpu_cpu', 'assort_abs') else '[TBD]'
    E['ConnCpuCpuAssortAbsMax'] = sci(max(col('sift', 'cpu_cpu', 'assort_abs'))) if col('sift', 'cpu_cpu', 'assort_abs') else '[TBD]'
    ep = f'{REV}/results/extra.json'; extra = json.load(open(ep)) if os.path.exists(ep) else {}; extra.update(E); json.dump(extra, open(ep, 'w'), indent=1)
    print(json.dumps(E, indent=1))

if __name__ == '__main__':
    cmd = sys.argv[1]
    if cmd == 'nodes': nodes(sys.argv[2])
    elif cmd == 'build': build(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6] if len(sys.argv) > 6 else None)
    elif cmd == 'compare': compare(sys.argv[2], sys.argv[3], sys.argv[4])
    elif cmd == 'summary': summary()

#!/usr/bin/env python3
"""Figure: (a) end-to-end runtime breakdown (one subject), (b) CPU thread scaling with GPU reference lines.
usage: fig_e2e_scaling.py --subject UKB --out fig.pdf"""
import argparse, json, os, re, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
REV = '/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision'; RUNS = '/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs'
runs = json.load(open(f'{REV}/results/runs.json'))
best = int(open(f'{RUNS}/best_threads.txt').read()) if os.path.exists(f'{RUNS}/best_threads.txt') else None
def R(s, name): return [r for r in runs if r['subject'] == s and r['name'] == name]
def Rg(s, pat): return [r for r in runs if r['subject'] == s and re.fullmatch(pat, r['name'])]
def med(rs, k): v = [r[k] for r in rs if r.get(k) is not None]; return float(np.median(v)) if v else 0.0

ap = argparse.ArgumentParser(); ap.add_argument('--subject', default='UKB'); ap.add_argument('--out', required=True); a = ap.parse_args()
s = a.subject
fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), gridspec_kw={'width_ratios': [1.15, 1]})
# ---- (a) stacked bars
ax = axes[0]
bars = []  # (label, [(component, seconds, colour)])
cols = {'read inputs + mapping': '#bbbbbb', 'optimisation': '#1f77b4', 'output write': '#7f7f7f', 'Stage 1 (mapping + serialise)': '#bbbbbb', 'mapping read': '#ffbb78', 'H2D': '#ff7f0e', 'GPU optimisation': '#d62728', 'output write (GPU)': '#7f7f7f'}
for alg, cpu4, cpub, gpu in [('SIFT', R(s, 'cpu_sift_t4_ref1') + R(s, 'cpu_sift_t4_ref2') + R(s, 'cpu_sift_t4_ref3'), Rg(s, r'cpu_sift_t\d+_best_ref\d'), Rg(s, r'gpu_sift_rep\d')),
                              ('SIFT2', R(s, 'cpu_sift2_t4_ref1') + R(s, 'cpu_sift2_t4_ref2') + R(s, 'cpu_sift2_t4_ref3'), Rg(s, r'cpu_sift2_t\d+_best_ref\d'), Rg(s, r'gpu_sift2_rep\d'))]:
    for lab, rs in [(f'{alg} CPU 4 thr.', cpu4), (f'{alg} CPU {best} thr.', cpub)]:
        if rs: bars.append((lab, [('read inputs + mapping', med(rs, 't_pre_s')), ('optimisation', med(rs, 't_opt_s')), ('output write', med(rs, 't_write_s'))]))
    for lab, st in [(f'{alg} GPU (Stage 1: 4 thr.)', R(s, 'stage1_t4_warm')), (f'{alg} GPU (Stage 1: {best} thr.)', Rg(s, r'stage1_t\d+_best'))]:
        if gpu and st:
            bars.append((lab, [('Stage 1 (mapping + serialise)', med(st, 'wall_s')), ('mapping read', med(gpu, 't_read_mapping')), ('H2D', med(gpu, 't_alloc_h2d' if alg == 'SIFT' else 't_prep_alloc_h2d')),
                               ('GPU optimisation', med(gpu, 't_optimise')), ('output write (GPU)', med(gpu, 't_write_tck' if alg == 'SIFT' else 't_write'))]))
y = np.arange(len(bars)); seen = set()
for i, (lab, comps) in enumerate(bars):
    left = 0
    for c, v, in comps:
        ax.barh(i, v, left=left, color=cols[c], edgecolor='k', linewidth=0.4, label=c if c not in seen else None); seen.add(c); left += v
    ax.text(left + 10, i, f'{left:.0f} s', va='center', fontsize=8)
ax.set_yticks(y); ax.set_yticklabels([b[0] for b in bars], fontsize=8); ax.invert_yaxis(); ax.set_xlabel('wall-clock time (s)'); ax.legend(fontsize=7, loc='upper center', bbox_to_anchor=(0.5, -0.16), ncol=3, frameon=False)
ax.set_title(f'(a) end-to-end runtime breakdown, {s} (medians)', fontsize=10, loc='left')
# ---- (b) thread scaling
ax = axes[1]
for subj, mk in [('UKB', 'o'), ('HCP2', 's')]:
    for cmd, col, name in [('tcksift', '#1f77b4', 'SIFT'), ('tcksift2', '#2ca02c', 'SIFT2')]:
        pts = {}
        for r in runs:
            if r['subject'] == subj and r['cmd'] == cmd and (r['name'].endswith('_scal') or r['name'].endswith('_ref1')) and r.get('t_opt_s'):
                pts.setdefault(r['threads'], []).append(r['t_opt_s'])
        if pts:
            T = sorted(pts); ax.plot(T, [np.median(pts[t]) for t in T], marker=mk, color=col, label=f'{name} CPU, {subj if subj=="UKB" else "HCP-2"}')
    for alg, col, ls in [('gpu_sift', '#1f77b4', '--'), ('gpu_sift2', '#2ca02c', '--')]:
        g = Rg(subj, alg + r'_rep\d')
        if g: ax.axhline(med(g, 't_optimise'), color=col, ls=ls if subj == 'UKB' else ':', lw=1, label=f'{"SIFT" if alg=="gpu_sift" else "SIFT2"} GPU, {subj if subj=="UKB" else "HCP-2"}')
ax.set_xscale('log', base=2); ax.set_yscale('log'); ax.set_xlabel('threads'); ax.set_ylabel('optimisation-phase time (s)'); ax.set_xticks([1, 2, 4, 8, 16, 24, 48, 96]); ax.set_xticklabels(['1', '2', '4', '8', '16', '24', '48', '96'])
ax.legend(fontsize=7, ncol=2); ax.grid(alpha=0.3, which='both'); ax.set_title('(b) reference thread scaling vs GPU', fontsize=10, loc='left')
fig.tight_layout(); fig.savefig(a.out, dpi=200); print('wrote', a.out)

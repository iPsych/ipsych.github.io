#!/usr/bin/env python3
"""Drive the streamline-based figures from the campaign outputs:
 main fig_sift_discrepant (subject with most discrepancies) + figS1 (others);
 main fig_sift2_weights (subject with largest max|dw|; distributions for all) + figS2 (others, scatter + axial map rows)."""
import json, os, subprocess, glob, re
REV = '/media/ipsych/Storage_Z8_3/mrtrix_sandbox/revision'; A = f'{REV}/analysis'; RUNS = '/media/ipsych/Data_4TB_01/mrtrix_sandbox/revision_runs'
DATA = '/media/ipsych/Data_4TB_01/mrtrix_sandbox/test_Data'; DOC = '/media/ipsych/Storage_Z8_3/M2561_CUDA_SIFT_SIFT2/M2561_CUDA_SIFT_SIFT2/Submission_MEP_IOP/1st_Revision/revised/figures'
SUBJ = ['UKB', 'HCP1', 'HCP2', 'HCP3']; LAB = {'UKB': 'UKB', 'HCP1': 'HCP-1', 'HCP2': 'HCP-2', 'HCP3': 'HCP-3'}
TRK = {'UKB': f'{DATA}/UKB/results/tracks_10000000.tck', 'HCP1': f'{DATA}/HCP/105216/results/tracks_10000000.tck', 'HCP2': f'{DATA}/HCP/124826/results/tracks_10000000.tck', 'HCP3': f'{DATA}/HCP/137128/results/tracks_10000000.tck'}
cmp = json.load(open(f'{REV}/results/comparisons.json'))
def sh(c): print('+', c, flush=True); subprocess.run(c, shell=True, check=False)
# SIFT
have = [s for s in SUBJ if 'gpu_vs_cpu4' in cmp['sift'].get(s, {})]
if have:
    main = max(have, key=lambda s: cmp['sift'][s]['gpu_vs_cpu4']['onlyA'] + cmp['sift'][s]['gpu_vs_cpu4']['onlyB'])
    sh(f"python3 {A}/fig_sift_discrepant.py --cpu {RUNS}/{main}/cpu_sift_t4_ref1.tck --gpu {RUNS}/{main}/gpu_sift_rep1.tck --title {LAB[main]} --out {DOC}/fig_sift_discrepant.pdf")
    others = [s for s in have if s != main]
    if others:
        sh(f"python3 {A}/fig_sift_discrepant.py --cpu {' '.join(f'{RUNS}/{s}/cpu_sift_t4_ref1.tck' for s in others)} --gpu {' '.join(f'{RUNS}/{s}/gpu_sift_rep1.tck' for s in others)} --title {' '.join(LAB[s] for s in others)} --out {DOC}/figS1_sift_discrepant_all.pdf")
# SIFT2
have2 = [s for s in SUBJ if 'gpu_vs_cpu4' in cmp['sift2'].get(s, {})]
if have2:
    main2 = max(have2, key=lambda s: cmp['sift2'][s]['gpu_vs_cpu4']['max_abs'])
    floor_a = [f for f in [glob.glob(f'{RUNS}/{main2}/cpu_sift2_t*_best_ref1.txt')] if f]; fa = floor_a[0][0] if floor_a else None
    floors = f"--floor_a {fa} --floor_b {RUNS}/{main2}/cpu_sift2_t4_ref1.txt --floor_label 'CPU best vs CPU 4 threads, {LAB[main2]}'" if fa else ''
    sh(f"python3 {A}/fig_sift2_weights.py --subjects {' '.join(LAB[s] for s in have2)} --cpu {' '.join(f'{RUNS}/{s}/cpu_sift2_t4_ref1.txt' for s in have2)} --gpu {' '.join(f'{RUNS}/{s}/gpu_sift2_rep1.txt' for s in have2)} --map_subject {LAB[main2]} --tracks {TRK[main2]} {floors} --out {DOC}/fig_sift2_weights.pdf")
    others = [s for s in have2 if s != main2]
    for s in others:  # one 4-panel figure per other subject, combined later by LaTeX includegraphics rows
        sh(f"python3 {A}/fig_sift2_weights.py --subjects {LAB[s]} --cpu {RUNS}/{s}/cpu_sift2_t4_ref1.txt --gpu {RUNS}/{s}/gpu_sift2_rep1.txt --map_subject {LAB[s]} --tracks {TRK[s]} --out {DOC}/figS2_sift2_weights_{s}.pdf")
    # stitch SI figure: list of per-subject PDFs -> one PDF via matplotlib not possible; we let LaTeX include them (figS2_sift2_weights_all.tex)
    with open(f'{DOC}/figS2_sift2_weights_all.tex', 'w') as f:
        for s in others: f.write(f'\\includegraphics[width=0.85\\linewidth]{{figures/figS2_sift2_weights_{s}}}\\\\[2pt]\n')
print('done')

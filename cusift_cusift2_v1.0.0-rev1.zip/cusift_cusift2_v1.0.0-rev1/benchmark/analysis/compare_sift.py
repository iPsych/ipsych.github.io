#!/usr/bin/env python3
"""Exact set comparison of two SIFT outputs. usage: compare_sift.py A.tck B.tck [out.json]"""
import sys, json, numpy as np
sys.path.insert(0, __file__.rsplit('/',1)[0]); from tckhash import tck_hashes
a=tck_hashes(sys.argv[1]); b=tck_hashes(sys.argv[2])
sa,sb=set(a.tolist()),set(b.tolist())
inter=len(sa&sb); only_a=len(sa-sb); only_b=len(sb-sa)
res=dict(A=sys.argv[1],B=sys.argv[2],nA=len(a),nB=len(b),uniqA=len(sa),uniqB=len(sb),common=inter,onlyA=only_a,onlyB=only_b,
         overlap_pct=100.0*inter/max(len(sa),1),jaccard_pct=100.0*inter/len(sa|sb))
print(json.dumps(res,indent=1))
if len(sys.argv)>3: json.dump(res,open(sys.argv[3],'w'),indent=1)
